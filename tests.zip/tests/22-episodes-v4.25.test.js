'use strict';
// v4.25.0 — Audit des épisodes : dates réécrites en bloc (Tsugai), date aberrante qui effaçait des épisodes, séries en pause
// jamais relues, dates AniList perdues au rechargement, numéro AniList incohérent, étiquette de nouvelle saison, plus aucune
// projection, annonces AniList confirmées Crunchyroll, saisons « The Final Season » écartées à tort, repères Débuts/Reprises.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
const ANI = /graphql\.anilist\.co/;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));
const iso = (ts) => new Date(ts).toISOString().slice(0, 16);

function build(id, title, eps, extra = {}) {
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const ph = new Map(eps.filter((e) => e.seen !== false).map((e) => [e.id, { p: 1440, full: true }]));
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air || e.avail)), null, 0, ph, null);
  return Object.assign(s, extra);
}
const ep = (id, season, n, avail, air) => ({ season, n, id: `${id}s${season}e${n}`, ids: [`${id}s${season}e${n}`], dur: 1440, title: '', avail, air: air === undefined ? avail : air });
const weekly = (id, n, endTs, o = {}) => Array.from({ length: n }, (_, i) => ep(id, o.season ?? 1, i + 1 + (o.startN ?? 0), endTs - (n - 1 - i) * 7 * DAY));

describe('RÉGRESSION Tsugai : épisodes de fin de série « sortis » le même jour', () => {
  const NOW = Date.parse('2026-10-24T19:00:00Z'), WED = Date.parse('2026-10-14T16:00:00Z');
  const tsugai = (restampFrom) => {
    const eps = [];
    for (let n = 1; n <= 24; n++) {
      const trueTs = WED - (24 - n) * 7 * DAY;
      eps.push(ep('TS', 1, n, n >= restampFrom ? WED : trueTs, trueTs - 3600e3));
    }
    return build('TS', 'Tsugai', eps);
  };
  test('E22-E24 réécrits au même instant : chacun retrouve sa vraie date de diffusion (jours distincts)', () => {
    E.setNow(NOW);
    T.STATE.series = [tsugai(22)];
    const ev = T.calReleasedEvents(NOW, Date.parse('2026-09-20T00:00:00Z'), NOW + 1);
    const byN = Object.fromEntries(ev.map((e) => [e.abs, e]));
    assert.equal(T.calDayKey(byN[22].ts), '2026-09-30');
    assert.equal(T.calDayKey(byN[23].ts), '2026-10-07');
    assert.equal(T.calDayKey(byN[24].ts), '2026-10-14');
    assert.equal(new Set(ev.filter((e) => e.abs >= 22).map((e) => T.calDayKey(e.ts))).size, 3, 'trois jours différents, plus un seul');
    assert.equal(byN[22].precision, 'day', 'la date est celle de la diffusion : pas d’heure inventée');
    assert.equal(byN[21].precision, 'time', 'un épisode normal garde son heure réelle');
  });
  test('l’accueil Crunchyroll ne propose plus ces épisodes comme « sortis aujourd’hui »', () => {
    const now = Date.parse('2026-10-24T10:00:00Z');
    E.setNow(now);
    const t = now - 2 * 3600e3;                                       // mise en ligne réécrite AUJOURD’HUI
    const eps = weekly('TS', 21, now - 40 * DAY);
    eps.push(ep('TS', 1, 22, t, now - 15 * DAY), ep('TS', 1, 23, t, now - 8 * DAY), ep('TS', 1, 24, t, now - 1 * DAY));
    T.STATE.series = [build('TS', 'Tsugai', eps)];
    T.STATE.loading = false;
    const out = T.crpCalEvents().ev.filter((e) => e.out);
    assert.equal(out.length, 0, 'rien de sorti aujourd’hui : ' + JSON.stringify(out.map((e) => e.n)));
  });
  test('lots LÉGITIMES intacts : ouverture de saison, rattrapage dont la diffusion est elle aussi groupée', () => {
    const now = E.now();
    const batch = now - 3 * DAY;
    // ouverture : E1-E3 le même jour, diffusion étalée sur 3 semaines (série ajoutée d’un coup)
    const s1 = build('P', 'Premiere', [ep('P', 1, 1, batch, now - 25 * DAY), ep('P', 1, 2, batch, now - 18 * DAY), ep('P', 1, 3, batch, now - 11 * DAY)]);
    // rattrapage en cours de série : diffusion à moins de 2 jours d’écart
    const s2 = build('R', 'Rattrapage', [ep('R', 1, 1, now - 30 * DAY), ep('R', 1, 2, batch, batch - DAY), ep('R', 1, 3, batch, batch)]);
    T.STATE.series = [s1, s2];
    const ev = T.calReleasedEvents(now, now - 5 * DAY, now + 1);
    assert.deepEqual(plain(ev.filter((e) => e.id === 'P').map((e) => e.ts)), [batch, batch, batch]);
    assert.deepEqual(plain(ev.filter((e) => e.id === 'R').map((e) => e.ts)), [batch, batch]);
    assert.ok(ev.every((e) => e.precision === 'time'));
  });
});

describe('RÉGRESSION : une date aberrante n’efface plus les épisodes normaux', () => {
  test('E10 daté il y a 200 j : E1-E9 sont conservés (seul E10 est écarté)', () => {
    const now = E.now();
    const rows = Array.from({ length: 10 }, (_, i) => ({ n: i + 1, t: now - (9 - i) * 7 * DAY }));
    rows[9].t = now - 200 * DAY;
    assert.deepEqual(plain(T.calDropRestamped(rows, (x) => x.t).map((x) => x.n)), [1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });
  test('dates normales, croissantes, ex æquo, vides : rien n’est retiré', () => {
    const f = (a) => T.calDropRestamped(a, (x) => x.t).map((x) => x.n);
    assert.deepEqual(plain(f([{ n: 1, t: 1e9 }, { n: 2, t: 1e9 }, { n: 3, t: 1e9 + 7 * DAY }])), [1, 2, 3]);
    assert.deepEqual(plain(f([{ n: 1, t: null }, { n: 2, t: 5e8 }, { n: 3, t: null }])), [1, 2, 3]);
    assert.deepEqual(plain(f([{ n: 1, t: 5 }])), [1]);
  });
  test('un épisode réécrit au MILIEU (E3 daté après E5) est toujours écarté, les autres restent', () => {
    const now = E.now();
    const rows = [0, 1, 2, 3, 4, 5].map((i) => ({ n: i + 1, t: now - (20 - 3 * i) * DAY }));
    rows[2].t = now - 0.5 * DAY;                                  // E3 réécrit hier
    assert.deepEqual(plain(T.calDropRestamped(rows, (x) => x.t).map((x) => x.n)), [1, 2, 4, 5, 6]);
  });
  test('sur 300 épisodes : rapide (pas de blocage de l’interface)', () => {
    const rows = Array.from({ length: 300 }, (_, i) => ({ n: i + 1, t: i * DAY }));
    const t0 = Date.now();
    T.calDropRestamped(rows, (x) => x.t);
    assert.ok(Date.now() - t0 < 500);
  });
});

describe('RÉGRESSION : séries en pause et cache épisodes', () => {
  test('TTL : en diffusion 1 h · pause < 150 j 6 h · ancienne 30 j', () => {
    const now = E.now();
    assert.equal(T.epsTtlMs(now - 3 * DAY), T.CFG.cacheHoursAiring * 3600e3);
    assert.equal(T.epsTtlMs(now - 25 * DAY), 6 * 3600e3);
    assert.equal(T.epsTtlMs(now - 200 * DAY), T.CFG.cacheHoursFinished * 3600e3);
    assert.equal(T.epsTtlMs(null), T.CFG.cacheHoursFinished * 3600e3);
  });
  test('AniList annonçait un épisode désormais sorti, plus récent que le cache → relecture', () => {
    const now = E.now();
    const put = (id, nextEpTs) => T.cacheSet('anilist:' + id, { matched: true, av: T.ANILIST_CACHE_VER, nextEpTs, nextEpNum: 5 });
    put('A', now - DAY); put('B', now + DAY); put('C', now - 5 * 60e3); put('D', now - 40 * DAY);
    assert.equal(T.epsAniSaysNew('A', now - 3 * DAY), true, 'épisode sorti depuis la dernière lecture');
    assert.equal(T.epsAniSaysNew('A', now - 3600e3), false, 'cache déjà postérieur à la sortie');
    assert.equal(T.epsAniSaysNew('B', now - 3 * DAY), false, 'pas encore sorti');
    assert.equal(T.epsAniSaysNew('C', now - 3 * DAY), false, 'moins de 15 min : Crunchyroll peut avoir du retard');
    assert.equal(T.epsAniSaysNew('Z', 0), false, 'aucune donnée AniList');
  });
  test('getEpisodes : série en pause relue après 6 h (et pas avant) ; nouvel épisode vu', async () => {
    const now = E.now();
    let calls = 0, nEps = 3;
    E.net.on(/\/content\/v2\/cms\/series\/BRK\/seasons/, () => ({ data: [{ id: 'sBRK', title: 'Season 1', season_number: 1, season_sequence_number: 1, series_title: 'Brk' }] }));
    E.net.on(/\/content\/v2\/cms\/seasons\/sBRK\/episodes/, () => { calls++; return { data: Array.from({ length: nEps }, (_, i) => ({ id: 'b' + (i + 1), episode_number: i + 1, title: '', duration_ms: 1440000, season_number: 1,
      episode_air_date: new Date(now - (60 - 7 * i) * DAY).toISOString(), availability_starts: new Date(now - (60 - 7 * i) * DAY).toISOString() })) }; });
    const a = await T.getEpisodes('BRK');
    assert.equal(a.episodes.length, 3); assert.equal(calls, 1);
    nEps = 4;
    E.advance(2 * 3600e3); T.SEASONS_MEMO.clear();
    assert.equal((await T.getEpisodes('BRK')).episodes.length, 3, 'moins de 6 h : cache');
    E.advance(5 * 3600e3); T.SEASONS_MEMO.clear();
    assert.equal((await T.getEpisodes('BRK')).episodes.length, 4, 'plus de 6 h : le nouvel épisode apparaît');
  });
});

describe('RÉGRESSION : dates AniList des épisodes suivants perdues au rechargement', () => {
  test('readAnilistCached relit futureEps ; la série reconstruite garde ses dates exactes', () => {
    const now = E.now();
    const fut = [[6, now + 3 * DAY], [7, now + 10 * DAY], [8, now + 24 * DAY]];       // E8 : une semaine de pause entre-temps
    T.cacheSet('anilist:F1', { matched: true, av: T.ANILIST_CACHE_VER, relv: 1, anilistStatus: 'RELEASING', plannedTotal: 12, nextEpTs: now + 3 * DAY, nextEpNum: 6, futureEps: fut });
    assert.deepEqual(plain(T.readAnilistCached('F1').futureEps), plain(fut));
    const s = build('F1', 'Fut', weekly('F1', 5, now - 2 * DAY));
    assert.deepEqual(plain(s.aniFuture), plain(fut));
    T.STATE.series = [s]; T.STATE.filters.calHorizon = 90;
    const ev = T.calEpisodeEvents(T.calOpts(), now, now + 90 * DAY).events;
    assert.deepEqual(plain(ev.map((e) => [e.abs, e.ts, e.exact])), plain(fut.map(([n, t]) => [n, t, true])), 'dates AniList, jamais « +7 jours »');
  });
  test('ancien cache sans futureEps : pas d’erreur', () => {
    T.cacheSet('anilist:F2', { matched: true, av: T.ANILIST_CACHE_VER, nextEpTs: E.now() + DAY, nextEpNum: 2 });
    assert.equal(T.readAnilistCached('F2').futureEps, null);
  });
});

describe('RÉGRESSION : plus AUCUNE date estimée', () => {
  test('seul le prochain épisode annoncé : pas de « prévu » à +7 j, ni à l’écran ni dans le modèle', () => {
    const now = E.now();
    T.STATE.series = [build('Y', 'Série Y', weekly('Y', 12, now - 2 * DAY), { aniNextTs: now + 2 * DAY, aniNextNum: 13, plannedTotal: 24, airing: true })];
    T.STATE.filters.calHorizon = 365;
    assert.equal(T.calOpts().proj, false);
    const m = T.calModel(T.calOpts(), now);
    assert.deepEqual(plain(m.events.filter((e) => e.type === 'ep').map((e) => [e.abs, e.exact])), [[13, true]]);
    const html = T.renderCalendrier();
    assert.ok(!/Prévu|prévu|Date estimée|rythme hebdomadaire/.test(html.replace(/Épisodes prévus/g, '')), 'aucun libellé d’estimation');
    assert.ok(!/data-k="calConfirmed"/.test(html));
  });
});

describe('RÉGRESSION : numéro AniList incohérent avec Crunchyroll, nouvelle saison', () => {
  const mkNext = (lastN, nextNum, o = {}) => {
    const now = E.now();
    const s = build('Z', 'Série Z', [...weekly('Z', lastN, now - 2 * DAY)], { aniNextTs: now + 2 * DAY, aniNextNum: nextNum, plannedTotal: o.total ?? 30, airing: true });
    T.STATE.series = [s];
    return T.calEpisodeEvents(T.calOpts(), now, now + 60 * DAY).events;
  };
  test('Crunchyroll à E12 : suite directe (+1 à +3) acceptée', () => {
    for (const n of [13, 14, 15]) assert.equal(mkNext(12, n).length, 1, 'E' + n);
  });
  test('Crunchyroll à E12 : « prochain = E3 », E12 ou E16 → mauvaise fiche AniList, rien d’affiché (ni héros)', () => {
    for (const n of [3, 12, 16]) {
      assert.equal(mkNext(12, n).length, 0, 'E' + n);
      assert.equal(T.calNextRelease(E.now()), null, 'héros E' + n);
    }
  });
  test('épisode 1 annoncé alors que la saison en cours en a déjà 12 : c’est la saison SUIVANTE (S2E1, S3E1…)', () => {
    const now = E.now();
    const eps = [...weekly('Q', 12, now - 60 * DAY, { season: 1 }), ...weekly('Q', 12, now - 2 * DAY, { season: 2 })];
    T.STATE.series = [build('Q', 'Série Q', eps, { aniNextTs: now + 20 * DAY, aniNextNum: 1, plannedTotal: 12, airing: true })];
    const [e1] = T.calEpisodeEvents(T.calOpts(), now, now + 60 * DAY).events;
    assert.equal(e1.sxe, 'S3E1'); assert.equal(e1.label, 'S3 E1'); assert.equal(e1.isNew, true);
    assert.equal(T.calNextRelease(now).label, 'S3 E1');
    // série à une seule saison
    T.STATE.series = [build('R', 'Série R', weekly('R', 12, now - 2 * DAY), { aniNextTs: now + 20 * DAY, aniNextNum: 1, plannedTotal: 12, airing: true })];
    assert.equal(T.calEpisodeEvents(T.calOpts(), now, now + 60 * DAY).events[0].sxe, 'S2E1');
  });
  test('début de série (E1-E2 sortis, AniList annonce E3) : pas pris pour une nouvelle saison', () => {
    const [e] = mkNext(2, 3);
    assert.equal(e.sxe, 'S1E3');
  });
});

describe('RÉGRESSION : saisons « The Final Season » / « Part 2 » écartées à tort', () => {
  test('saison sans libellé mais de vraie taille : gardée ; OAD de 2 épisodes : écarté ; « OVA » jamais lu', async () => {
    const now = E.now();
    const seasons = [
      { id: 's1', title: 'Season 1', season_number: 1, season_sequence_number: 1, series_title: 'Titan' },
      { id: 's2', title: 'Season 2', season_number: 2, season_sequence_number: 2, series_title: 'Titan' },
      { id: 's3', title: 'The Final Season', season_number: 3, season_sequence_number: 3, series_title: 'Titan' },
      { id: 'sp', title: 'Le rêve de Coleus', season_number: 4, season_sequence_number: 4, series_title: 'Titan' },
      { id: 'sv', title: 'Titan OVA', season_number: 5, season_sequence_number: 5, series_title: 'Titan' },
    ];
    const sizes = { s1: 12, s2: 12, s3: 8, sp: 2, sv: 3 };
    const asked = [];
    E.net.on(/\/content\/v2\/cms\/series\/TI\/seasons/, () => ({ data: seasons }));
    E.net.on(/\/content\/v2\/cms\/seasons\/([^/?]+)\/episodes/, (u) => {
      const id = u.match(/seasons\/([^/?]+)\/episodes/)[1]; asked.push(id);
      return { data: Array.from({ length: sizes[id] }, (_, i) => ({ id: id + 'e' + (i + 1), episode_number: i + 1, title: '', duration_ms: 1440000, season_number: seasons.findIndex((x) => x.id === id) + 1,
        episode_air_date: new Date(now - (100 - i) * DAY).toISOString(), availability_starts: new Date(now - (100 - i) * DAY).toISOString() })) };
    });
    const out = await T.fetchEpisodesRaw('TI');
    assert.equal(out.episodes.length, 32, '12 + 12 + 8 (Final Season gardée), spécial et OVA exclus');
    assert.ok(out.episodes.some((e) => e.season === 3));
    assert.ok(!asked.includes('sv'), 'un titre OVA n’est même pas demandé');
    assert.equal(out.fv, T.EPS_FILTER_VER);
  });
  test('anciens caches : une entrée v2 reste valable sauf si une saison avait été écartée « sans libellé »', () => {
    assert.equal(T.epsVerOk({ fv: T.EPS_FILTER_VER }), true);
    assert.equal(T.epsVerOk({ fv: 2, seasonsDiag: [{ why: 'label' }, { why: 'special' }] }), true);
    assert.equal(T.epsVerOk({ fv: 2, seasonsDiag: [{ why: 'unlabeled', keep: false }] }), false, 'à relire : « The Final Season » a pu être perdue');
    assert.equal(T.epsVerOk({ fv: 1 }), false);
    assert.equal(T.epsVerOk(null), false);
  });
});

describe('annonces AniList « pas encore sorties » diffusées sur Crunchyroll (dates futures)', () => {
  const NOWS = () => Math.floor(E.now() / 1000);
  // m = fiche AniList telle que renvoyée par Page.media (status NOT_YET_RELEASED, licensedById_in [5])
  const media = (id, o = {}) => ({ id, title: { english: o.title || 'Show ' + id, romaji: 'Romaji ' + id }, format: o.format || 'TV', genres: o.genres || ['Action'],
    description: 'Un <br>synopsis', coverImage: { large: 'https://img/' + id + '.jpg' }, season: o.season || null, seasonYear: o.seasonYear || null,
    startDate: o.startDate || { year: null, month: null, day: null },
    nextAiringEpisode: o.days === undefined ? null : { episode: 1, airingAt: NOWS() + o.days * 86400 },
    externalLinks: o.links === undefined ? [{ site: 'Crunchyroll', url: `https://www.crunchyroll.com/series/G${id}ABC/show-${id}`, type: 'STREAMING' }] : o.links });
  const ymd = (days) => { const d = new Date(E.now() + days * DAY); return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() }; };
  const mockAni = (list) => { E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: list } } })); };
  const prems = (view = 'agenda', horizon = 90) => T.calModel(Object.assign(T.calOpts(), { horizon, view }), E.now()).events.filter((e) => e.type === 'prem');

  test('requête = celle du site AniList : pas encore sortie + licence Crunchyroll (id 5)', async () => {
    const bodies = [];
    E.net.on(ANI, (u, o) => { bodies.push(String((o && o.body) || '')); return { data: { Page: { pageInfo: { hasNextPage: false }, media: [] } } }; });
    await T.loadAniFuture(true);
    assert.equal(bodies.length, 1);
    assert.match(bodies[0], /NOT_YET_RELEASED/); assert.match(bodies[0], /licensedById_in: \[5\]/);
  });
  test('films / genres exclus écartés ; le lien Crunchyroll n’est plus exigé (AniList affirme déjà la licence)', async () => {
    mockAni([media(1, { days: 5 }), media(3, { days: 5, format: 'MOVIE' }), media(4, { days: 5, genres: ['Hentai'] }), media(6, { days: 5, links: [] })]);
    await T.loadAniFuture(true);
    assert.deepEqual(plain(T.STATE.aniFut.items.map((i) => i.aniId).sort()), [1, 6]);
    const six = prems().find((e) => e.key === 'premani:6');
    assert.ok(six, 'série sans lien : affichée'); assert.match(six.urls.web, /crunchyroll\.com\/fr\/search\?q=Show%206/);
  });
  test('précisions : heure exacte, jour, mois, saison — jamais plus précis qu’AniList, sans date = écartée', async () => {
    mockAni([media(1, { days: 6 }), media(2, { startDate: ymd(20) }), media(3, { startDate: { year: new Date(E.now() + 40 * DAY).getFullYear(), month: new Date(E.now() + 40 * DAY).getMonth() + 1, day: null } }),
      media(4, { season: 'WINTER', seasonYear: new Date(E.now()).getFullYear() + 1 }), media(5)]);
    await T.loadAniFuture(true);
    const by = Object.fromEntries(prems('agenda', 400).map((e) => [e.key, e.precision]));
    assert.deepEqual(plain(by), { 'premani:1': 'time', 'premani:2': 'day', 'premani:3': 'month', 'premani:4': 'season' });
    assert.equal(prems('agenda', 400).find((e) => e.key === 'premani:1').ts, (NOWS() + 6 * 86400) * 1000);
  });
  test('Semaine / Mois : uniquement les dates précises ; mois et saison seuls vivent dans l’Agenda (« Date à préciser »)', async () => {
    mockAni([media(1, { days: 3 }), media(2, { startDate: ymd(4) }), media(3, { startDate: { year: new Date(E.now() + 5 * DAY).getFullYear(), month: new Date(E.now() + 5 * DAY).getMonth() + 1, day: null } })]);
    await T.loadAniFuture(true);
    const keys = (v) => prems(v, 30).map((e) => e.key).sort();
    assert.deepEqual(plain(keys('agenda')), ['premani:1', 'premani:2', 'premani:3']);
    for (const v of ['week', 'month']) assert.ok(!keys(v).includes('premani:3'), v);
    T.STATE.series = [build('Z0', 'Zéro', weekly('Z0', 3, E.now() - 2 * DAY))];
    const dom = E.html(T.renderCalendrier());
    assert.ok([...dom.querySelectorAll('.crrav-agsec.undated .crrav-calcard')].some((c) => /Show 3/.test(c.textContent)), 'carte dans « Date à préciser »');
  });
  test('l’événement : lien Crunchyroll, libellé « annoncé », fenêtre respectée', async () => {
    mockAni([media(1, { days: 6 }), media(5, { days: 3, links: [{ site: 'Crunchyroll', url: 'https://www.crunchyroll.com/some-page', type: 'STREAMING' }] }), media(7, { days: 400 })]);
    await T.loadAniFuture(true);
    const p = prems();
    assert.deepEqual(plain(p.map((e) => e.key)), ['premani:5', 'premani:1'], 'triés par date, la série à 400 j est hors période (90 j)');
    const a = p.find((e) => e.key === 'premani:1');
    assert.equal(a.released, false); assert.equal(a.announced, true);
    assert.match(a.urls.watch, /series\/G1ABC/);
    assert.equal(p.find((e) => e.key === 'premani:5').urls.web, 'https://www.crunchyroll.com/some-page');
    T.STATE.series = [build('Z0', 'Zéro', weekly('Z0', 3, E.now() - 2 * DAY))];
    const dom = E.html(T.renderCalendrier());
    const card = [...dom.querySelectorAll('.crrav-calcard.prem')].find((c) => /Show 1/.test(c.textContent));
    assert.ok(card, 'carte affichée'); assert.match(card.textContent, /Annoncé sur Crunchyroll ✓/); assert.match(card.textContent, /Épisode 1 le /);
  });
  test('doublons : déjà lue chez Crunchyroll (même fiche ou même titre) ou ignorée → une seule fois / jamais', async () => {
    const now = E.now();
    mockAni([media(1, { days: 5 }), media(2, { days: 5 }), media(3, { days: 5 })]);
    await T.loadAniFuture(true);
    T.STATE.crNew.items = [{ id: 'G1ABC', title: 'Autre titre', poster: '', wide: '', synopsis: '', categories: [], ts: now + 5 * DAY, firstN: 1, rank: 1, crId: 'G1ABC', crSlug: 'x', crSource: 'crunchyroll', eps: [{ id: 'e', n: 1, t: '', ts: now + 5 * DAY }] },
      { id: 'GZ', title: 'Show 2', poster: '', wide: '', synopsis: '', categories: [], ts: now + 6 * DAY, firstN: 1, rank: 1, crId: 'GZ', crSlug: 'z', crSource: 'crunchyroll', eps: [{ id: 'e2', n: 1, t: '', ts: now + 6 * DAY }] }];
    T.IGNORED.set('G3ABC', { title: '', source: 'newpremieres', ignoredAt: 0 });
    const keys = prems().map((e) => e.key);
    assert.ok(!keys.includes('premani:1'), 'même fiche Crunchyroll → date réelle de Crunchyroll');
    assert.ok(!keys.includes('premani:2'), 'même titre');
    assert.ok(!keys.includes('premani:3'), 'ignorée');
    assert.deepEqual(plain(keys.sort()), ['prem:G1ABC', 'prem:GZ']);
    T.IGNORED.delete('G3ABC');
  });
  test('suite d’une série de tes listes : « Nouvelle saison » ; cache 6 h ; réglage désactivé = aucune requête', async () => {
    const now = E.now();
    T.STATE.series = [build('G9ABC', 'Show 9', weekly('G9ABC', 12, now - 60 * DAY))];
    mockAni([media(9, { days: 10 })]);
    await T.loadAniFuture(true);
    assert.equal(prems()[0].followed.id, 'G9ABC');
    assert.match(E.html(T.renderCalendrier()).querySelector('.crrav-calcard.prem').textContent, /Nouvelle saison/);
    E.net.log.length = 0; T.STATE.aniFut.tried = false;
    T.calEnsureFuture(); T.calEnsureFuture(); await E.tick(30);
    assert.equal(E.net.log.filter((l) => ANI.test(l.url)).length, 0, 'cache de 6 h : pas de nouvelle requête');
    T.CFG.calFutureEnabled = false; E.net.log.length = 0; T.STATE.aniFut.tried = false;
    T.calEnsureFuture(); await E.tick(30);
    assert.equal(E.net.log.length, 0);
    assert.deepEqual(plain(prems()), []);
  });
  test('l’argument de filtre refusé par l’API : essai de l’écriture suivante, puis repli sur les épisodes 1 programmés', async () => {
    const seen = [];
    E.net.on(ANI, (u, o) => {
      const b = String((o && o.body) || ''); seen.push(b);
      if (/licensedById_in/.test(b) || /licensedById: 5/.test(b)) return { errors: [{ message: 'Unknown argument "licensedById"' }] };
      return { data: { Page: { pageInfo: { hasNextPage: false }, airingSchedules: [{ airingAt: NOWS() + 9 * 86400, media: media(1, { days: 9 }) }, { airingAt: NOWS() + 9 * 86400, media: media(2, { days: 9, links: [] }) }] } } };
    });
    await T.loadAniFuture(true);
    assert.equal(seen.length, 3, 'licensedById_in, licensedById, puis airingSchedules');
    assert.deepEqual(plain(T.STATE.aniFut.items.map((i) => i.aniId)), [1], 'au repli on exige le lien Crunchyroll déclaré');
  });
  test('panne ou pause AniList : le calendrier reste affichable, on garde le dernier état connu', async () => {
    mockAni([media(1, { days: 5 })]);
    await T.loadAniFuture(true);
    E.net.clear(); E.net.on(ANI, () => ({ __status: 500, body: 'boom' }));
    await T.loadAniFuture(true);
    assert.deepEqual(plain(T.STATE.aniFut.items.map((i) => i.aniId)), [1]);
    assert.match(T.STATE.aniFut.error || '', /indisponibles/);
    assert.doesNotThrow(() => T.renderCalendrier());
  });
});

describe('repères : Débuts / Reprises et Nouvelles séries', () => {
  test('« Reprises » exclut les nouvelles séries ; badge DÉBUT / SAISON / REPRISE selon la raison', () => {
    const now = E.now();
    const eps = [ep('A', 1, 1, now - 3 * DAY), ep('A', 1, 2, now - 2 * DAY)];                               // début de série
    const eps2 = [...weekly('B', 3, now - 80 * DAY), ep('B', 1, 4, now - 2 * DAY)];                          // reprise après 70 j de pause
    const eps3 = [...weekly('C', 12, now - 40 * DAY), ep('C', 2, 1, now - 1 * DAY)];                         // nouvelle saison
    T.STATE.series = [build('A', 'Alpha', eps), build('B', 'Bravo', eps2), build('C', 'Charlie', eps3)];
    T.STATE.crNew.items = [{ id: 'G1', title: 'Neuve', poster: '', wide: '', synopsis: '', categories: ['Action'], ts: now - DAY, firstN: 1, rank: 1, crId: 'G1', crSlug: 'g', crSource: 'crunchyroll', eps: [{ id: 'g1', n: 1, t: '', ts: now - DAY }] }];
    T.STATE.filters.calView = 'week'; T.STATE.filters.calWeekMode = 'rolling';
    const dom = E.html(T.renderCalendrier());
    const badge = (title) => { const c = [...dom.querySelectorAll('.crrav-calcard')].filter((x) => x.querySelector('.crrav-calttl').textContent === title).map((x) => (x.querySelector('.crrav-calnew') || {}).textContent || ''); return c; };
    assert.ok(badge('Alpha').includes('DÉBUT'));
    assert.ok(badge('Bravo').includes('REPRISE'));
    assert.ok(badge('Charlie').includes('SAISON'));
    assert.deepEqual(badge('Neuve'), [''], 'nouvelle série : pas de repère de reprise');
    const m = T.calModel(Object.assign(T.calOpts(), { flags: ['new'] }), now);
    assert.ok(m.events.length >= 3 && m.events.every((e) => e.type !== 'prem' && e.isNew));
    assert.match(dom.textContent, /Reprises/);
    assert.ok(!/\bNEW\b/.test(dom.textContent), 'plus de « NEW » ambigu');
  });
});
