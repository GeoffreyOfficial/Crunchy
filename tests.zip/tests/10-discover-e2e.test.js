'use strict';
// Bout en bout : un vrai scan Découverte (loadDiscover) sur un Crunchyroll/AniList simulé.
// Vérifie que rien de déjà vu / suivi / ignoré n'est proposé — le bug « Mashle » — et que
// le scan se termine toujours.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series, historyEntry, routeHistory } = require('./lib/env');

let E, T;
const panel = (id, title, extra = {}) => ({ id, type: 'series', title, slug_title: id.toLowerCase(), description: '', images: {},
  series_metadata: { season_count: 1, episode_count: 12, tenant_categories: extra.genres || ['Action'] } });

function setup({ catalog, history, profileTags = true, watchlist = [], customLists = [] }) {
  Object.assign(T.CFG, { discoverTarget: 10, discoverMinRatingCr: 0, discoverMinRatingAni: 0, discoverBrowseCacheHours: 0,
    discoverMaxSeasons: 5, discoverExcludeCategories: ['romance', 'hentai'] });
  T.STATE.series = [series('TRACKED', [ep(1, 1, { seen: true }), ep(1, 2)], { title: 'Série suivie',
    tags: profileTags ? [{ name: 'Magic', rank: 90 }] : [], categories: ['Action'] })];
  T.STATE.filters.discoverCatsIn = []; T.STATE.filters.discoverCatsEx = [];
  routeHistory(E.net, history);
  E.net.on(/discover\/acc\/watchlist/, () => ({ data: watchlist.map((id) => ({ panel: { type: 'series', id } })), total: watchlist.length }));
  E.net.on(/custom-lists\?/, () => ({ data: customLists.length ? [{ list_id: 'L1', title: 'Ma liste' }] : [] }));
  E.net.on(/custom-lists\/L1/, () => ({ data: customLists.map((id) => ({ panel: { type: 'series', id } })) }));
  E.net.on(/discover\/browse/, (u) => { const s = +new URL(u).searchParams.get('start'); return { data: s === 0 ? catalog : [], total: catalog.length }; });
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\?/, (u, o, m) => ({ data: [catalog.find((p) => p.id === m[1]) || panel(m[1], m[1])] }));
  E.net.on(/rating\/series/, () => ({ average: '4.5' }));
  E.net.on(/graphql\.anilist/, () => ({ data: {} }));
  E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
}
// onProgress qui casse une éventuelle boucle infinie (sinon le test gèlerait).
function guardedProgress(limit = 5000) {
  const g = { calls: 0 };
  g.fn = () => { if (++g.calls > limit) throw new Error('boucle infinie détectée (' + limit + ' progressions)'); };
  return g;
}
const ids = () => T.STATE.discover.series.map((s) => s.id);

beforeEach(() => { E = fresh(); T = E.T; T.CFG.concurrency = 3; T.PACE.limit = 3; });
afterEach(() => E.close());

describe('loadDiscover — exclusions', () => {
  test('série vue tout au fond d’un historique de 250+ entrées : jamais proposée (régression Mashle)', async () => {
    const history = [];
    for (let i = 0; i < 250; i++) history.push(historyEntry('W' + Math.floor(i / 12), 1, i % 12 + 1, E.now() - i * 3600e3));
    history.push(historyEntry('GDKHZEP8W', 1, 1, E.now() - 900 * 3600e3, { title: 'MASHLE: MAGIC AND MUSCLES' }));
    setup({ history, catalog: [panel('GDKHZEP8W', 'MASHLE: MAGIC AND MUSCLES'), panel('GNEW1', 'Nouvelle série'), panel('W3', 'Vue W3'), panel('GNEW2', 'Autre nouvelle')] });
    const g = guardedProgress();
    await T.loadDiscover(g.fn, { force: true });
    assert.equal(T.STATE.discover.error, null);
    assert.deepEqual([...ids()].sort(), ['GNEW1', 'GNEW2']);
  });
  test('autre fiche du même titre (doublage / saison à part) : écartée par le filet titre', async () => {
    setup({ history: [historyEntry('GORIG', 1, 1, E.now(), { title: 'Frieren' })],
      catalog: [panel('GDUB', 'Frieren (French Dub)'), panel('GNEW', 'Totalement neuve')] });
    await T.loadDiscover(guardedProgress().fn, { force: true });
    assert.deepEqual([...ids()], ['GNEW']);
  });
  test('watchlist, Crunchylists, séries suivies et ignorées : exclues', async () => {
    setup({ history: [], watchlist: ['GWL'], customLists: ['GCL'],
      catalog: [panel('GWL', 'En watchlist'), panel('GCL', 'En liste perso'), panel('TRACKED', 'Série suivie'), panel('GIGN', 'Ignorée'), panel('GOK', 'Libre')] });
    T.toggleIgnored('GIGN', 'Ignorée', 'discover');
    await T.loadDiscover(guardedProgress().fn, { force: true });
    assert.deepEqual([...ids()], ['GOK']);
  });
  test('genre exclu (romance) et trop de saisons : écartés', async () => {
    const many = panel('GMANY', 'Fleuve'); many.series_metadata.season_count = 9;
    setup({ history: [], catalog: [panel('GROM', 'Romance', { genres: ['Romance'] }), many, panel('GOK', 'Libre')] });
    await T.loadDiscover(guardedProgress().fn, { force: true });
    assert.deepEqual([...ids()], ['GOK']);
  });
  test('historique indisponible : avertissement visible, scan quand même mené', async () => {
    setup({ history: [], catalog: [panel('GOK', 'Libre')] });
    E.net.clear();
    E.net.on(/watch-history/, () => ({ __status: 500, body: {} }));
    E.net.on(/discover\/browse/, (u) => (new URL(u).searchParams.get('start') === '0' ? { data: [panel('GOK', 'Libre')] } : { data: [] }));
    E.net.on(/cms\/series\/GOK/, () => ({ data: [panel('GOK', 'Libre')] }));
    E.net.on(/rating\/series/, () => ({ average: '4.5' }));
    E.net.on(/graphql\.anilist/, () => ({ data: {} }));
    E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
    await T.loadDiscover(guardedProgress().fn, { force: true });
    assert.ok(T.STATE.discover.warning, 'l’utilisateur est prévenu');
  });
});

describe('loadDiscover — terminaison', () => {
  test('classement CR épuisé avec un profil de goût SANS tags AniList : le scan se termine (régression v4.8.0)', async () => {
      setup({ history: [], profileTags: false, catalog: [panel('GOK', 'Libre')] });
      const g = guardedProgress(2000);
      await T.loadDiscover(g.fn, { force: true });
      assert.ok(g.calls < 2000, `le scan a tourné en boucle (${g.calls} progressions)`);
      assert.equal(T.STATE.discover.error, null);
    });
  test('AniList en erreur GraphQL pendant le rattrapage : le scan se termine aussi', async () => {
    E.net.on(/graphql\.anilist/, () => ({ errors: [{ message: 'Unknown argument' }] }));   // prioritaire sur setup()
    setup({ history: [], catalog: [panel('GOK', 'Libre')] });
    const g = guardedProgress(2000);
    await T.loadDiscover(g.fn, { force: true });
    assert.ok(g.calls < 2000, `boucle (${g.calls})`);
    assert.deepEqual([...ids()], ['GOK']);
  });
});

describe('loadOrphelines (Hors listes) de bout en bout', () => {
  const eps12 = (sid) => ({ data: Array.from({ length: 12 }, (_, i) => ({ id: `${sid}-e${i + 1}`, episode_number: i + 1, season_number: 1, sequence_number: i + 1, duration_ms: 1440000, title: '', versions: [] })) });
  function setupOrphans({ history, watchedEps, failOnce = new Set() }) {
    T.STATE.series = []; T.STATE.raw = [];
    routeHistory(E.net, history);
    E.net.on(/cms\/series\/([A-Za-z0-9]+)\/seasons/, (u, o, m) => ({ data: [{ id: m[1] + '-S1', season_number: 1, number_of_episodes: 12, title: 'Saison 1', versions: [] }] }));
    E.net.on(/cms\/seasons\/([A-Za-z0-9]+)-S1\/episodes/, (u, o, m) => eps12(m[1]));
    E.net.on(/cms\/series\/([A-Za-z0-9]+)\?/, (u, o, m) => {
      if (failOnce.has(m[1])) { failOnce.delete(m[1]); return { __status: 500, body: {} }; }
      return { data: [panel(m[1], 'Série ' + m[1])] };
    });
    E.net.on(/playheads/, (u) => {
      const ids = new URL(u).searchParams.get('content_ids').split(',');
      return { data: ids.filter((id) => watchedEps.has(id)).map((id) => ({ content_id: id, playhead: 1440, fully_watched: true })) };
    });
    E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
  }
  test('toutes les séries hors listes affichées, rangées par section (v4.12.0)', async () => {
    const t = E.now();
    const history = [historyEntry('GA', 1, 1, t), historyEntry('GB', 1, 1, t - 1), historyEntry('GC', 1, 1, t - 2)];
    const watched = new Set(['GA-e1', 'GA-e2', ...Array.from({ length: 12 }, (_, i) => `GB-e${i + 1}`)]);
    setupOrphans({ history, watchedEps: watched });
    await T.loadOrphelines(() => {});
    const O = T.STATE.orphan;
    assert.equal(O.error, null);
    assert.deepEqual([...O.series.map((s) => s.id)].sort(), ['GA', 'GB', 'GC']);
    const grp = Object.fromEntries(O.series.map((s) => [s.id, T.orphanGroupOf(s)]));
    assert.deepEqual(grp, { GA: 'barely', GB: 'uptodate', GC: 'barely' });
    assert.equal(O.stats.history, 3);
    assert.equal(O.stats.finished, 1);
    assert.equal(O.stats.barelyStarted, 1);
    assert.equal(O.stats.failed, 0);
  });
  test('analyse en échec : rejouée au lieu d’être sautée en silence (v4.8.0)', async () => {
    const t = E.now();
    setupOrphans({ history: [historyEntry('GA', 1, 1, t), historyEntry('GZ', 1, 1, t - 1)], watchedEps: new Set(['GA-e1', 'GZ-e1']), failOnce: new Set(['GZ']) });
    await T.loadOrphelines(() => {});
    assert.deepEqual([...T.STATE.orphan.series.map((s) => s.id)].sort(), ['GA', 'GZ']);
    assert.equal(T.STATE.orphan.stats.failed, 0);
  });
});
