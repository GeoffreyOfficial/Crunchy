'use strict';
// v4.21.0 — filtres du calendrier (groupes, recherche, dates confirmées), vue Mois visuelle,
// agenda d'une série (fiche détaillée, ICS, points d'entrée).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T, D;
beforeEach(() => { E = fresh(); T = E.T; D = E.w.document; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());

function mk(id, title, o = {}) {
  const now = E.now();
  const nEps = o.nEps ?? 5, seen = o.seen ?? nEps;
  const eps = [];
  for (let n = 1; n <= nEps; n++) {
    const air = now - (nEps - n) * 7 * DAY - 2 * DAY;
    eps.push({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, air, avail: air, title: '' });
  }
  const ph = new Map(eps.slice(0, seen).map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, o.rating ?? null);
  if (o.noNext !== true) { s.aniNextTs = now + (o.inDays ?? 3) * DAY; s.aniNextNum = nEps + 1; }
  s.plannedTotal = o.total === undefined ? 12 : o.total;
  if (o.future) s.aniFuture = o.future;
  s.poster = o.poster ?? '';
  return s;
}
const opts = (over = {}) => ({ view: 'agenda', horizon: 365, filter: 'all', proj: true, est: false, onlyCr: false, ...over });
const ids = (m) => [...new Set(m.events.map((e) => e.id))].sort();
const PREM = (id, title, followed, inDays = 30) => ({ id, title, poster: '', ts: E.now() + inDays * DAY, precision: 'time', titles: [title], categories: [], popularity: 1, season: 'WINTER', seasonYear: 2027, crId: id, crSlug: id });

describe('filtres : nouveaux critères', () => {
  test('« À commencer », « Derniers ép. », « Mes séries » et compteurs', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 6, nEps: 5 }), mk('B', 'Bravo', { seen: 0, nEps: 5, total: null })];
    const m = T.calModel(opts(), E.now());
    assert.equal(m.counts.mine, m.events.filter((e) => e.type !== 'prem').length);
    assert.deepEqual([...ids(T.calModel(opts({ filter: 'unstarted' }), E.now()))], ['B']);
    const fin = T.calModel(opts({ filter: 'final' }), E.now());
    assert.deepEqual([...ids(fin)], ['A']);
    assert.ok(fin.events.every((e) => e.final));
    assert.equal(m.counts.final, 1);
    assert.equal(m.counts.unstarted, m.events.filter((e) => e.id === 'B').length);
  });
  test('recherche par titre (accents/casse/mots) appliquée AVANT les compteurs', () => {
    T.STATE.series = [mk('A', 'Les Carnets de l’apothicaire'), mk('B', 'Bravo Team')];
    assert.deepEqual([...ids(T.calModel(opts({ q: 'APOTHICAIRE carnets' }), E.now()))], ['A']);
    assert.deepEqual([...ids(T.calModel(opts({ q: 'brâvo' }), E.now()))], ['B']);
    const m = T.calModel(opts({ q: 'bravo' }), E.now());
    assert.equal(m.counts.all, m.events.length);
    assert.equal(T.calModel(opts({ q: 'zzz' }), E.now()).events.length, 0);
    assert.equal(T.calModel(opts({ q: '   ' }), E.now()).events.length, T.calModel(opts(), E.now()).events.length);
  });
  test('« dates confirmées » retire projections et estimations, garde les annonces', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    const all = T.calModel(opts(), E.now()).events.filter((e) => e.type === 'ep');
    const sure = T.calModel(opts({ confirmed: true }), E.now()).events.filter((e) => e.type === 'ep');
    assert.ok(all.length > 1);
    assert.equal(sure.length, 1); assert.equal(sure[0].exact, true);
  });
  test('« Suites » : nouvelles saisons de séries suivies uniquement', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.calFuture.items = [PREM('P1', 'Alpha', null), PREM('P2', 'Zeta', null, 40)];
    T.STATE.calFuture.loaded = true;
    const m = T.calModel(opts({ horizon: 365 }), E.now());
    const seq = T.calModel(opts({ filter: 'sequel' }), E.now());
    assert.ok(m.counts.new >= 1);
    assert.ok(seq.events.every((e) => e.type === 'prem' && e.followed));
    assert.ok(seq.events.length <= m.counts.new);
    assert.equal(m.counts.sequel, seq.events.length);
  });
  test('options invalides ou état corrompu : retombe sur « Tout »', () => {
    T.STATE.filters.calFilter = 'nimportequoi'; T.STATE.calUi = { q: 42 };
    const o = T.calOpts();
    assert.equal(o.filter, 'all'); assert.equal(o.q, '');
  });
});

describe('filtres : interface', () => {
  async function openCal(series) {
    T.STATE.series = series; T.STATE.tab = 'suivi';
    T.openCalendar(); await E.tick(60);
    return D.querySelector('.crrav-overlay');
  }
  test('groupes libellés, recherche, bascule « dates confirmées », info-bulles', async () => {
    const ov = await openCal([mk('A', 'Alpha')]);
    const caps = [...ov.querySelectorAll('.crrav-calfl')].map((n) => n.textContent);
    assert.ok(caps.includes('Mes séries') && caps.includes('Nouveautés') && caps.includes('Période'));
    assert.ok(ov.querySelector('.crrav-calq'));
    assert.ok(ov.querySelector('[data-k="calConfirmed"]'));
    for (const c of ov.querySelectorAll('.crrav-calchip[data-act="cal-filter"]')) assert.ok(c.title, 'info-bulle sur ' + c.dataset.v);
    assert.equal(ov.querySelector('.crrav-calres'), null, 'pas de ligne de résultat sans filtre');
    assert.equal(ov.querySelector('[data-act="cal-reset"]'), null);
  });
  test('filtre actif : ligne de résultat + « Effacer » qui remet tout à zéro', async () => {
    const ov = await openCal([mk('A', 'Alpha'), mk('B', 'Bravo')]);
    ov.querySelector('[data-act="cal-filter"][data-v="late"]').click();
    T.calUi().q = 'alp'; T.forceRender(); await E.tick(20);
    const res = D.querySelector('.crrav-calres');
    assert.ok(res && /En retard/.test(res.textContent) && /alp/.test(res.textContent));
    D.querySelector('[data-act="cal-reset"]').click(); await E.tick(20);
    assert.equal(T.STATE.filters.calFilter, 'all'); assert.equal(T.calUi().q, ''); assert.equal(T.STATE.filters.calConfirmed, false);
    assert.equal(D.querySelector('.crrav-calres'), null);
  });
  test('saisie dans la recherche : filtre la vue et garde la valeur', async () => {
    const ov = await openCal([mk('A', 'Alpha'), mk('B', 'Bravo')]);
    const inp = ov.querySelector('.crrav-calq');
    inp.value = 'bra'; inp.dispatchEvent(new E.w.Event('input', { bubbles: true }));
    await E.tick(300);
    assert.equal(T.calUi().q, 'bra');
    const titles = [...D.querySelectorAll('.crrav-calcard .crrav-calttl')].map((n) => n.textContent);
    assert.ok(titles.length && titles.every((t) => t === 'Bravo'), titles.join());
    assert.equal(D.querySelector('.crrav-calq').value, 'bra');
  });
  test('rien ne correspond : message clair + bouton pour effacer', async () => {
    const ov = await openCal([mk('A', 'Alpha')]);
    T.calUi().q = 'zzz'; T.forceRender(); await E.tick(20);
    assert.match(D.querySelector('.crrav-overlay').textContent, /Rien ne correspond à ces filtres/);
    assert.ok(D.querySelector('.crrav-calemptyacts [data-act="cal-reset"]'));
  });
  test('l’export .ics et les compteurs respectent la recherche', () => {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo')];
    T.calUi().q = 'alpha';
    const m = T.calModel(T.calOpts(), E.now());
    const { text } = T.calBuildIcs(m.events, E.now());
    assert.match(text, /Alpha/); assert.doesNotMatch(text, /Bravo/);
  });
});

describe('vue Mois : visuelle', () => {
  function monthHtml(series, setup) {
    T.STATE.series = series;
    T.STATE.filters.calView = 'month';
    if (setup) setup();
    const m = T.calModel(T.calOpts(), E.now());
    return { m, html: T.calMonthBody(m, T.calUi()) };
  }
  test('chaque jour chargé affiche affiches + vignettes détaillées + compteur', () => {
    const { html } = monthHtml([mk('A', 'Alpha', { poster: 'https://x/a.jpg', inDays: 1 })]);
    assert.match(html, /crrav-calthumbs/); assert.match(html, /crrav-calmini/); assert.match(html, /crrav-calcnt/);
    assert.match(html, /src="https:\/\/x\/a\.jpg"/);
    assert.match(html, /crrav-callegend/);
    assert.match(html, /class="crrav-calcell[^"]* heat1/);
  });
  test('journée chargée : 3 affiches + tuile « +N », jamais plus de 4 tuiles', () => {
    const many = ['A', 'B', 'C', 'D', 'E', 'F'].map((x) => mk(x, 'Serie ' + x, { inDays: 1 }));
    const { html, m } = monthHtml(many);
    const day = T.calDayKey(m.events[0].ts);
    const cell = html.split('<button').find((c) => c.includes(`data-day="${day}"`));
    assert.equal((cell.match(/class="crrav-calth /g) || []).length, 4);
    assert.match(cell, /crrav-calth more">\+3</);
    assert.match(cell, /crrav-calmore m3">\+3 autres/);
    assert.match(cell, /crrav-calmore m4">\+2 autres/);
  });
  test('couleurs par type : retard, nouveauté, sorti aujourd’hui', () => {
    const a = mk('A', 'Alpha', { seen: 3, inDays: 1 });
    const { html } = monthHtml([a]);
    assert.match(html, /crrav-calth late/);
  });
  test('séries ignorées : jamais dans la grille', () => {
    const a = mk('A', 'Alpha', { inDays: 1 });
    T.STATE.series = [a];
    T.toggleIgnored(a.id, { title: 'Alpha', source: 'watchlist' });
    T.STATE.filters.calView = 'month';
    const html = T.calMonthBody(T.calModel(T.calOpts(), E.now()), T.calUi());
    assert.doesNotMatch(html, /Alpha/);
    assert.doesNotMatch(html, /crrav-calth/);
  });
  test('titres échappés dans les vignettes', () => {
    const { html } = monthHtml([mk('A', 'A<img src=x onerror=1>', { inDays: 1 })]);
    assert.doesNotMatch(html, /<img src=x/);
  });
  test('CSS : mobile = affiches serrées ; ≥560 = pastilles détaillées ; ≥1700 = jour sélectionné à côté', () => {
    const css = T.CSS;
    assert.match(css, /\.crrav-calthumbs\{display:grid/);
    assert.match(css, /@container cal \(min-width:560px\)\{[\s\S]*?crrav-calthumbs\{display:none\}/);
    assert.match(css, /@container cal \(min-width:1700px\)\{\s*\.crrav-calmonth\{display:grid/);
    // Régression : à côté de la grille, le jour sélectionné doit rester UNE colonne (pas 3/4 colonnes étroites).
    assert.match(css, /\.crrav-calmonth \.crrav-calselday \.crrav-calcards\{grid-template-columns:minmax\(0,1fr\) !important/);
  });
});

describe('agenda d’une série', () => {
  test('modèle : prochaines sorties, total, sortis, dernier épisode, tout trié', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 8, nEps: 5, inDays: 2 })];
    const m = T.calSeriesModel('A', E.now());
    assert.deepEqual(JSON.parse(JSON.stringify(m.events.map((e) => e.abs))), [6, 7, 8]);
    assert.equal(m.released, 5); assert.equal(m.total, 8);
    assert.equal(m.first.exact, true); assert.equal(m.last.final, true);
    for (let i = 1; i < m.events.length; i++) assert.ok(m.events[i].ts > m.events[i - 1].ts);
  });
  test('série inconnue : null ; ignorée : aucune sortie', () => {
    assert.equal(T.calSeriesModel('nope', E.now()), null);
    const a = mk('A', 'Alpha');
    T.STATE.series = [a];
    T.toggleIgnored(a.id, { title: 'Alpha', source: 'watchlist' });
    const m = T.calSeriesModel('A', E.now());
    assert.equal(m.ignored, true); assert.equal(m.events.length, 0);
    T.STATE.serieAgenda = { id: 'A' };
    assert.match(T.calSeriesSheetHtml(), /Série ignorée/);
  });
  test('ne montre que cette série (jamais les autres)', () => {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo')];
    const m = T.calSeriesModel('B', E.now());
    assert.ok(m.events.length && m.events.every((e) => e.id === 'B'));
  });
  test('fiche : frise vus / sortis / à venir, tuiles, liste par épisode, actions', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 12, nEps: 5, seen: 3, inDays: 2 })];
    T.STATE.serieAgenda = { id: 'A' };
    const html = T.calSeriesSheetHtml();
    assert.equal((html.match(/<i class="seen/g) || []).length, 3);
    assert.equal((html.match(/<i class="out/g) || []).length, 2);
    assert.equal((html.match(/<i class="next/g) || []).length, 7);
    assert.match(html, /2 ép\. de retard/);
    assert.match(html, /E6/); assert.match(html, /E12/); assert.match(html, /dernier/);
    assert.match(html, /data-act="cal-sa-ics"/); assert.match(html, /data-act="cal-sa-focus"/);
    assert.equal((html.match(/class="crrav-sa-r/g) || []).length, 7);
  });
  test('titre échappé dans la fiche', () => {
    T.STATE.series = [mk('A', '<b>X</b>')];
    T.STATE.serieAgenda = { id: 'A' };
    assert.doesNotMatch(T.calSeriesSheetHtml(), /<h3><b>X/);
  });
  test('depuis une carte du calendrier : ouvre la fiche, ✕ / fond / Échap la ferment', async () => {
    T.STATE.series = [mk('A', 'Alpha')]; T.STATE.tab = 'suivi';
    T.openCalendar(); await E.tick(60);
    const btn = D.querySelector('.crrav-calcard [data-act="cal-series"]');
    assert.ok(btn, 'bouton Série sur la carte');
    btn.click(); await E.tick(20);
    assert.ok(D.querySelector('.crrav-sa'));
    D.querySelector('.crrav-sa-x').click(); await E.tick(20);
    assert.equal(D.querySelector('.crrav-sa'), null);
    D.querySelector('.crrav-calcard [data-act="cal-series"]').click(); await E.tick(20);
    D.querySelector('.crrav-sa-bg').click(); await E.tick(20);
    assert.equal(D.querySelector('.crrav-sa'), null);
    D.querySelector('.crrav-calcard [data-act="cal-series"]').click(); await E.tick(20);
    D.dispatchEvent(new E.w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); await E.tick(20);
    assert.equal(D.querySelector('.crrav-sa'), null);
    assert.ok(D.querySelector('.crrav-overlay') && D.querySelector('.crrav-overlay').style.display !== 'none', 'Échap ferme d’abord la fiche, pas le panneau');
  });
  test('clic dans la fiche ne la ferme pas', async () => {
    T.STATE.series = [mk('A', 'Alpha')]; T.STATE.tab = 'suivi';
    T.openCalendar(); await E.tick(60);
    D.querySelector('.crrav-calcard [data-act="cal-series"]').click(); await E.tick(20);
    D.querySelector('.crrav-sa-head').click(); await E.tick(10);
    assert.ok(D.querySelector('.crrav-sa'));
  });
  test('« Voir dans l’agenda » : filtre la vue Agenda sur cette série (1 an)', async () => {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo')]; T.STATE.tab = 'suivi';
    T.STATE.filters.calView = 'month';
    T.openCalendar(); await E.tick(60);
    T.openSeriesAgenda('B'); await E.tick(20);
    D.querySelector('[data-act="cal-sa-focus"]').click(); await E.tick(30);
    assert.equal(T.STATE.serieAgenda, null);
    assert.equal(T.STATE.filters.calView, 'agenda'); assert.equal(T.STATE.filters.calHorizon, 365);
    assert.equal(T.calUi().q, 'Bravo');
    const titles = [...D.querySelectorAll('.crrav-calcard .crrav-calttl')].map((n) => n.textContent);
    assert.ok(titles.length && titles.every((t) => t === 'Bravo'));
  });
  test('.ics de la série : un VEVENT par épisode daté, rien des autres séries', async () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 8 }), mk('B', 'Bravo')];
    const m = T.calSeriesModel('A', E.now());
    const { text, count } = T.calBuildIcs(m.events, E.now());
    assert.equal(count, m.events.length);
    assert.doesNotMatch(text, /Bravo/);
  });
  test('depuis la fiche série Crunchyroll (panneau fermé) : ouvre le panneau sur le calendrier avec la fiche', async () => {
    T.STATE.series = [mk('A', 'Alpha')]; T.STATE.tab = 'suivi';
    T.openSeriesAgenda('A'); await E.tick(60);
    assert.equal(T.STATE.tab, 'calendrier');
    assert.ok(D.querySelector('.crrav-sa'));
  });
  test('bouton agenda sur les cartes du panneau : séries en diffusion seulement, jamais les ignorées', () => {
    const a = mk('A', 'Alpha'); a.airing = true;
    const b = mk('B', 'Bravo', { noNext: true }); b.airing = false;
    assert.match(T.agendaBtn(a), /data-act="cal-series" data-id="A"/);
    assert.equal(T.agendaBtn(b), '');
    T.toggleIgnored(a.id, { title: 'Alpha', source: 'watchlist' });
    assert.equal(T.agendaBtn(a), '');
    assert.equal(T.agendaBtn(null), '');
  });
  test('fiche série Crunchyroll : bouton « Agenda des prochaines sorties » dans le tableau de bord', () => {
    const src = require('fs').readFileSync(process.env.CRRAV_SCRIPT || require('path').join(__dirname, '..', 'script.js'), 'utf8');
    assert.match(src, /data-crrav-seriesag="\$\{escapeHtml\(sid\)\}"/);
  });
});

describe('options et résumé : feuille plein écran', () => {
  async function openCal() {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo')]; T.STATE.tab = 'suivi';
    T.openCalendar(); await E.tick(60);
  }
  test('le bouton réglages ouvre une feuille hors de la page (pas de bloc inséré dans le calendrier)', async () => {
    await openCal();
    D.querySelector('.crrav-calsidebtn').click(); await E.tick(20);
    const sheet = D.querySelector('.crrav-modals .crrav-sa-opts');
    assert.ok(sheet, 'feuille dans .crrav-modals');
    assert.equal(D.querySelector('.crrav-cal .crrav-sa-opts'), null);
    assert.equal(D.querySelector('.crrav-calaside.open'), null);
    assert.match(sheet.textContent, /Résumé de la période/); assert.match(sheet.textContent, /Affichage/);
  });
  test('✕, fond et bouton Fermer referment ; une option change la vue sans fermer', async () => {
    await openCal();
    for (const sel of ['.crrav-sa-x2', '.crrav-sa-bg', '.crrav-sa-opts .crrav-sa-foot button']) {
      D.querySelector('.crrav-calsidebtn').click(); await E.tick(20);
      D.querySelector(sel).click(); await E.tick(20);
      assert.equal(D.querySelector('.crrav-sa-opts'), null, sel);
    }
    D.querySelector('.crrav-calsidebtn').click(); await E.tick(20);
    D.querySelector('.crrav-sa-opts [data-k="calShowEst"]').click(); await E.tick(20);
    assert.equal(T.STATE.filters.calShowEst, true);
    assert.ok(D.querySelector('.crrav-sa-opts'), 'reste ouverte');
  });
  test('Échap ferme la feuille avant le panneau ; un jour du mini-mois la ferme', async () => {
    await openCal();
    D.querySelector('.crrav-calsidebtn').click(); await E.tick(20);
    D.dispatchEvent(new E.w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); await E.tick(20);
    assert.equal(D.querySelector('.crrav-sa-opts'), null);
    assert.ok(D.querySelector('.crrav-overlay').style.display !== 'none');
    D.querySelector('.crrav-calsidebtn').click(); await E.tick(20);
    const day = D.querySelector('.crrav-sa-opts .crrav-calcell.has');
    if (day) { day.click(); await E.tick(20); assert.equal(D.querySelector('.crrav-sa-opts'), null); }
  });
  test('CSS : plein écran mobile, fenêtre ≥700 px, masquée ≥1160 px (panneau permanent)', () => {
    assert.match(T.CSS, /\.crrav-sa-opts \.crrav-sa-sheet\{[^}]*height:100dvh/);
    assert.match(T.CSS, /@media \(min-width:1160px\)\{\.crrav-sa\.crrav-sa-opts\{display:none\}\}/);
    assert.doesNotMatch(T.CSS, /\.crrav-calaside\.open\{display:flex\}/);
  });
});
