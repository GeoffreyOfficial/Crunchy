'use strict';
// Rendus : pas de « saut » visuel pendant un rafraîchissement (v3.85 / v3.86 / v3.87),
// et rendu robuste des cartes sur des données réelles ou incomplètes (instantanés anciens).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.filters.suiviGroupBy = true; T.STATE.filters.view = 'grid'; });
afterEach(() => E.close());
const q = (html, sel) => E.html(html).querySelectorAll(sel);
const started = () => series('A', [ep(1, 1, { seen: true }), ep(1, 2)], { title: 'Commencée' });
const fresh0 = () => series('B', [ep(1, 1), ep(1, 2)], { title: 'Pas commencée' });
const done = () => series('C', [ep(1, 1, { seen: true })], { title: 'Finie' });

describe('Reste à voir pendant un chargement', () => {
  test('rafraîchissement depuis un instantané : sections conservées (v3.85.0)', () => {
    T.STATE.series = [started(), fresh0(), done()];
    T.STATE.loading = true; T.STATE.fromSnapshot = true;
    const h = T.renderSuivi();
    assert.equal(q(h, '.crrav-group').length, 3);
    assert.equal(q(h, '.crrav-skel').length, 0, 'pas de squelettes sous des cartes valides');
  });
  test('scan à froid en cours : les séries déjà arrivées sont groupées tout de suite (v3.87.0)', () => {
    T.STATE.series = [started()];
    T.STATE.loading = true; T.STATE.fromSnapshot = false;
    const h = T.renderSuivi();
    assert.equal(q(h, '.crrav-group').length, 1);
    assert.equal(q(h, '.crrav-skel').length, 0);
  });
  test('rien encore arrivé : squelettes', () => {
    T.STATE.series = []; T.STATE.loading = true;
    assert.ok(q(T.renderSuivi(), '.crrav-skel').length > 0);
  });
  test('erreur affichée avec bouton Réessayer', () => {
    T.STATE.series = []; T.STATE.loading = false; T.STATE.error = 'boom';
    const d = E.html(T.renderSuivi());
    assert.match(d.textContent, /boom/);
    assert.ok(d.querySelector('[data-act="retry"]'));
  });
});

describe('Hors listes pendant un rafraîchissement (v3.86.0)', () => {
  test('cartes existantes gardées, progression en pied', () => {
    T.STATE.orphan.series = [started(), fresh0()];
    T.STATE.orphan.loading = true; T.STATE.orphan.fromSnapshot = true;
    const h = T.renderOrphelines();
    assert.equal(q(h, '.crrav-skel').length, 0);
    assert.match(E.html(h).textContent, /dernier état connu/);
  });
  test('liste vide en chargement : squelettes', () => {
    T.STATE.orphan.series = []; T.STATE.orphan.loading = true;
    assert.ok(q(T.renderOrphelines(), '.crrav-skel').length > 0);
  });
});

describe('robustesse des cartes', () => {
  const variants = () => [
    started(), fresh0(), done(),
    series('JJK', [...Array.from({ length: 24 }, (_, i) => ep(1, i + 1, { seen: true })), ep(2, 1, { dur: 6000, seen: true, title: 'JJK 0' }), ep(3, 1)], { airing: true, plannedTotal: 23, targetSeason: 3, seasonEndTs: E.now() + 9e8 }),
    series('LONG', Array.from({ length: 150 }, (_, i) => ep(1, i + 1, { seen: i < 40 }))),
    { ...series('OLD', [ep(1, 1, { seen: true }), ep(1, 2)]), next: { season: 1, n: 2 } },   // instantané d'avant v3.99 (sans id)
    series('<script>', [ep(1, 1)], { title: '<img src=x onerror=alert(1)>' }),
  ];
  test('card() rend toutes les variantes sans lever', () => {
    variants().forEach((s, i) => { const h = T.card(s, i, 'watchlist'); assert.ok(h.length > 50, s.id); });
  });
  test('listRow() idem (vue liste)', () => {
    variants().forEach((s) => assert.ok(T.listRow(s, 'watchlist').length > 50, s.id));
  });
  test('les titres sont échappés (pas d’injection HTML)', () => {
    const d = E.html(T.card(variants()[6], 0, 'watchlist'));
    assert.equal(d.querySelector('img[onerror]'), null);
  });
  test('carte Découverte : rend avec et sans profil/tags/notes', () => {
    const c = { id: 'D', title: 'Candidate', slug: 'c', poster: '', synopsis: '', categories: ['Action'], tags: [{ name: 'Magic', rank: 80 }], rating: 4.5, aniScore: 80, aniMatched: true, episodes: 12, secTotal: 17280, seasons: 1 };
    assert.ok(T.discoverCard(c, T.buildTasteProfile()).length > 50);
    assert.ok(T.discoverCard({ ...c, tags: [], rating: null, aniScore: null, aniMatched: false }, null).length > 50);
  });
});
