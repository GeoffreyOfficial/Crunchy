'use strict';
// Rendus : pas de « saut » visuel pendant un rafraîchissement (v3.85 / v3.86 / v3.87),
// et rendu robuste des cartes sur des données réelles ou incomplètes (instantanés anciens).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.filters.suiviGroupBy = true; T.STATE.filters.view = 'grid'; });
afterEach(() => E.close());
const q = (html, sel) => E.html(html).querySelectorAll(sel);
const started = () => series('A', [ep(1, 1, { seen: true }), ep(1, 2)], { title: 'Commencée' });
const fresh0 = () => series('B', [ep(1, 1), ep(1, 2)], { title: 'Pas commencée' });
const done = () => series('C', [ep(1, 1, { seen: true })], { title: 'Finie' });

describe('Reste à voir pendant un chargement', () => {
  test('rafraîchissement depuis un instantané : sections conservées (v3.85.0)', () => {
    T.STATE.series = [started(), fresh0(), done()];
    T.STATE.loading = true; T.STATE.fromSnapshot = true;
    const h = T.renderSuivi();
    assert.equal(q(h, '.crrav-group').length, 3);
    assert.equal(q(h, '.crrav-skel').length, 0, 'pas de squelettes sous des cartes valides');
  });
  test('scan à froid en cours : les séries déjà arrivées sont groupées tout de suite (v3.87.0)', () => {
    T.STATE.series = [started()];
    T.STATE.loading = true; T.STATE.fromSnapshot = false;
    const h = T.renderSuivi();
    assert.equal(q(h, '.crrav-group').length, 1);
    assert.equal(q(h, '.crrav-skel').length, 0);
  });
  test('rien encore arrivé : squelettes', () => {
    T.STATE.series = []; T.STATE.loading = true;
    assert.ok(q(T.renderSuivi(), '.crrav-skel').length > 0);
  });
  test('erreur affichée avec bouton Réessayer', () => {
    T.STATE.series = []; T.STATE.loading = false; T.STATE.error = 'boom';
    const d = E.html(T.renderSuivi());
    assert.match(d.textContent, /boom/);
    assert.ok(d.querySelector('[data-act="retry"]'));
  });
});

describe('Hors listes pendant un rafraîchissement (v3.86.0)', () => {
  test('cartes existantes gardées, progression en pied', () => {
    T.STATE.orphan.series = [started(), fresh0()];
    T.STATE.orphan.loading = true; T.STATE.orphan.fromSnapshot = true;
    const h = T.renderOrphelines();
    assert.equal(q(h, '.crrav-skel').length, 0);
    assert.match(E.html(h).textContent, /dernier état connu/);
  });
  test('liste vide en chargement : squelettes', () => {
    T.STATE.orphan.series = []; T.STATE.orphan.loading = true;
    assert.ok(q(T.renderOrphelines(), '.crrav-skel').length > 0);
  });
});

describe('robustesse des cartes', () => {
  const variants = () => [
    started(), fresh0(), done(),
    series('JJK', [...Array.from({ length: 24 }, (_, i) => ep(1, i + 1, { seen: true })), ep(2, 1, { dur: 6000, seen: true, title: 'JJK 0' }), ep(3, 1)], { airing: true, plannedTotal: 23, targetSeason: 3, seasonEndTs: E.now() + 9e8 }),
    series('LONG', Array.from({ length: 150 }, (_, i) => ep(1, i + 1, { seen: i < 40 }))),
    { ...series('OLD', [ep(1, 1, { seen: true }), ep(1, 2)]), next: { season: 1, n: 2 } },   // instantané d'avant v3.99 (sans id)
    series('<script>', [ep(1, 1)], { title: '<img src=x onerror=alert(1)>' }),
  ];
  test('card() rend toutes les variantes sans lever', () => {
    variants().forEach((s, i) => { const h = T.card(s, i, 'watchlist'); assert.ok(h.length > 50, s.id); });
  });
  test('listRow() idem (vue liste)', () => {
    variants().forEach((s) => assert.ok(T.listRow(s, 'watchlist').length > 50, s.id));
  });
  test('les titres sont échappés (pas d’injection HTML)', () => {
    const d = E.html(T.card(variants()[6], 0, 'watchlist'));
    assert.equal(d.querySelector('img[onerror]'), null);
  });
  test('carte Découverte : rend avec et sans profil/tags/notes', () => {
    const c = { id: 'D', title: 'Candidate', slug: 'c', poster: '', synopsis: '', categories: ['Action'], tags: [{ name: 'Magic', rank: 80 }], rating: 4.5, aniScore: 80, aniMatched: true, episodes: 12, secTotal: 17280, seasons: 1 };
    assert.ok(T.discoverCard(c, T.buildTasteProfile()).length > 50);
    assert.ok(T.discoverCard({ ...c, tags: [], rating: null, aniScore: null, aniMatched: false }, null).length > 50);
  });
});

describe('recherche principale : le clavier ne se ferme plus en tapant (v4.9.1)', () => {
  function mount() {
    const content = E.w.document.createElement('div');
    content.className = 'crrav-content';
    content.innerHTML = '<div class="crrav-head">h</div><div class="crrav-globalrow"><input class="crrav-search crrav-search-global" value="mas"></div><div class="res">ancien</div>';
    E.w.document.body.appendChild(content);
    const input = content.querySelector('.crrav-search-global');
    input.focus();
    return { content, input };
  }
  const next = '<div class="crrav-head">h2</div><div class="crrav-globalrow"><input class="crrav-search crrav-search-global" value="mash"><button class="crrav-globalclear">✕</button></div><div class="res">nouveau</div>';
  test('le champ en cours de saisie est le MÊME nœud après le rendu, toujours focalisé', () => {
    const { content, input } = mount();
    T.replaceContentKeepingSearch(content, next);
    assert.equal(content.querySelector('.crrav-search-global'), input);
    assert.equal(E.w.document.activeElement, input);
    assert.equal(content.querySelector('.res').textContent, 'nouveau');
    assert.equal(content.querySelector('.crrav-head').textContent, 'h2');
    assert.ok(content.querySelector('.crrav-globalclear'), 'bouton effacer ajouté');
    assert.equal(content.children[1].className, 'crrav-globalrow', 'ordre conservé');
  });
  test('champ non focalisé : remplacement complet classique', () => {
    const { content, input } = mount();
    input.blur();
    T.replaceContentKeepingSearch(content, next);
    assert.notEqual(content.querySelector('.crrav-search-global'), input);
  });
});

describe('recherche globale dans l’interface réelle (v4.12.2 : clavier + 1re lettre seulement)', () => {
  async function openUi() {
    E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
    E.net.on(/anilist/, () => ({ data: {} }));
    T.CFG.showSearchBar = true;
    T.open();
    await E.tick(150);
    T.STATE.loading = false;
    T.STATE.series = [series('F1', [ep(1, 1, { seen: true }), ep(1, 2)], { title: 'Fate/Zero' }), series('F2', [ep(1, 1)], { title: 'Frieren' })];
    T.renderNow();
    return E.w.document;
  }
  const typeIn = async (input, v) => { input.value = v; input.dispatchEvent(new E.w.Event('input', { bubbles: true })); await E.tick(260); };
  const shown = (doc) => ['Fate/Zero', 'Frieren'].filter((t) => doc.querySelector('.crrav-content').textContent.includes(t));
  test('le champ (imbriqué dans .crrav-top) reste le même nœud, focalisé, à chaque lettre', async () => {
    const doc = await openUi();
    const input = doc.querySelector('.crrav-search-global');
    assert.notEqual(input.parentNode.parentNode, doc.querySelector('.crrav-content'), 'cas réel : ligne non directe');
    input.focus();
    for (const v of ['f', 'fa', 'fat', 'fate']) {
      await typeIn(input, v);
      assert.equal(doc.querySelector('.crrav-search-global'), input, `« ${v} » : nœud recréé (clavier fermé)`);
      assert.equal(doc.activeElement, input, `« ${v} » : focus perdu`);
    }
  });
  test('chaque lettre, retour arrière compris, change les résultats', async () => {
    const doc = await openUi();
    const input = doc.querySelector('.crrav-search-global');
    input.focus();
    await typeIn(input, 'f');    assert.deepEqual(shown(doc), ['Fate/Zero', 'Frieren']);
    await typeIn(input, 'fa');   assert.deepEqual(shown(doc), ['Fate/Zero']);
    await typeIn(input, 'fate'); assert.deepEqual(shown(doc), ['Fate/Zero']);
    await typeIn(input, 'f');    assert.deepEqual(shown(doc), ['Fate/Zero', 'Frieren']);
    await typeIn(input, 'fr');   assert.deepEqual(shown(doc), ['Frieren']);
  });
  test('après un rendu complet (champ non focalisé), le nouveau champ est bien câblé', async () => {
    const doc = await openUi();
    let input = doc.querySelector('.crrav-search-global');
    input.focus();
    await typeIn(input, 'f');
    input.blur();
    T.renderNow();                                   // remplacement complet
    input = doc.querySelector('.crrav-search-global');
    input.focus();
    await typeIn(input, 'fr');
    assert.equal(T.STATE.filters.globalQ, 'fr');
    assert.deepEqual(shown(doc), ['Frieren']);
  });
  test('rendu avec un autre champ focalisé : aucun plantage (CSS masqué par la feuille de style)', () => {
    assert.equal(typeof T.CSS, 'string', 'la constante CSS du script masque bien l’API du navigateur');
    assert.equal(T.cssEscape('a b'), 'a\\ b');
    assert.doesNotThrow(() => T.cssEscape('crrav-search'));
  });
});
