'use strict';
// v4.22.0 — Le calendrier montre AUSSI le passé : épisodes déjà sortis (vus / pas vus), semaine glissante,
// navigation arrière, règle « NEW », libellés SxEy, note, image wide, périmètre « Tout Crunchyroll ».
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

// Série dont les épisodes sont sortis aux jours donnés (en jours avant « maintenant »), `seen` premiers épisodes vus.
function mk(id, title, daysAgo, o = {}) {
  const now = E.now();
  const eps = daysAgo.map((d, i) => {
    const air = now - d * DAY;
    return { season: o.season ?? 1, n: (o.startN ?? 1) + i, id: `${id}e${i + 1}`, ids: [`${id}e${i + 1}`], dur: 1440, air, avail: air, title: '' };
  });
  const ph = new Map(eps.slice(0, o.seen ?? eps.length).map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), o.rating ?? null, 0, ph, null);
  s.poster = o.poster || '';
  if (o.wide) s.wide = o.wide;
  if (o.aniScore != null) s.aniScore = o.aniScore;
  return s;
}
const base = (over = {}) => ({ view: 'week', weekMode: 'calendar', horizon: 90, filter: 'all', flags: [], proj: true, est: false, onlyCr: true, scope: 'mine', confirmed: false, q: '', ...over });
const outs = (m) => m.events.filter((e) => e.type === 'out');

describe('RÉGRESSION : la semaine montre les épisodes déjà sortis', () => {
  test('les jours passés de la semaine en cours ne sont pas vides', () => {
    // T0 = dimanche 4 oct. 2026 12:00Z. Épisodes sortis il y a 6, 4, 2 jours et 1 h.
    T.STATE.series = [mk('A', 'Alpha', [13, 6, 4, 2, 0.05])];
    const m = T.calModel(base(), E.now());
    const days = new Set(outs(m).map((e) => T.calDayKey(e.ts)));
    assert.ok(outs(m).length >= 3, 'plusieurs sorties de la semaine, pas seulement aujourd’hui : ' + outs(m).length);
    assert.ok(days.size >= 3, 'réparties sur plusieurs jours');
  });
  test('une série sans épisode « de retard » mais sortie lundi apparaît bien lundi', () => {
    const now = E.now();
    const monday = T.calWeekStart(now) + 10 * 3600e3;
    const s = mk('B', 'Bravo', [20]);
    s.episodes.push({ season: 1, n: 2, id: 'Be2', ids: ['Be2'], dur: 1440, air: monday, avail: monday, seen: true, title: '' });
    T.STATE.series = [s];
    const m = T.calModel(base(), now);
    assert.ok(outs(m).some((e) => e.ts === monday), 'épisode de lundi présent');
  });
});

const ANI = /graphql\.anilist\.co/;
const html = () => E.html(T.renderCalendrier());

describe('semaine glissante, navigation vers le passé', () => {
  test('glissante (défaut) : 3 jours avant aujourd’hui → 3 jours après, 7 jours exactement', () => {
    T.STATE.filters.calView = 'week';
    const o = T.calOpts();
    assert.equal(o.weekMode, 'rolling');
    const r = T.calRange(o, E.now());
    assert.equal(r.start, T.calAddDays(T.calStartOfDay(E.now()), -3));
    assert.equal(r.end - r.start, 7 * DAY);
  });
  test('mode lundi → dimanche conservé en option, persisté, validé', () => {
    T.STATE.filters.calView = 'week'; T.STATE.filters.calWeekMode = 'calendar';
    assert.equal(new Date(T.calRange(T.calOpts(), E.now()).start).getDay(), 1);
    T.STATE.filters.calWeekMode = 'n’importe quoi';
    assert.equal(T.calOpts().weekMode, 'rolling');
  });
  test('navigation : ‹ remonte dans le passé, borne à 26 semaines / 12 mois, bouton désactivé à la borne, « Aujourd’hui » ramène', () => {
    T.STATE.series = [mk('A', 'Alpha', [3, 1])];
    T.STATE.filters.calView = 'week';
    const D = E.w.document; T.openCalendar();
    for (let i = 0; i < 40; i++) T.calHandleAct({ dataset: { act: 'cal-nav', d: '-1' } });
    assert.equal(T.calUi().off, -26);
    assert.match(T.renderCalendrier(), /data-d="-1"[^>]*disabled/);
    T.calHandleAct({ dataset: { act: 'cal-today' } });
    assert.equal(T.calUi().off, 0);
    T.STATE.filters.calView = 'month';
    for (let i = 0; i < 40; i++) T.calHandleAct({ dataset: { act: 'cal-nav', d: '-1' } });
    assert.equal(T.calUi().off, -12);
    assert.ok(T.renderCalendrier().includes('Aujourd’hui'), 'bouton retour affiché quand on est dans le passé');
  });
  test('semaine passée : les épisodes sortis cette semaine-là sont là, avec l’état vu / pas vu de l’époque', () => {
    T.STATE.series = [mk('A', 'Alpha', [20, 13, 6], { seen: 2 })];   // sorties il y a 20, 13, 6 jours
    T.STATE.filters.calView = 'week';
    T.calUi().off = -1;                                              // semaine précédente (glissante)
    const m = T.calModel(T.calOpts(), E.now());
    const out = outs(m);
    assert.equal(out.length, 1);
    assert.equal(out[0].n, 3);
    assert.equal(out[0].seen, false);
  });
  test('mois précédent : les sorties du mois dernier apparaissent', () => {
    T.STATE.series = [mk('A', 'Alpha', [40, 33, 26, 5])];
    T.STATE.filters.calView = 'month'; T.calUi().off = -1;
    const m = T.calModel(T.calOpts(), E.now());
    assert.ok(outs(m).length >= 2);
    assert.ok(m.events.every((e) => T.calMonthKey(e.ts) === T.calMonthKey(m.range.start)));
  });
});

describe('NEW : épisode 1 ou précédent diffusé il y a plus d’un mois', () => {
  const o = () => base({ view: 'agenda', horizon: 365, weekMode: 'rolling' });
  const run = () => outs(T.calModel(base({ view: 'month', weekMode: 'rolling' }), E.now())).concat([]);
  test('épisode 1 → NEW ; épisodes réguliers → pas NEW', () => {
    T.STATE.series = [mk('A', 'Alpha', [9, 2, 1.5])];
    const ev = T.calReleasedEvents(E.now(), E.now() - 30 * DAY, E.now() + 1);
    const byN = Object.fromEntries(ev.map((e) => [e.n, e.isNew]));
    assert.deepEqual(plain(byN), { 1: true, 2: false, 3: false });
  });
  test('précédent il y a 31 j → NEW ; il y a exactement 30 j → pas NEW', () => {
    T.STATE.series = [mk('A', 'Alpha', [40, 8, 7], { startN: 5 })];     // E5 (-40 j), E6 (-8 j : écart 32 j), E7 (-7 j)
    let ev = T.calReleasedEvents(E.now(), E.now() - 20 * DAY, E.now() + 1);
    assert.deepEqual(plain(ev.map((e) => [e.abs, e.isNew])), [[6, true], [7, false]]);
    T.STATE.series = [mk('B', 'Bravo', [40, 10, 9], { startN: 5 })];    // écart exactement 30 j
    ev = T.calReleasedEvents(E.now(), E.now() - 20 * DAY, E.now() + 1);
    assert.deepEqual(plain(ev.map((e) => [e.abs, e.isNew])), [[6, false], [7, false]]);
  });
  test('1er épisode d’une nouvelle saison (numérotation par saison) → NEW', () => {
    const s = mk('A', 'Alpha', [60, 53, 3, 2]);
    s.episodes[2].season = 2; s.episodes[2].n = 13; s.episodes[3].season = 2; s.episodes[3].n = 14;
    T.STATE.series = [s];
    const ev = T.calReleasedEvents(E.now(), E.now() - 10 * DAY, E.now() + 1);
    assert.equal(ev[0].isNew, true);
    assert.equal(ev[1].isNew, false);
  });
  test('épisode à venir : NEW si son précédent est à plus d’un mois, ou épisode 1', () => {
    const s = mk('A', 'Alpha', [50, 49], { total: 12 });
    s.aniNextTs = E.now() + 2 * DAY; s.aniNextNum = 3;
    T.STATE.series = [s];
    const m = T.calModel(base({ view: 'agenda', horizon: 30 }), E.now());
    const first = m.events.find((e) => e.type === 'ep');
    assert.equal(first.isNew, true, 'reprise après une longue pause');
    assert.equal(m.events.filter((e) => e.type === 'ep' && e.isNew).length, 1, 'les suivants (une semaine après) ne sont pas NEW');
  });
  test('filtre NEW : ne garde que ces épisodes ; l’affichage porte la pastille NEW', () => {
    T.STATE.series = [mk('A', 'Alpha', [3.5, 2, 1.5]), mk('B', 'Bravo', [2.5])];
    T.STATE.filters.calView = 'week';
    const m = T.calModel(base({ flags: ['new'], view: 'week', weekMode: 'rolling' }), E.now());
    assert.ok(m.events.length >= 2 && m.events.every((e) => e.isNew));
    const dom = html();
    assert.ok(dom.querySelector('.crrav-calcard .crrav-calnew'));
  });
});

describe('SxEy, note, image wide', () => {
  test('S{rang réel}E{n par saison} même quand Crunchyroll numérote en continu', () => {
    const s = mk('A', 'Alpha', [30, 23, 3, 2]);
    s.episodes[0].season = 5; s.episodes[0].n = 1; s.episodes[1].season = 5; s.episodes[1].n = 2;
    s.episodes[2].season = 12; s.episodes[2].n = 1; s.episodes[3].season = 12; s.episodes[3].n = 2;   // saisons « 5 » et « 12 » → S1, S2
    T.STATE.series = [s];
    const ev = T.calReleasedEvents(E.now(), E.now() - 10 * DAY, E.now() + 1);
    assert.deepEqual(plain(ev.map((e) => e.sxe)), ['S2E1', 'S2E2']);
    const ev1 = T.calReleasedEvents(E.now(), E.now() - 40 * DAY, E.now() - 20 * DAY);
    assert.deepEqual(plain(ev1.map((e) => e.sxe)), ['S1E1', 'S1E2']);
  });
  test('une saison unique s’écrit quand même S1Ey', () => {
    T.STATE.series = [mk('A', 'Alpha', [2, 1])];
    assert.deepEqual(plain(T.calReleasedEvents(E.now(), E.now() - 5 * DAY, E.now() + 1).map((e) => e.sxe)), ['S1E1', 'S1E2']);
  });
  test('la carte affiche SxEy, le titre en petit sur l’image, la note et l’image wide', () => {
    T.STATE.series = [mk('A', 'Alpha', [2, 1], { rating: 4.66, wide: 'https://img/wide.jpg', poster: 'https://img/tall.jpg' })];
    T.STATE.filters.calView = 'week';
    const card = [...html().querySelectorAll('.crrav-calcard.out')].pop();
    assert.ok(card);
    assert.equal(card.querySelector('.crrav-calsx').textContent, 'S1 · E2');
    assert.equal(card.querySelector('.crrav-calp .crrav-calttl').textContent, 'Alpha');
    assert.equal(card.querySelector('.crrav-calstar').textContent, '★ 4.7');
    assert.equal(card.querySelector('.crrav-calp img').getAttribute('src'), 'https://img/wide.jpg');
    assert.ok(!card.querySelector('.crrav-calp img.tall'));
  });
  test('sans image wide : l’affiche recadrée (classe tall) ; sans rien : une initiale', () => {
    T.STATE.series = [mk('A', 'Alpha', [1], { poster: 'https://img/tall.jpg' }), mk('B', 'Bravo', [1.2])];
    T.STATE.filters.calView = 'week';
    const cards = [...html().querySelectorAll('.crrav-calcard.out')];
    assert.ok(cards.some((c) => c.querySelector('.crrav-calp img.tall')));
    assert.ok(cards.some((c) => c.querySelector('.crrav-calp .crrav-calini')));
  });
  test('note : note du public Crunchyroll, sinon AniList /20, sinon rien', () => {
    const a = mk('A', 'Alpha', [1], { rating: 4.5 }), b = mk('B', 'Bravo', [1], { aniScore: 84 }), c = mk('C', 'Charlie', [1]);
    assert.equal(T.calScoreOf(a), 4.5); assert.equal(T.calScoreOf(b), null, 'jamais la note AniList à la place de Crunchyroll'); assert.equal(T.calAniScoreOf(b), 4.2); assert.equal(T.calScoreOf(c), null);
    T.STATE.series = [c];
    assert.ok(!html().querySelector('.crrav-calcard .crrav-calstar'));
  });
  test('buildSeriesEntry récupère l’image wide de la fiche Crunchyroll', () => {
    const panel = { id: 'W', title: 'W', slug_title: 'w', series_metadata: { tenant_categories: [] },
      images: { poster_tall: [[{ width: 240, height: 360, source: 'https://img/t.jpg' }]], poster_wide: [[{ width: 320, height: 180, source: 'https://img/w320.jpg' }, { width: 1200, height: 675, source: 'https://img/w1200.jpg' }]] } };
    const eps = [{ season: 1, n: 1, id: 'x', ids: ['x'], dur: 1, air: E.now() - DAY, avail: E.now() - DAY, title: '' }];
    const s = T.buildSeriesEntry(panel, eps, E.now(), null, 0, new Map(), null);
    assert.equal(s.wide, 'https://img/w1200.jpg');
    assert.equal(T.posterWideOf({}), '');
  });
});

describe('vu / pas vu : différenciés partout', () => {
  test('événements : seen, started ; cartes : classes seen / unseen + pastilles « ✓ Vu » / « À voir »', () => {
    T.STATE.series = [mk('A', 'Alpha', [3, 2, 1], { seen: 2 })];
    const m = T.calModel(base({ view: 'month' }), E.now());
    const o = outs(m).sort((a, b) => a.n - b.n);
    assert.deepEqual(plain(o.map((e) => e.seen)), [true, true, false]);
    const dom = html();
    T.STATE.filters.calView = 'week';
    const d2 = html();
    assert.equal(d2.querySelectorAll('.crrav-calcard.out.seen').length, 2);
    assert.equal(d2.querySelectorAll('.crrav-calcard.out.unseen').length, 1);
    assert.match(d2.querySelector('.crrav-calcard.out.unseen .crrav-calvu.todo').textContent, /À voir/);
    assert.match(d2.querySelector('.crrav-calcard.out.seen .crrav-calvu:not(.todo)').textContent, /Vu/);
    assert.ok(dom);
  });
  test('CSS : « vu » = image grise et assombrie, « pas vu » = image vive avec filet orange', () => {
    const css = T.CSS.replace(/\s+/g, ' ');
    assert.match(css, /\.crrav-calcard\.out\.seen \.crrav-calp img[^{]*\{filter:grayscale\(1\)/);
    assert.match(css, /\.crrav-calcard\.out\.unseen\{box-shadow:inset 0 -3px 0 #f47521/);
  });
  test('filtres « À voir » (sortis pas vus) et « Vus » : exacts', () => {
    T.STATE.series = [mk('A', 'Alpha', [3, 2, 1], { seen: 2 }), mk('B', 'Bravo', [2, 1], { seen: 2 })];
    const u = T.calModel(base({ view: 'month', filter: 'unseen' }), E.now());
    assert.deepEqual(plain(u.events.map((e) => e.id + e.n)), ['A3']);
    const v = T.calModel(base({ view: 'month', filter: 'seen' }), E.now());
    assert.deepEqual(plain(v.events.map((e) => e.id + e.n).sort()), ['A1', 'A2', 'B1', 'B2']);
    assert.equal(u.counts.unseen, 1); assert.equal(u.counts.seen, 4);
  });
  test('un épisode marqué « vu » ensuite bascule bien de À voir à Vu', () => {
    const s = mk('A', 'Alpha', [2, 1], { seen: 0 });
    T.STATE.series = [s];
    assert.equal(T.calModel(base({ view: 'month', filter: 'unseen' }), E.now()).events.length, 2);
    s.episodes[0].seen = true;
    const m = T.calModel(base({ view: 'month', filter: 'unseen' }), E.now());
    assert.equal(m.events.length, 1);
  });
});

// ── (v4.24.0) Catalogue Crunchyroll : fixtures partagées ───────────────────────────────────────────────────────────
const crPanel = (id, title, o = {}) => ({ id, title, slug_title: title.toLowerCase().replace(/\W+/g, '-'), description: 'Synopsis ' + title,
  images: { poster_tall: [[{ width: 240, height: 360, source: 'https://img/' + id + '-t.jpg' }]], poster_wide: [[{ width: 1200, height: 675, source: 'https://img/' + id + '-w.jpg' }]] },
  series_metadata: { tenant_categories: o.cats || ['Comédie'] } });
// newly : panels du catalogue « ajouté récemment » ; season : { 'fall-2026': [panels] } ; eps : { id: { S1: [[n, ts]], S2: [[n, ts]] } } (saisons dans l'ordre des clés).
function mockCr({ newly = [], season = {}, eps = {}, browseFail = false } = {}) {
  const calls = { browse: [], fail: !!browseFail };      // calls.fail = true : le catalogue tombe en panne (les routes déjà déclarées gagnent : on les pilote)
  E.net.on(/\/content\/v2\/discover\/browse/, (u) => {
    const q = new URL(u).searchParams; calls.browse.push(Object.fromEntries(q));
    if (calls.fail) return { __status: 500, body: 'boom' };
    const tag = q.get('seasonal_tag');
    return { data: tag ? (season[tag] || []) : newly };
  });
  E.net.on(/\/content\/v2\/cms\/series\/([^/]+)\/seasons/, (u) => {
    const id = u.match(/series\/([^/]+)\/seasons/)[1];
    const keys = Object.keys(eps[id] || { S1: [] }).sort();
    return { data: keys.map((k, i) => ({ id: k + '-' + id, title: 'Saison ' + (i + 1), season_number: i + 1, season_sequence_number: i + 1, series_title: id })) };
  });
  E.net.on(/\/content\/v2\/cms\/seasons\/([^/?]+)\/episodes/, (u) => {
    const sid = u.match(/seasons\/([^/?]+)\/episodes/)[1];
    const k = sid.slice(0, sid.indexOf('-')), id = sid.slice(sid.indexOf('-') + 1);
    return { data: ((eps[id] || {})[k] || []).map(([n, ts]) => ({ id: `${id}-${k}e${n}`, episode_number: n, title: 'Ép ' + n, duration_ms: 1440000, season_number: 1,
      availability_starts: new Date(ts).toISOString(), episode_air_date: new Date(ts).toISOString() })) };
  });
  return calls;
}
// Catalogue de la saison : une nouvelle série, une série longue (saison 2 en cours), une série revenue de pause, + pièges.
function seasonFixture(now) {
  const eps = {
    A1: { S1: [[1, now - 2 * DAY], [2, now + 5 * DAY]] },
    B1: { S1: [[1, now - 300 * DAY], [2, now - 293 * DAY]], S2: [[1, now - 24 * DAY], [2, now - 17 * DAY], [3, now - 10 * DAY], [4, now - 3 * DAY]] },
    P1: { S1: [[1, now - 100 * DAY], [2, now - 3 * DAY]] },
    MINE: { S1: [[1, now - 3 * DAY]] }, D1: { S1: [[1, now - 3 * DAY]] }, X1: { S1: [[1, now - 3 * DAY]] }, H1: { S1: [[1, now - 3 * DAY]] },
  };
  const panels = [crPanel('A1', 'Neuve'), crPanel('B1', 'Longue Série'), crPanel('P1', 'Retour de Pause'), crPanel('MINE', 'Alpha'),
    crPanel('D1', 'Truc (Dub)'), crPanel('X1', 'Ignorée'), crPanel('H1', 'Interdit', { cats: ['Hentai'] })];
  return { eps, newly: [panels[0]], season: { 'fall-2026': panels } };
}

describe('Tout Crunchyroll : catalogue de la saison lu chez Crunchyroll (jamais AniList)', () => {
  const ANI = /graphql\.anilist\.co/;
  const air = (m) => m.events.filter((e) => e.type === 'air');
  test('étiquettes de saison Crunchyroll : la saison en cours (+ la précédente en début de saison, + celles de la période passée)', () => {
    const now = E.now();                                                       // 4 oct. 2026 : automne, début de saison
    const o = base({ view: 'week', weekMode: 'rolling' });
    assert.deepEqual(plain(T.calCrSeasonTagsFor(T.calRange(o, now), now)), ['summer-2026', 'fall-2026']);
    const late = Date.UTC(2026, 10, 30, 12);                                   // fin novembre : plus besoin de l’été
    assert.deepEqual(plain(T.calCrSeasonTagsFor({ start: late - 3 * DAY, end: late + 4 * DAY }, late)), ['fall-2026']);
    T.STATE.filters.calView = 'week'; T.calUi().off = -20;                     // ~20 semaines en arrière
    const tags = T.calCrSeasonTagsFor(T.calRange(T.calOpts(), now), now);
    assert.equal(tags[tags.length - 1], 'fall-2026'); assert.ok(tags.length <= 3 && tags.length >= 2);
  });
  test('chargement : une requête « seasonal_tag » par saison, séries hors listes seulement, doublages / ignorées / genres exclus écartés, épisodes datés lus', async () => {
    const now = E.now();
    T.STATE.series = [mk('MINE', 'Alpha', [1])];
    T.IGNORED.set('X1', { title: 'Ignorée', source: 'newpremieres', ignoredAt: 1 });
    const fx = seasonFixture(now);
    const calls = mockCr(fx);
    await T.loadCrSeason(['summer-2026', 'fall-2026']);
    const S = T.STATE.crSeason;
    assert.equal(S.error, null);
    assert.deepEqual(plain(calls.browse.map((c) => c.seasonal_tag)), ['summer-2026', 'fall-2026']);
    assert.ok(calls.browse.every((c) => c.type === 'series' && c.sort_by === 'newly_added'));
    assert.deepEqual(plain(S.items.map((i) => i.id).sort()), ['A1', 'B1', 'P1']);
    const b = S.items.find((i) => i.id === 'B1');
    assert.equal(b.rank, 2, 'dernière saison de la série');
    assert.deepEqual(plain(b.eps.map((e) => e.n)), [1, 2, 3, 4]);
    assert.equal(b.wide, 'https://img/B1-w.jpg');
  });
  test('périmètre « Tout Crunchyroll » : épisodes de la période, SxEy par saison, NEW (épisode 1 / reprise après > 1 mois) ; « Mes séries » : aucun', async () => {
    const now = E.now();
    T.STATE.series = [mk('MINE', 'Alpha', [1])];
    T.IGNORED.set('X1', { title: 'Ignorée', source: 'newpremieres', ignoredAt: 1 });
    mockCr(seasonFixture(now));
    await T.loadCrNew(); await T.loadCrSeason(['fall-2026']);
    const mine = T.calModel(base({ view: 'week', weekMode: 'rolling' }), now);
    assert.equal(air(mine).length, 0);
    assert.ok(mine.events.some((e) => e.type === 'prem' && e.id === 'A1'), 'la nouvelle série reste visible en « Mes séries »');
    const all = T.calModel(base({ view: 'week', weekMode: 'rolling', scope: 'all' }), now);
    const a = Object.fromEntries(air(all).map((e) => [e.id, e]));
    assert.deepEqual(plain(Object.keys(a).sort()), ['B1', 'P1']);
    assert.equal(a.B1.sxe, 'S2E4'); assert.equal(a.B1.isNew, false);
    assert.equal(a.P1.sxe, 'S1E2'); assert.equal(a.P1.isNew, true, 'précédent il y a plus d’un mois');
    assert.ok(all.events.every((e) => e.type !== 'air' || e.listed === false));
    assert.equal(new Set(all.events.map((e) => e.key)).size, all.events.length);
  });
  test('épisode 1 d’une nouvelle série : « nouveauté » (jamais en double avec la ligne du catalogue de la saison)', async () => {
    const now = E.now();
    mockCr(seasonFixture(now));
    await T.loadCrNew(); await T.loadCrSeason(['fall-2026']);
    const m = T.calModel(base({ view: 'month', scope: 'all' }), now);
    const a1 = m.events.filter((e) => e.id === 'A1');
    assert.deepEqual(plain(a1.map((e) => e.type + e.n)), ['prem1', 'air2']);
  });
  test('épisode 1 d’une série du catalogue de la saison (pas « nouvelle ») : épisode hors liste NEW', async () => {
    const now = E.now();
    const fx = seasonFixture(now);
    fx.eps.B1.S2 = [[1, now - 2 * DAY]];                          // la saison 2 vient de démarrer
    mockCr(fx);
    await T.loadCrSeason(['fall-2026']);
    const m = T.calModel(base({ view: 'week', weekMode: 'rolling', scope: 'all' }), now);
    const e1 = air(m).find((e) => e.id === 'B1' && e.n === 1);
    assert.ok(e1 && e1.isNew && e1.sxe === 'S2E1');
  });
  test('liens : « Regarder » ouvre directement l’épisode Crunchyroll ; ignorer une série la retire partout', async () => {
    const now = E.now();
    mockCr(seasonFixture(now));
    await T.loadCrSeason(['fall-2026']);
    const o = base({ view: 'week', weekMode: 'rolling', scope: 'all' });
    const e = air(T.calModel(o, now)).find((x) => x.id === 'B1');
    assert.equal(e.urls.watch, 'https://www.crunchyroll.com/watch/B1-S2e4');
    assert.match(e.urls.web, /series\/B1\//);
    T.IGNORED.set('B1', { title: 'Longue Série', source: 'newpremieres', ignoredAt: 1 });
    assert.ok(!air(T.calModel(o, now)).some((x) => x.id === 'B1'));
  });
  test('cache : aucune requête au 2e chargement ; panne : message clair + Réessayer, tes séries restent', async () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha', [1])];
    const calls = mockCr(seasonFixture(now));
    await T.loadCrSeason(['fall-2026']);
    const n = calls.browse.length;
    await T.loadCrSeason(['fall-2026']);
    assert.equal(calls.browse.length, n, 'cache 3 h');
    calls.fail = true;
    T.STATE.crSeason.items = []; T.invalidateCache(['crseason:']);
    await T.loadCrSeason(['fall-2026'], true);
    assert.match(T.STATE.crSeason.error, /indisponible/);
    T.STATE.filters.calView = 'week'; T.STATE.filters.calScope = 'all';
    const dom = html();
    assert.match(dom.textContent, /Réessayer/);
    assert.ok(dom.querySelector('.crrav-calcard.out'));
    assert.ok(calls.browse.length > n);
  });
  test('chargement à la demande : « Mes séries » ne lit jamais le catalogue de la saison ; « Tout Crunchyroll » le lit une seule fois', async () => {
    const calls = mockCr(seasonFixture(E.now()));
    T.STATE.series = [mk('A', 'Alpha', [1])];
    T.STATE.filters.calView = 'week';
    T.calEnsureCrSeason(); await E.tick(30);
    assert.equal(calls.browse.filter((c) => c.seasonal_tag).length, 0);
    T.STATE.filters.calScope = 'all';
    T.calEnsureCrSeason(); await E.tick(60);
    const k = calls.browse.filter((c) => c.seasonal_tag).length;
    assert.ok(k >= 1);
    T.calEnsureCrSeason(); await E.tick(30);
    assert.equal(calls.browse.filter((c) => c.seasonal_tag).length, k, 'pas de relecture en boucle');
  });
  test('réglage « Calendrier — nouvelles séries et Tout Crunchyroll » désactivé : aucune lecture du catalogue', async () => {
    T.CFG.calFutureEnabled = false;
    const calls = mockCr(seasonFixture(E.now()));
    T.STATE.filters.calScope = 'all';
    await T.loadCrNew(); await T.loadCrSeason(['fall-2026']); T.calEnsureFuture(); await E.tick(20);
    assert.equal(calls.browse.length, 0);
  });
  test('rendu : tuile image wide, SxEy, « pas dans tes listes », pas de note inventée, pas de bouton « Série », ignorable', async () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha', [1])];
    mockCr(seasonFixture(now));
    await T.loadCrSeason(['fall-2026']);
    T.STATE.filters.calView = 'week'; T.STATE.filters.calScope = 'all'; T.STATE.filters.calWeekMode = 'rolling';
    const card = [...html().querySelectorAll('.crrav-calcard.air')].find((c) => /Longue/.test(c.textContent));
    assert.ok(card);
    assert.equal(card.querySelector('.crrav-calsx').textContent, 'S2 · E4');
    assert.equal(card.querySelector('.crrav-calp img').getAttribute('src'), 'https://img/B1-w.jpg');
    assert.ok(!card.querySelector('.crrav-calstar'), 'pas de note : Crunchyroll n’en donne pas ici, on n’en invente pas');
    assert.match(card.textContent, /pas dans tes listes/);
    assert.ok(!card.querySelector('[data-act="cal-series"]'));
    assert.match(card.querySelector('[data-ignore]').outerHTML, /data-ignore="B1"[^>]*data-source="newpremieres"/);
    assert.equal(card.querySelector('[data-act="cal-link"]').getAttribute('href'), 'https://www.crunchyroll.com/watch/B1-S2e4');
  });
  test('ICS : ni épisodes déjà sortis ni diffusions passées ; les annonces futures oui', () => {
    const now = E.now();
    const out = { type: 'out', key: 'o', title: 'x', ts: now - 3600e3, precision: 'time', label: 'E1' };
    const past = { type: 'air', key: 'p', title: 'y', ts: now - 3600e3, precision: 'time', label: 'E1', sxe: 'S1E1' };
    const fut = { type: 'air', key: 'f', title: 'z', ts: now + 3600e3, precision: 'time', label: 'E1', sxe: 'S1E1' };
    const r = T.calBuildIcs([out, past, fut], now);
    assert.equal(r.count, 1);
    assert.match(r.text, /z — S1E1/);
  });
});

describe('RÉGRESSION v4.24 : Les Carnets de l’apothicaire « épisode 1 » fantôme, GelPiyo 2 qui n’existe pas', () => {
  test('un épisode dont la date a été RÉÉCRITE (E1 daté d’hier alors que E2 date de plus tôt) n’est pas une sortie d’hier', () => {
    const now = E.now();
    const s = mk('C', 'Les Carnets', [0.9, 25, 18, 0.9]);                 // E1 réécrit (hier), E2, E3 anciens, E4 vraiment sorti hier
    T.STATE.series = [s];
    const ev = T.calReleasedEvents(now, now - 3 * DAY, now + 1);
    assert.deepEqual(plain(ev.map((e) => e.abs)), [4], 'seul l’épisode 4 est sorti hier');
    T.STATE.filters.calView = 'week';
    const cards = [...html().querySelectorAll('.crrav-calcard.out')].map((c) => c.querySelector('.crrav-calsx').textContent);
    assert.deepEqual(plain(cards), ['S1 · E4']);
  });
  test('sorties groupées légitimes (plusieurs épisodes le même jour, dans l’ordre) : toutes conservées', () => {
    const now = E.now();
    T.STATE.series = [mk('B', 'Rattrapage', [30, 0.9, 0.9, 0.9])];
    const ev = T.calReleasedEvents(now, now - 3 * DAY, now + 1);
    assert.deepEqual(plain(ev.map((e) => e.abs)), [2, 3, 4]);
  });
  test('calDropRestamped : tolérance de 12 h, séries sans date, tableau vide', () => {
    const f = (a) => T.calDropRestamped(a, (x) => x.t).map((x) => x.n);
    assert.deepEqual(plain(f([])), []);
    assert.deepEqual(plain(f([{ n: 1, t: 100 * 3600e3 }, { n: 2, t: 90 * 3600e3 }])), [1, 2], '10 h d’écart : dans la tolérance, gardé');
    assert.deepEqual(plain(f([{ n: 1, t: 104 * 3600e3 }, { n: 2, t: 90 * 3600e3 }])), [2], '14 h d’écart : réécrit, écarté');
    assert.deepEqual(plain(f([{ n: 1, t: null }, { n: 2, t: 90 * 3600e3 }])), [1, 2], 'sans date : conservé tel quel');
  });
  test('rien venant d’AniList n’entre dans le calendrier : ni nouveautés, ni annonces, ni requête', async () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha', [1])];
    T.STATE.newPremieres.series = [{ id: 'ani:1', title: 'GelPiyo 2', ep1Ts: now - 3 * DAY, released: true, crId: 'GWRONG', crSlug: 'fruits-basket', crSource: 'search', categories: [] }];
    const ANI = /graphql\.anilist\.co/;
    E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: [], airingSchedules: [] } } }));
    mockCr({});
    for (const scope of ['mine', 'all']) {
      const m = T.calModel(base({ view: 'month', scope }), now);
      assert.ok(!m.events.some((e) => /GelPiyo|Fruit/i.test(e.title + JSON.stringify(e.urls || {}))), 'scope ' + scope);
    }
    T.STATE.filters.calScope = 'all'; T.STATE.filters.calView = 'week';
    T.calEnsureFuture(); html(); await E.tick(60);
    const bodies = E.net.log.filter((l) => ANI.test(l.url)).map((l) => String(l.body || ''));
    assert.ok(bodies.every((b) => /(NOT_YET_RELEASED|status: RELEASING)/.test(b) && /licensedById/.test(b)) && bodies.length <= 2, 'v4.32 : au plus deux requêtes AniList (annonces + prochains épisodes du catalogue, « Reste de Crunchyroll » étant coché) ; ' + bodies.length);
  });
  test('ouvrir le calendrier (toutes vues, tous périmètres) ne lance aucune requête AniList de nouveautés / grille de diffusion', async () => {
    const bodies = [];
    E.net.on(/graphql\.anilist\.co/, (u, o) => { bodies.push(String((o && o.body) || '')); return { data: { Page: { pageInfo: { hasNextPage: false }, media: [], airingSchedules: [] } } }; });
    mockCr(seasonFixture(E.now()));
    T.STATE.series = [mk('A', 'Alpha', [1])];
    for (const view of ['agenda', 'week', 'month']) for (const scope of ['mine', 'all']) {
      T.STATE.filters.calView = view; T.STATE.filters.calScope = scope;
      T.openCalendar(); await E.tick(60);
    }
    assert.ok(!bodies.some((b) => /airingSchedules\s*\(\s*airingAt_greater: \$from, airingAt_lesser: \$to, sort: TIME/.test(b) && !/NOT_YET_RELEASED/.test(b)), 'aucune grille de diffusion AniList');
    assert.ok(bodies.length <= 2, 'au plus deux requêtes AniList (annonces + prochains épisodes), une fois par session : ' + bodies.length);
    assert.ok(!T.SETTINGS_KEYS.includes('discoverNewPremieres'), 'réglage du bloc AniList retiré');
    assert.ok(T.SETTINGS_KEYS.includes('calFutureEnabled'));
  });
  test('une série absente de Crunchyroll (aucun épisode daté lu) n’est jamais affichée', async () => {
    const now = E.now();
    mockCr({ newly: [crPanel('N1', 'Fantôme')], eps: { N1: { S1: [] } } });
    await T.loadCrNew();
    assert.equal(T.STATE.crNew.items.length, 0);
    assert.ok(!T.calModel(base({ view: 'month', scope: 'all' }), now).events.some((e) => /Fantôme/.test(e.title)));
  });
});


describe('complétude : aucun épisode perdu', () => {
  test('propriété : pour des centaines de séries aléatoires, la semaine contient EXACTEMENT les épisodes sortis dans la fenêtre', () => {
    let seed = 12345; const rnd = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
    const list = [];
    for (let i = 0; i < 120; i++) {
      const n = 1 + Math.floor(rnd() * 14);
      const days = Array.from({ length: n }, () => rnd() * 90).sort((a, b) => b - a);
      list.push(mk('S' + i, 'Serie ' + i, days, { seen: Math.floor(rnd() * n) }));
    }
    T.STATE.series = list;
    const ignored = new Set(['S3', 'S50']); for (const id of ignored) T.IGNORED.set(id, { title: id, source: 'watchlist', ignoredAt: 1 });
    for (const off of [0, -1, -2, -5]) {
      T.STATE.filters.calView = 'week'; T.calUi().off = off;
      const m = T.calModel(base({ weekMode: 'rolling' }), E.now());
      const stop = Math.min(m.range.end, E.now() + 1);
      let expected = 0;
      for (const s of list) { if (ignored.has(s.id)) continue; for (const e of s.episodes) { const t = e.avail || e.air; if (t >= m.range.start && t < stop) expected++; } }
      assert.equal(outs(m).length, expected, `semaine ${off}`);
      assert.ok(outs(m).every((e) => !ignored.has(e.id)));
      assert.equal(new Set(m.events.map((e) => e.key)).size, m.events.length, 'aucune clé en double');
    }
  });
  test('chaque jour de la semaine glissante affiche ses épisodes (aucun jour passé vide à tort)', () => {
    const now = E.now();
    const eps = [3.2, 2.5, 1.4, 0.6, 0.1];   // un épisode par jour des 4 derniers jours + aujourd’hui
    T.STATE.series = eps.map((d, i) => mk('S' + i, 'Serie ' + i, [d]));
    T.STATE.filters.calView = 'week';
    const dom = html();
    const filled = [...dom.querySelectorAll('.crrav-agsec[data-calday]')].filter((x) => x.querySelector('.crrav-calcard')).length;
    assert.ok(filled >= 4, 'jours remplis : ' + filled);
    assert.equal(dom.querySelectorAll('.crrav-agsec').length, 7);
  });
  test('un même épisode n’apparaît jamais à la fois comme sorti et comme prévu', () => {
    const s = mk('A', 'Alpha', [14, 7, 0.1]);
    s.aniNextTs = E.now() + 7 * DAY - 0.1 * DAY; s.aniNextNum = 4; s.plannedTotal = 12;
    T.STATE.series = [s];
    const m = T.calModel(base({ view: 'agenda', horizon: 30 }), E.now());
    const nums = m.events.filter((e) => e.id === 'A').map((e) => e.abs);
    assert.equal(new Set(nums).size, nums.length, 'doublon : ' + nums);
  });
  test('séries ignorées, supprimées de la vue, et filtres/compteurs cohérents', () => {
    T.STATE.series = [mk('A', 'Alpha', [2, 1]), mk('B', 'Bravo', [2, 1])];
    T.IGNORED.set('B', { title: 'Bravo', source: 'watchlist', ignoredAt: 1 });
    const m = T.calModel(base({ view: 'month' }), E.now());
    assert.ok(m.events.every((e) => e.id === 'A'));
    assert.equal(m.counts.all, m.events.length);
    const cnt = T.calModel(base({ view: 'month', scope: 'all' }), E.now()).counts;
    for (const k of T.CAL_STATUS) assert.equal(T.calModel(base({ view: 'month', filter: k, scope: 'all' }), E.now()).events.length, cnt[k], 'compteur ' + k);
    for (const k of T.CAL_FLAGS) assert.equal(T.calModel(base({ view: 'month', flags: [k], scope: 'all' }), E.now()).events.length, cnt[k], 'compteur ' + k);
  });
});

describe('réglages et interface', () => {
  test('valeurs par défaut : glissante, mes séries, seulement Crunchyroll confirmé', () => {
    const o = T.calOpts();
    assert.equal(o.weekMode, 'rolling'); assert.equal(o.scope, 'mine'); assert.equal(o.onlyCr, true);
  });
  test('clics réels : périmètre, découpage de la semaine, statut (re-clic = annule), repères cumulables, effacer', async () => {
    T.STATE.series = [mk('A', 'Alpha', [3, 2, 1], { seen: 1 })];
    T.STATE.filters.calView = 'week';
    T.openCalendar(); await E.tick(40);
    const D = E.w.document;
    const click = async (sel) => { D.querySelector(sel).click(); await E.tick(10); };
    await click('[data-act="cal-src"][data-v="rest"]');
    assert.equal(T.STATE.filters.calScope, 'all'); assert.deepEqual(plain(T.STATE.filters.calSources), ['mine', 'new', 'rest']);
    await click('[data-act="cal-src"][data-v="rest"]');
    assert.equal(T.STATE.filters.calScope, 'mine'); assert.deepEqual(plain(T.STATE.filters.calSources), ['mine', 'new']);
    await click('[data-act="cal-weekmode"][data-v="calendar"]');
    assert.equal(T.STATE.filters.calWeekMode, 'calendar');
    await click('[data-act="cal-filter"][data-v="unseen"]');
    assert.equal(T.STATE.filters.calFilter, 'unseen');
    assert.ok(D.querySelectorAll('.crrav-calcard').length >= 1 && [...D.querySelectorAll('.crrav-calcard.out')].every((c) => c.classList.contains('unseen')));
    assert.equal(D.querySelector('[data-act="cal-filter"][data-v="unseen"]').getAttribute('aria-pressed'), 'true');
    await click('[data-act="cal-filter"][data-v="unseen"]');
    assert.equal(T.STATE.filters.calFilter, 'all', 'retoucher le statut actif l’annule');
    assert.equal(D.querySelector('[data-act="cal-filter"][data-v="unseen"]').getAttribute('aria-pressed'), 'false');
    await click('[data-act="cal-filter"][data-v="new"]');
    assert.deepEqual(plain(T.STATE.filters.calFlags), ['new']);
    assert.ok([...D.querySelectorAll('.crrav-calcard')].every((c) => c.classList.contains('isnew')));
    await click('[data-act="cal-filter"][data-v="new"]');
    assert.deepEqual(plain(T.STATE.filters.calFlags), [], 'retoucher un repère le retire');
    await click('[data-act="cal-filter"][data-v="seen"]'); await click('[data-act="cal-filter"][data-v="late"]');
    assert.equal(T.STATE.filters.calFilter, 'late', 'un seul statut à la fois');
    await click('[data-act="cal-filter"][data-v="new"]');
    await click('[data-act="cal-reset"]');
    assert.equal(T.STATE.filters.calFilter, 'all'); assert.deepEqual(plain(T.STATE.filters.calFlags), []);
    assert.ok(!D.querySelector('[data-act="cal-reset"]'), 'plus rien à effacer');
  });
  test('persistance : les réglages survivent à saveFilters / rechargement', () => {
    T.STATE.filters.calScope = 'all'; T.STATE.filters.calWeekMode = 'calendar'; T.STATE.filters.calFlags = ['new'];
    T.saveFilters();
    const E2 = fresh();
    try {
      E2.T.loadFilters && E2.T.loadFilters();
      const o = E2.T.calOpts();
      assert.ok(['all', 'mine'].includes(o.scope));
    } finally { E2.close(); }
  });
  test('états sauvegardés d’une ancienne version ou corrompus : jamais d’exception', () => {
    T.STATE.filters.calScope = 42; T.STATE.filters.calWeekMode = null; T.STATE.filters.calCrOnly = 'peut-être';
    T.STATE.filters.calFilter = 'inconnu'; T.calUi().off = 'x';
    T.STATE.series = [mk('A', 'Alpha', [1])];
    assert.doesNotThrow(() => T.renderCalendrier());
    assert.equal(T.calOpts().filter, 'all'); assert.equal(T.calUi().off, 0);
  });
  test('la pastille flottante « sortis aujourd’hui » compte toujours les épisodes sortis aujourd’hui non vus', () => {
    const s = mk('A', 'Alpha', [3, 0.05], { seen: 1 });
    T.STATE.series = [s];
    assert.equal(T.fabInfo(E.now()).n >= 1, true);
  });
});

describe('séries en pause (saison scindée, coupure) : leur reprise n’est pas perdue', () => {
  test('dernier épisode il y a 50 j, reprise annoncée par AniList dans 4 j → présente, marquée NEW', () => {
    const s = mk('A', 'Alpha', [57, 50]);
    s.airing = false; s.aniNextTs = E.now() + 4 * DAY; s.aniNextNum = 3; s.plannedTotal = 12;
    T.STATE.series = [s];
    const m = T.calModel(base({ view: 'agenda', horizon: 30 }), E.now());
    const ep = m.events.filter((e) => e.type === 'ep');
    assert.ok(ep.length >= 1);
    assert.equal(ep[0].n, 3); assert.equal(ep[0].isNew, true);
    assert.equal(T.calNextRelease(E.now()).title, 'Alpha');
  });
  test('série terminée il y a longtemps, ou en pause sans date : aucune sortie inventée, pas dans « sans date »', () => {
    const old = mk('A', 'Vieille', [400, 393]); old.airing = false;
    const pause = mk('B', 'Pause', [50, 43]); pause.airing = false; pause.aniNextTs = null;
    T.STATE.series = [old, pause];
    const m = T.calModel(base({ view: 'agenda', horizon: 90, est: true }), E.now());
    assert.equal(m.events.filter((e) => e.type === 'ep').length, 0);
    assert.equal(m.noDate.length, 0);
  });
});

describe('v4.22.1 : lisibilité (passé / aujourd’hui / à venir), badge NEW, liens fiables', () => {
  test('chaque jour de la semaine porte une pastille passé / aujourd’hui / à venir et une classe de section', () => {
    T.STATE.series = [mk('A', 'Alpha', [3, 1])];
    T.STATE.filters.calView = 'week';
    const dom = html();
    const secs = [...dom.querySelectorAll('.crrav-agsec[data-calday]')];
    assert.equal(secs.length, 7);
    // v4.34.0 : plus de pastilles « passé » / « à venir » ; seul « aujourd’hui » garde la sienne (et le jour n’est plus écrit deux fois).
    const kinds = secs.map((x) => (x.querySelector('.crrav-calwhen') || { className: '' }).className.replace('crrav-calwhen', '').trim());
    assert.deepEqual(plain(kinds), ['', '', '', 'today', '', '', '']);
    for (const x of secs) assert.match(x.querySelector('.crrav-caldlab b').textContent, /^(Lundi|Mardi|Mercredi|Jeudi|Vendredi|Samedi|Dimanche) \d{1,2} (Janvier|Février|Mars|Avril|Mai|Juin|Juillet|Août|Septembre|Octobre|Novembre|Décembre)/, 'titre unique « Vendredi 30 Octobre »');
    assert.equal(secs.filter((x) => x.classList.contains('past')).length, 3);
    assert.equal(secs.filter((x) => x.classList.contains('future')).length, 3);
  });
  test('le badge NEW n’a pas la classe des boutons ‹ › de navigation (collision qui l’agrandissait en gros carré)', () => {
    const css = T.CSS.replace(/\/\*[\s\S]*?\*\//g, '');
    const rules = [...css.matchAll(/([^{}@][^{}]*)\{([^{}]*)\}/g)].filter(([, sel]) => /\.crrav-calnew\b/.test(sel));
    assert.ok(rules.length >= 1);
    assert.ok(!/\.crrav-calnew\b/.test(T.CSS.match(/\.crrav-calnb[^{]*\{[^}]*\}/)[0]));
    T.STATE.series = [mk('A', 'Alpha', [2, 1])];
    T.STATE.filters.calView = 'week';
    const dom = html();
    const nb = dom.querySelectorAll('.crrav-calnb').length;
    assert.equal(nb, 2, 'seuls les deux boutons de navigation portent .crrav-calnb');
    assert.ok(dom.querySelector('.crrav-calcard .crrav-calnew'));
  });
  test('sélecteur de découpage explicite + phrase d’explication', () => {
    T.STATE.series = [mk('A', 'Alpha', [1])];
    T.STATE.filters.calView = 'week';
    let d = html();
    assert.match(d.querySelector('.crrav-calmodehelp').textContent, /3 jours avant aujourd’hui/);
    assert.equal(d.querySelectorAll('.crrav-calmodeseg button').length, 2);
    assert.equal(d.querySelector('.crrav-calmodeseg button.on').dataset.v, 'rolling');
    T.STATE.filters.calWeekMode = 'calendar';
    d = html();
    assert.match(d.querySelector('.crrav-calmodehelp').textContent, /lundi au dimanche/);
  });
});

describe('v4.24 : nouvelles séries lues chez Crunchyroll (épisode 1) et interface épurée', () => {
  test('séries neuves : épisode 1 lu chez Crunchyroll (date, image wide, vrai lien) ; listes, doublages, trop anciennes, genres exclus écartés', async () => {
    const now = E.now();
    T.STATE.series = [mk('MINE', 'Dans Mes Listes', [1])];
    const eps = { G1: { S1: [[2, now - 3 * DAY + 7 * DAY], [1, now - 3 * DAY], [3, now - 3 * DAY + 14 * DAY]] }, MINE: { S1: [[1, now - DAY]] }, G3: { S1: [[1, now - DAY]] }, G4: { S1: [[1, now - 200 * DAY]] }, G5: { S1: [[1, now - DAY]] } };
    mockCr({ newly: [crPanel('G1', 'GelPiyo 2'), crPanel('MINE', 'Dans Mes Listes'), crPanel('G3', 'Truc (Dub)'), crPanel('G4', 'Trop Ancienne'), crPanel('G5', 'Interdit', { cats: ['Hentai'] })], eps });
    await T.loadCrNew();
    const N = T.STATE.crNew;
    assert.equal(N.error, null);
    assert.deepEqual(plain(N.items.map((i) => i.id)), ['G1']);
    assert.equal(N.items[0].wide, 'https://img/G1-w.jpg');
    assert.equal(N.items[0].ts, now - 3 * DAY);           // épisode 1 = plus petit numéro, même listé en désordre
    const m = T.calModel(base({ view: 'month' }), now);
    const p = m.events.find((e) => e.id === 'G1');
    assert.ok(p && p.type === 'prem' && p.released && p.isNew);
    assert.match(p.urls.web, /series\/G1\//);
    assert.equal(p.urls.watch, 'https://www.crunchyroll.com/watch/G1-S1e1');
    assert.equal(p.sxe, 'S1E1');
  });
  test('cache : aucune requête au 2e appel ; panne : message clair, anciennes données gardées', async () => {
    const now = E.now();
    const eps = { G1: { S1: [[1, now - DAY]] } };
    const calls = mockCr({ newly: [crPanel('G1', 'Neuve')], eps });
    await T.loadCrNew();
    const n = calls.browse.length;
    await T.loadCrNew();
    assert.equal(calls.browse.length, n);
    calls.fail = true;
    await T.loadCrNew(true);
    assert.match(T.STATE.crNew.error, /indisponibles/);
    assert.equal(T.STATE.crNew.items.length, 1);
    T.STATE.series = [mk('A', 'Alpha', [1])];
    assert.match(T.renderCalendrier(), /Réessayer/);
  });
  test('réglage désactivé : aucune requête de ce type', async () => {
    T.CFG.calFutureEnabled = false;
    const calls = mockCr({ newly: [crPanel('G1', 'Neuve')], eps: { G1: { S1: [[1, E.now() - DAY]] } } });
    await T.loadCrNew(); T.calEnsureCrNew(); await E.tick(10);
    assert.equal(calls.browse.length, 0);
  });
  test('tuile : image wide, titre, « S1 · E1 », badge NEW, heure ; détail (statut + actions) dans la même carte', () => {
    T.STATE.series = [mk('A', 'Alpha', [1])];
    T.STATE.crNew.items = [{ id: 'G1', title: 'GelPiyo 2', poster: 'https://img/t.jpg', wide: 'https://img/w.jpg', synopsis: '', categories: ['Comédie'], ts: E.now() - 3 * DAY, firstN: 1, rank: 1,
      crId: 'G1', crSlug: 'gel', crSource: 'crunchyroll', eps: [{ id: 'G1e1', n: 1, t: '', ts: E.now() - 3 * DAY }] }];
    T.STATE.filters.calView = 'week'; T.calUi().off = 0;
    T.STATE.filters.calWeekMode = 'rolling';
    const c = html().querySelector('.crrav-calcard.prem');
    assert.ok(c);
    assert.equal(c.querySelector('.crrav-calp img').getAttribute('src'), 'https://img/w.jpg');
    assert.equal(c.querySelector('.crrav-calttl').textContent, 'GelPiyo 2');
    assert.equal(c.querySelector('.crrav-calsx').textContent, 'S1 · E1');
    assert.ok(!c.querySelector('.crrav-calnew'), 'nouvelle série : « Nouveau » dans le statut, pas de repère de reprise');
    assert.match(c.querySelector('.crrav-calt b').textContent, /^\d{1,2}h(\d\d)?$/);
    assert.ok(c.querySelector('.crrav-calc .crrav-calacts [data-act="cal-link"]'));
    assert.ok(!c.querySelector('.crrav-calp .crrav-calacts'));
    assert.match(c.querySelector('.crrav-calacts .pri span').textContent, /^Regarder$/, 'libellé court : jamais coupé');
  });
  test('panneau « Affichage » supprimé : plus aucune case incohérente, ni chip « Sur Crunchyroll », ni « Dates estimées »', () => {
    T.STATE.series = [mk('A', 'Alpha', [2, 1])];
    for (const v of ['agenda', 'week', 'month']) {
      T.STATE.filters.calView = v;
      const d = html();
      const txt = d.textContent;
      assert.ok(!d.querySelector('.crrav-calopt'), v);
      assert.ok(!/Dates estimées|Épisodes suivants prévus|Seulement les séries confirmées|Sur Crunchyroll\b(?! ✓)/.test(txt.replace(/Sur Crunchyroll ✓/g, '')), v);
      assert.ok(!d.querySelector('[data-k="calCrOnly"],[data-k="calShowEst"],[data-k="calShowProj"],[data-k="calWeekCal"]'), v);
      assert.ok(!d.querySelector('[data-k="calConfirmed"]'), 'v4.25 : plus rien d’estimé, donc plus de bascule « dates confirmées »');
    }
  });
});

describe('v4.24 : filtres plus logiques (statut exclusif + repères cumulables, compteurs toujours justes)', () => {
  const seedMix = () => {
    const now = E.now();
    const a = mk('A', 'Alpha', [3, 2, 1], { seen: 1 }); a.favorite = true;
    const b = mk('B', 'Bravo', [40, 2.5, 1.5], { seen: 3 });            // E2 : après une pause > 1 mois → NEW
    const c = mk('C', 'Charlie', [2, 1], { seen: 0 });
    T.STATE.series = [a, b, c];
    return now;
  };
  const ids = (m) => m.events.map((e) => e.key).sort();
  test('statut : un seul à la fois ; les repères se combinent (ET) et se mélangent au statut', () => {
    const now = seedMix();
    const o = (x) => base({ view: 'month', sources: ['mine'], ...x });
    const un = T.calModel(o({ filter: 'unseen' }), now);
    assert.ok(un.events.length && un.events.every((e) => e.type === 'out' && !e.seen));
    const unNew = T.calModel(o({ filter: 'unseen', flags: ['new'] }), now);
    assert.ok(unNew.events.length < un.events.length && unNew.events.every((e) => e.type === 'out' && !e.seen && e.isNew));
    assert.ok(T.calModel(o({ flags: ['new'] }), now).events.every((e) => e.isNew));
  });
  test('compteurs conditionnels : chaque pastille annonce EXACTEMENT ce qu’on obtient en la touchant (toutes combinaisons, via de vrais clics)', () => {
    const now = seedMix();
    T.STATE.filters.calView = 'month';
    const f = T.STATE.filters;
    const statuses = ['all', 'unseen', 'seen', 'late'];
    const flagSets = [[], ['new']];
    let checked = 0;
    for (const st of statuses) for (const fl of flagSets) {
      f.calFilter = st; f.calFlags = fl.slice();
      const shown = T.calModel(T.calOpts(), now).counts;
      for (const k of T.CAL_STATUS) {
        f.calFilter = st; f.calFlags = fl.slice();
        T.calHandleAct({ dataset: { act: 'cal-filter', v: k } });
        const want = T.calModel(T.calOpts(), now).events.length;
        // « Tout » ou retoucher le statut actif → statut = all
        assert.equal(want, (k === st ? T.calModel(base({ view: 'month', filter: 'all', flags: fl }), now) : T.calModel(base({ view: 'month', filter: k, flags: fl }), now)).events.length);
        if (k !== st && k !== 'all') assert.equal(shown[k], want, `statut ${k} depuis ${st}+${fl}`);
        checked++;
      }
      for (const k of T.CAL_FLAGS) {
        f.calFilter = st; f.calFlags = fl.slice();
        T.calHandleAct({ dataset: { act: 'cal-filter', v: k } });
        const want = T.calModel(T.calOpts(), now).events.length;
        if (!fl.includes(k)) assert.equal(shown[k], want, `repère ${k} depuis ${st}+${fl}`);
        checked++;
      }
    }
    assert.ok(checked > 30);
  });
  test('retoucher un repère ou le statut revient exactement à l’état précédent (aller-retour)', () => {
    seedMix();
    const f = T.STATE.filters;
    for (const v of [...T.CAL_STATUS, ...T.CAL_FLAGS]) {
      const before = JSON.stringify(plain({ s: T.calOpts().filter, f: T.calOpts().flags }));
      T.calHandleAct({ dataset: { act: 'cal-filter', v } });
      T.calHandleAct({ dataset: { act: 'cal-filter', v } });
      const after = JSON.stringify(plain({ s: T.calOpts().filter, f: T.calOpts().flags }));
      if (v === 'all') assert.equal(after, before); else assert.equal(after, before, v);
    }
    f.calFilter = 'unseen'; f.calFlags = ['new'];
    T.calHandleAct({ dataset: { act: 'cal-reset' } });
    assert.equal(T.calOpts().filter, 'all'); assert.deepEqual(plain(T.calOpts().flags), []);
  });
  test('anciens réglages (une seule pastille) migrés sans erreur vers statut + repères', () => {
    const f = T.STATE.filters;
    const cases = { fresh: ['all', ['new']], new: ['all', []], sequel: ['all', []], fav: ['all', []], final: ['all', []], mine: ['all', []], offlist: ['all', []], uptodate: ['all', []], unstarted: ['all', []], late: ['late', []], unseen: ['unseen', []] };
    for (const [old, [st, fl]] of Object.entries(cases)) {
      f.calFilter = old; f.calFlags = undefined;
      const o = T.calOpts();
      assert.equal(o.filter, st, old); assert.deepEqual(plain(o.flags), fl, old);
      assert.doesNotThrow(() => T.renderCalendrier());
    }
    f.calFilter = 'all'; f.calFlags = ['n’importe quoi', 'new', 42, 'fav'];
    assert.deepEqual(plain(T.calOpts().flags), ['new']);
  });
  test('affichage : pastilles cohérentes avec l’état (.on + aria-pressed), ligne de résultat explicite, « Tout effacer » seulement si utile', () => {
    seedMix();
    T.STATE.filters.calView = 'week';
    let d = html();
    assert.ok(!d.querySelector('[data-act="cal-reset"]') && !d.querySelector('.crrav-calres'));
    assert.equal(d.querySelector('[data-act="cal-filter"][data-v="all"]').getAttribute('aria-pressed'), 'true');
    T.STATE.filters.calFilter = 'unseen'; T.STATE.filters.calFlags = ['new'];
    d = html();
    for (const v of ['unseen', 'new']) {
      const b = d.querySelector(`[data-act="cal-filter"][data-v="${v}"]`);
      assert.equal(b.getAttribute('aria-pressed'), 'true', v); assert.ok(b.classList.contains('on'), v);
    }
    for (const v of ['all', 'seen', 'late']) assert.equal(d.querySelector(`[data-act="cal-filter"][data-v="${v}"]`).getAttribute('aria-pressed'), 'false', v);
    assert.match(d.querySelector('.crrav-calres').textContent, /À voir \+ Reprises/);
    assert.match(d.querySelector('.crrav-calres').textContent, /touche un filtre actif pour le retirer/);
    assert.ok(d.querySelector('[data-act="cal-reset"]'));
    const n = d.querySelector('[data-act="cal-filter"][data-v="unseen"] i').textContent;
    assert.equal(Number(n), T.calModel(T.calOpts(), E.now()).events.length, 'la pastille active annonce ce qui est affiché');
  });
  test('l’agenda vide propose d’effacer les filtres actifs (statut ET repères)', () => {
    T.STATE.series = [mk('A', 'Alpha', [1])];
    T.STATE.filters.calView = 'agenda'; T.STATE.filters.calSources = ['new'];
    const d = html();
    assert.match(d.textContent, /Rien ne correspond à ces filtres/);
    assert.ok(d.querySelector('.crrav-msg [data-act="cal-reset"]'));
  });
});
