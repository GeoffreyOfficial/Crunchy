'use strict';
// v4.20.0 — Bouton flottant « Agenda | Mon Crunchy » : accès direct au calendrier.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T, D;
beforeEach(() => { E = fresh(); T = E.T; D = E.w.document; E.window = E.w; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => E.close());

function mk(id, title, inDays, ignored) {
  const now = E.now();
  const eps = [];
  for (let n = 1; n <= 5; n++) { const air = now - (5 - n) * 7 * DAY - 2 * DAY; eps.push({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, air, avail: air, title: '' }); }
  const ph = new Map(eps.map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
  s.aniNextTs = now + inDays * DAY; s.aniNextNum = 6; s.plannedTotal = 12; s.poster = '';
  return s;
}
const q = (sel) => D.querySelector(sel);

describe('bouton agenda direct', () => {
  test('addFab crée le duo Agenda + Mon Crunchy, idempotent', () => {
    assert.equal(T.addFab(), true); assert.equal(T.addFab(), true);
    assert.equal(D.querySelectorAll('.crrav-fabs').length, 1);
    assert.ok(q('.crrav-fab-ag')); assert.ok(q('.crrav-fab'));
    assert.match(q('.crrav-fab').textContent, /Mon Crunchy/);
  });
  test('sans données : libellé neutre, pas de badge, aucune exception', () => {
    T.addFab();
    assert.equal(q('.crrav-fab-sub').textContent, 'Voir les sorties');
    assert.equal(q('.crrav-fab-badge').hidden, true);
  });
  test('affiche la prochaine sortie (titre + épisode + heure) et exclut les séries ignorées', () => {
    const a = mk('A', 'Alpha', 1), b = mk('B', 'Bravo', 3);
    T.STATE.series = [a, b];
    T.addFab();
    assert.match(q('.crrav-fab-sub').textContent, /^(demain )?\d+h\d{2} · Alpha /);
    
    T.toggleIgnored(a.id, { title: 'Alpha', source: 'watchlist' });
    T.fabUpdate();
    assert.match(q('.crrav-fab-sub').textContent, /Bravo /);
    assert.doesNotMatch(q('.crrav-fab-sub').textContent, /Alpha/);
  });
  test('badge = épisodes encore à venir aujourd’hui', () => {
    const now = E.now();
    const endOfDay = new Date(now); endOfDay.setHours(23, 59, 0, 0);
    const left = (endOfDay.getTime() - now) / DAY;
    if (left < 0.01) return;                       // horloge de test collée à minuit : rien à vérifier
    const a = mk('A', 'Alpha', left / 2), b = mk('B', 'Bravo', 3);
    T.STATE.series = [a, b];
    T.addFab();
    assert.equal(q('.crrav-fab-badge').hidden, false);
    assert.equal(q('.crrav-fab-badge').textContent, '1');
    T.toggleIgnored(a.id, { title: 'Alpha', source: 'watchlist' });
    T.fabUpdate();
    assert.equal(q('.crrav-fab-badge').hidden, true);
  });
  test('clic sur Agenda : ouvre le panneau directement sur l’onglet Calendrier', async () => {
    T.STATE.series = [mk('A', 'Alpha', 2)];
    T.STATE.tab = 'suivi';
    T.addFab();
    q('.crrav-fab-ag').click();
    await E.tick(60);
    assert.equal(T.STATE.tab, 'calendrier');
    const ov = q('.crrav-overlay');
    assert.ok(ov && ov.style.display !== 'none');
    assert.ok(ov.querySelector('.crrav-cal'), 'le calendrier est rendu');
  });
  test('clic sur Mon Crunchy : comportement inchangé (garde l’onglet courant)', () => {
    T.STATE.series = [mk('A', 'Alpha', 2)];
    T.STATE.tab = 'suivi';
    T.addFab();
    q('.crrav-fab').click();
    assert.equal(T.STATE.tab, 'suivi');
    assert.ok(q('.crrav-overlay'));
  });
  test('panneau déjà ouvert sur un autre onglet : Agenda bascule sans le rouvrir', () => {
    T.STATE.series = [mk('A', 'Alpha', 2)];
    T.STATE.tab = 'suivi';
    T.addFab(); q('.crrav-fab').click();
    T.openCalendar();
    assert.equal(T.STATE.tab, 'calendrier');
    assert.equal(D.querySelectorAll('.crrav-overlay').length, 1);
  });
  test('instantané périmé ignoré, instantané valide repris (page fraîche)', () => {
    const now = E.now(), k = T.LS + 'calfab';
    E.window.localStorage.setItem(k, JSON.stringify({ title: 'Vieux', label: 'S1E1', ts: now - 1000, n: 2, day: 'x' }));
    assert.equal(T.fabInfo(now).title, '');
    E.window.localStorage.setItem(k, JSON.stringify({ title: 'Futur', label: 'S1E2', ts: now + 3600e3, n: 1, day: T.calDayKey(now) }));
    const i = T.fabInfo(now); assert.equal(i.title, 'Futur'); assert.equal(i.n, 1);
    E.window.localStorage.setItem(k, '{pas du json');
    assert.doesNotThrow(() => T.fabInfo(now));
  });
  test('CSS : agenda rond ≥ 44 px sur mobile, texte masqué ; pas de position fixe sur le bouton principal', () => {
    const css = T.CSS;
    assert.match(css, /\.crrav-fabs\{position:fixed/);
    assert.match(css, /@media \(max-width:560px\)\{\s*\.crrav-fab-ag\{width:48px;height:48px/);
    assert.doesNotMatch(css, /\.crrav-fab\{position:fixed/);
  });
  test('accueil Crunchyroll : bouton « Agenda complet » présent et ouvre le calendrier', () => {
    T.STATE.series = [mk('A', 'Alpha', 2)];
    const html = T.crpCalHtml({ h2: '', container: '' });
    assert.match(html, /data-crrav-calopen/);
  });
});
