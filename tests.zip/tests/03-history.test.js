'use strict';
// Historique de visionnage : décodage des entrées, scan complet / incrémental, cache,
// et toutes les régressions déjà vécues (pagination, repère, total bidon, pages perdues).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, historyEntry, routeHistory, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.CFG.concurrency = 3; T.PACE.limit = 3; });
afterEach(() => E.close());

// Historique de N entrées, du plus récent au plus ancien, 12 épisodes par série.
function makeHistory(n, start, stepMs = 3600e3, prefix = 'S') {
  const list = [];
  for (let i = 0; i < n; i++) list.push(historyEntry(prefix + Math.floor(i / 12), 1, (i % 12) + 1, start - i * stepMs));
  return list;
}
const scan = (force = true) => T.getWatchedSeriesIds('acc', null, force);

describe('extractSeriesRef', () => {
  test('watch-history : parent_id à la racine prime sur l’id d’épisode du panel', () => {
    assert.equal(T.extractSeriesRef(historyEntry('GSERIES', 1, 1, 0)).id, 'GSERIES');
  });
  test('series_id à la racine', () => assert.equal(T.extractSeriesRef({ series_id: 'X' }).id, 'X'));
  test('panel de type series (watchlist)', () => {
    const r = T.extractSeriesRef({ panel: { type: 'series', id: 'S9' } });
    assert.equal(r.id, 'S9'); assert.ok(r.panel);
  });
  test('panel épisode → series_id de episode_metadata', () => {
    assert.equal(T.extractSeriesRef({ panel: { type: 'episode', id: 'E', episode_metadata: { series_id: 'S7' } } }).id, 'S7');
  });
  test('panel sans type mais avec series_metadata', () => {
    assert.equal(T.extractSeriesRef({ panel: { id: 'S5', series_metadata: {} } }).id, 'S5');
  });
  test('entrées inexploitables → null', () => {
    assert.equal(T.extractSeriesRef(null), null);
    assert.equal(T.extractSeriesRef({ panel: { type: 'episode', id: 'E' } }), null);
  });
});

describe('historyMark / historyTs', () => {
  test('repère = id d’entrée stable, date = date_played', () => {
    const it = historyEntry('S', 1, 1, Date.parse('2026-01-02T03:04:05Z'));
    assert.equal(T.historyMark(it), 'S-s1e1');
    assert.equal(T.historyTs(it), Date.parse('2026-01-02T03:04:05Z'));
    assert.equal(T.historyTs({}), 0);
  });
});

describe('scan complet — régression v4.7.0 : total annoncé = taille de page', () => {
  test('lit TOUTES les pages même si l’API annonce total=100 (Mashle tout au fond)', async () => {
    const list = makeHistory(450, E.now());
    list.push(historyEntry('GDKHZEP8W', 1, 1, E.now() - 2000 * 3600e3, { title: 'MASHLE: MAGIC AND MUSCLES' }));
    routeHistory(E.net, list);
    const ids = await scan();
    assert.ok(ids.has('GDKHZEP8W'), 'la série la plus ancienne doit être lue');
    assert.equal(ids.size, 39);
    assert.equal(T.historyComplete, true);
    assert.equal(T.historyGapPages, 0);
  });
  test('total fiable (> page 1) toujours respecté', async () => {
    const list = makeHistory(250, E.now());
    routeHistory(E.net, list, { realTotal: true });
    const ids = await scan();
    assert.equal(ids.size, 21);
    assert.equal(E.net.count(/watch-history/), 3, 'exactement ceil(250/100) pages');
    assert.equal(T.historyComplete, true);
  });
  test('historique exactement multiple de 100 : s’arrête sur la page vide', async () => {
    routeHistory(E.net, makeHistory(300, E.now()));
    await scan();
    assert.equal(T.historyComplete, true);
    assert.ok(E.net.count(/watch-history/) <= 6);
  });
  test('API en erreur au-delà de la fin : arrêt rapide, aucun trou, pas déclaré « complet »', async () => {
    const list = makeHistory(300, E.now());
    E.net.on(/watch-history\?/, (u) => {
      const q = new URL(u).searchParams; const p = +q.get('page');
      if (p > 3) return { __status: 404, body: {} };
      const d = list.slice((p - 1) * 100, p * 100); return { total: d.length, data: d };
    });
    const ids = await scan();
    assert.equal(ids.size, 25);
    assert.equal(T.historyGapPages, 0);
    assert.equal(T.historyComplete, false, 'prudence : le filet playheads reste actif');
    assert.ok(E.net.count(/watch-history/) < 60, 'pas 1000 requêtes en échec');
  });
  test('page perdue au milieu (500 persistant) : trou signalé, pas de repère, pas « complet »', async () => {
    const list = makeHistory(450, E.now());
    routeHistory(E.net, list, { errorPages: new Set([3]) });
    const ids = await scan();
    assert.ok(T.historyGapPages >= 1);
    assert.equal(T.historyComplete, false);
    const c = T.cacheGetStale('watchedids:acc');
    assert.equal(c.cv, 1, 'cv 1 = scan complet obligatoire la prochaine fois');
    assert.ok(ids.has('S36'), 'les pages après le trou sont quand même lues');
  });
  test('détail par série : épisodes logiques (pas une entrée par version audio)', async () => {
    const t = E.now();
    const list = [
      historyEntry('S', 1, 1, t, { epId: 'vo' }), historyEntry('S', 1, 1, t - 1, { epId: 'vf' }),
      historyEntry('S', 1, 2, t - 2),
    ];
    routeHistory(E.net, list);
    await scan();
    const d = T.HISTORY_DETAIL.find((x) => x.id === 'S');
    assert.equal(d.episodes, 2, 'VO + VF du même épisode = 1');
    assert.equal(d.seconds, 2 * 1440);
  });
});

describe('scan incrémental — régression v4.6.0 : repère temporel', () => {
  test('épisode repris remonté en tête : ce qui a été vu entre-temps est capté', async () => {
    const list = makeHistory(250, E.now() - DAY);
    list.unshift(historyEntry('X', 1, 1, E.now() - 60e3));
    routeHistory(E.net, list);
    await scan();
    E.advance(3600e3);
    // Y regardé, puis X repris → X repasse devant Y
    list.unshift(historyEntry('Y', 1, 1, E.now() - 3000e3), historyEntry('Y', 1, 2, E.now() - 2000e3));
    list.splice(list.findIndex((e) => e.parent_id === 'X'), 1);
    list.unshift(historyEntry('X', 1, 1, E.now() - 10e3));
    list.sort((a, b) => Date.parse(b.date_played) - Date.parse(a.date_played));
    E.net.log.length = 0;
    const ids = await scan();
    assert.ok(ids.has('Y'), 'Y ne doit pas être perdu derrière le repère');
    assert.ok(ids.has('S20'), 'socle du scan précédent conservé');
    assert.equal(E.net.count(/watch-history/), 1, 'incrémental = 1 requête');
    assert.equal(T.historyComplete, true, 'exhaustivité héritée');
  });
  test('scan complet de contrôle au-delà de 7 jours', async () => {
    routeHistory(E.net, makeHistory(250, E.now()));
    await scan();
    E.advance(8 * DAY); E.net.log.length = 0;
    await scan();
    assert.ok(E.net.count(/watch-history/) >= 3, 'relecture complète (toutes les pages)');
  });
  test('anciens caches cv 2 / cv 3 (potentiellement troués) jamais servis, même frais', async () => {
    routeHistory(E.net, makeHistory(250, E.now()));
    for (const cv of [2, 3]) {
      T.cacheSet('watchedids:acc', { ids: ['ONLY'], complete: true, detail: [], mark: 'm', markTs: E.now(), fullAt: E.now(), cv });
      const ids = await scan(false);
      assert.ok(ids.has('S20') && !ids.has('ONLY'), 'cv ' + cv + ' : scan complet de réparation');
    }
  });
  test('cache cv courant frais servi sans requête (2 min max si base incrémentale)', async () => {
    routeHistory(E.net, makeHistory(120, E.now()));
    await scan();
    E.net.log.length = 0;
    await scan(false);
    assert.equal(E.net.count(/watch-history/), 0);
    E.advance(121e3);
    await scan(false);
    assert.equal(E.net.count(/watch-history/), 1, 'au-delà de 2 min : rattrapage incrémental');
  });
  test('historique sans dates : jamais d’arrêt incrémental, cache cv 1', async () => {
    const list = makeHistory(150, E.now()).map((e) => ({ ...e, date_played: undefined }));
    routeHistory(E.net, list);
    await scan();
    assert.equal(T.cacheGetStale('watchedids:acc').cv, 1);
  });
});

describe('cachedWatchedIds (Stats / Hors listes, sans requête)', () => {
  test('lit le cache sans jamais appeler le réseau', async () => {
    routeHistory(E.net, makeHistory(30, E.now()));
    assert.equal(T.cachedWatchedIds(), null);
    await scan();
    E.net.log.length = 0;
    const c = T.cachedWatchedIds();
    assert.equal(c.ids.size, 3);
    assert.equal(c.complete, true);
    assert.equal(E.net.log.length, 0);
  });
});

describe('serializeDetail / mergeDetail', () => {
  test('fusion : le neuf prime, l’ancien comble, total exact', () => {
    const detail = new Map([['A', { title: 'A', eps: new Map([['s1e1', 1400]]), genres: new Set() }]]);
    const ids = new Set(['A']);
    T.mergeDetail([{ id: 'A', title: 'A', eps: ['s1e1', 's1e2'], seconds: 2800, genres: ['Action'] },
      { id: 'B', title: 'B', eps: ['s1e1'], seconds: 1000, genres: [] }], detail, ids);
    const arr = T.serializeDetail(detail);
    assert.ok(ids.has('B'));
    const a = arr.find((x) => x.id === 'A');
    assert.equal(a.episodes, 2);
    assert.deepEqual([...a.genres], ['Action']);
    assert.equal(arr[0].id, 'A', 'trié par temps vu décroissant');
  });
});

describe('diagnostic historique', () => {
  test('état réel du scan exposé au diagnostic (v4.8.0 : plus « seulement 100 »)', async () => {
    routeHistory(E.net, makeHistory(451, E.now()));
    await scan();
    const st = T.historyScanState();
    assert.equal(st.entries, 451);
    assert.equal(st.series, 38);
    assert.equal(st.complete, true);
    const r = T.summarizeHistoryProbe({ deep: true, startWorks: true, total: 100, depth: 100, extract: { sampleSize: 25, extracted: 25 } });
    assert.match(r.note, /451 entrées · 38 séries/);
    assert.match(T.historyScanStateHtml(), /451/);
    E.advance(10 * 60e3);
    routeHistory(E.net, makeHistory(451, E.now()));
    await scan();
    assert.equal(T.historyScanState().entries, 451, 'conservé par le scan incrémental');
  });
  test('summarizeHistoryProbe signale le total non fiable', () => {
    const r = T.summarizeHistoryProbe({ deep: true, startWorks: true, total: 100, depth: 100, extract: { sampleSize: 25, extracted: 25 } });
    assert.match(r.note, /taille d’une page/);
  });
  test('pagination cassée / extraction basse', () => {
    assert.equal(T.summarizeHistoryProbe({ deep: true, startWorks: false }).status, 'err');
    assert.equal(T.summarizeHistoryProbe({ extract: { sampleSize: 25, extracted: 10 } }).status, 'warn');
    assert.equal(T.summarizeHistoryProbe(null).status, 'err');
  });
});
