'use strict';
// v4.27.1 — Filtres « intelligents » : SOURCES cumulables (Mes séries · Nouvelles séries · Reste de Crunchyroll) au lieu d'un
// périmètre exclusif ; le statut ne concerne que « Mes séries » ; les repères restreignent toutes les sources.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

function mk(id, title, o = {}) {
  const now = E.now();
  const nEps = o.nEps ?? 5, seen = o.seen ?? nEps;
  const eps = [];
  for (let n = 1; n <= nEps; n++) { const air = now - (nEps - n) * 7 * DAY - 2 * DAY; eps.push({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, air, avail: air, title: '' }); }
  const ph = new Map(eps.slice(0, seen).map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
  s.aniNextTs = now + 3 * DAY; s.aniNextNum = nEps + 1; s.plannedTotal = 12; s.poster = '';
  return s;
}
const crItem = (id, title, inDays, fresh = true) => ({ id, title, poster: '', wide: '', synopsis: '', categories: [], ts: E.now() + inDays * DAY, firstN: 1, rank: 1, crId: id, crSlug: id.toLowerCase(), crSource: 'crunchyroll',
  eps: [1, 2, 3].map((n) => ({ id: id + 'e' + n, n, t: '', ts: E.now() + (inDays + (n - 1) * 7) * DAY })) });
const o = (x = {}) => ({ view: 'agenda', horizon: 365, filter: 'all', flags: [], ...x });
const seed = () => {
  T.STATE.series = [mk('A', 'Alpha', { seen: 3 }), mk('B', 'Bravo')];
  T.STATE.crNew.items = [crItem('N1', 'Inconnue', 9), crItem('A2', 'Alpha', 20)];            // une vraie nouveauté + la suite d'Alpha (série suivie)
  T.STATE.crSeason.items = [crItem('R1', 'Catalogue', 5, false)];
};
const kinds = (m) => [...new Set(m.events.map((e) => (e.type === 'air' ? 'rest' : e.type === 'prem' && !e.followed ? 'new' : 'mine')))].sort();

describe('sources cumulables', () => {
  test('défaut = Mes séries + Nouvelles séries ; chaque source seule ; toutes ensemble = union', () => {
    seed();
    assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new']);
    assert.deepEqual(kinds(T.calModel(o({ sources: ['mine'] }), E.now())), ['mine']);
    assert.deepEqual(kinds(T.calModel(o({ sources: ['new'] }), E.now())), ['new']);
    assert.deepEqual(kinds(T.calModel(o({ sources: ['rest'] }), E.now())), ['rest']);
    assert.deepEqual(kinds(T.calModel(o({ sources: ['mine', 'new'] }), E.now())), ['mine', 'new']);
    const all = T.calModel(o({ sources: ['mine', 'new', 'rest'] }), E.now());
    const sum = ['mine', 'new', 'rest'].reduce((n, k) => n + T.calModel(o({ sources: [k] }), E.now()).events.length, 0);
    assert.equal(all.events.length, sum, 'l’union = somme des sources (aucun doublon, aucune perte)');
  });
  test('la suite d’une série que je suis appartient à « Mes séries » (pas aux nouvelles séries)', () => {
    seed();
    const mine = T.calModel(o({ sources: ['mine'] }), E.now()).events;
    assert.ok(mine.some((e) => e.type === 'prem' && e.followed && e.id === 'A2'));
    assert.ok(!T.calModel(o({ sources: ['new'] }), E.now()).events.some((e) => e.id === 'A2'));
  });
  test('le statut ne concerne que « Mes séries » : Nouvelles séries reste affichée (« À voir » + « Nouvelles séries »)', () => {
    seed(); T.STATE.crNew.items[0] = crItem('N1', 'Inconnue', 1);
    const w = { view: 'week' };
    const m = T.calModel(o({ ...w, filter: 'unseen', sources: ['mine', 'new'] }), E.now());
    assert.ok(m.events.some((e) => e.type === 'out' && !e.seen));
    assert.ok(m.events.filter((e) => e.type === 'out').every((e) => !e.seen), 'plus aucun épisode vu');
    assert.ok(m.events.some((e) => e.type === 'prem' && e.id === 'N1'), 'la nouveauté est toujours là');
    const only = T.calModel(o({ ...w, filter: 'unseen', sources: ['mine'] }), E.now());
    assert.ok(only.events.every((e) => e.type === 'out' && !e.seen));
  });
  test('un repère (Reprises) restreint TOUTES les sources', () => {
    seed();
    const m = T.calModel(o({ flags: ['new'], sources: ['mine', 'new', 'rest'] }), E.now());
    assert.ok(m.events.length > 0 && m.events.every((e) => (e.type === 'prem' ? !!e.followed : !!e.isNew)));
    assert.ok(!m.events.some((e) => e.id === 'N1'), 'une série inconnue n’est pas une reprise');
  });
  test('compteurs de sources : ce que chaque source apporte ; « reste » inconnu tant qu’il n’est pas chargé', () => {
    seed();
    const c = T.calModel(o({ sources: ['mine', 'new'] }), E.now()).counts;
    assert.equal(c.src_new, 1); assert.ok(c.src_mine > 0); assert.equal(c.src_rest, null);
    const c2 = T.calModel(o({ sources: ['mine', 'new', 'rest'] }), E.now()).counts;
    assert.ok(c2.src_rest > 0);
    assert.equal(c2.src_mine + c2.src_new + c2.src_rest, T.calModel(o({ sources: ['mine', 'new', 'rest'] }), E.now()).events.length);
  });
  test('le catalogue « reste de Crunchyroll » n’est lu que si la source est cochée', async () => {
    seed(); T.STATE.crSeason.items = []; T.STATE.crSeason.tried = new Set();
    const asked = []; E.net.on(/\/discover\/browse/, (u) => { asked.push(u); return { data: [] }; });
    T.STATE.filters.calSources = ['mine', 'new']; T.calEnsureCrSeason(); await E.tick(30);
    assert.equal(asked.filter((u) => /seasonal_tag/.test(u)).length, 0);
    T.STATE.filters.calSources = ['mine', 'new', 'rest']; T.calEnsureCrSeason(); await E.tick(30);
    assert.ok(asked.filter((u) => /seasonal_tag/.test(u)).length > 0);
  });
});

describe('clics et réglages', () => {
  const click = (v, act = 'cal-src') => T.calHandleAct({ dataset: { act, v } });
  test('cocher / décocher ; la dernière source ne se décoche pas ; l’état est mémorisé', () => {
    seed();
    click('rest'); assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new', 'rest']); assert.equal(T.calOpts().scope, 'all');
    click('mine'); click('new'); assert.deepEqual(plain(T.calOpts().sources), ['rest']);
    click('rest'); assert.deepEqual(plain(T.calOpts().sources), ['rest'], 'au moins une source reste cochée');
    click('new'); assert.deepEqual(plain(T.calOpts().sources), ['new', 'rest']);
    assert.deepEqual(plain(T.STATE.filters.calSources), ['new', 'rest']);
  });
  test('décocher « Mes séries » annule le statut ; toucher un statut la recoche', () => {
    seed();
    click('unseen', 'cal-filter'); assert.equal(T.calOpts().filter, 'unseen');
    click('mine'); assert.equal(T.calOpts().filter, 'all', 'le statut ne concerne que Mes séries');
    click('unseen', 'cal-filter');
    assert.equal(T.calOpts().filter, 'unseen'); assert.ok(T.calOpts().sources.includes('mine'), '« À voir » réactive « Mes séries »');
  });
  test('anciens réglages : périmètre « Tout Crunchyroll », repère « Nouvelles séries », réglage corrompu', () => {
    const f = T.STATE.filters;
    f.calSources = null; f.calScope = 'all'; f.calFlags = []; assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new', 'rest']);
    f.calScope = 'mine'; f.calFlags = ['prem']; assert.deepEqual(plain(T.calOpts().sources), ['new'], 'l’ancien repère devient la seule source « nouvelles séries »');
    assert.deepEqual(plain(T.calOpts().flags), []);
    f.calSources = ['rest', 'n’importe quoi', 7]; assert.deepEqual(plain(T.calOpts().sources), ['rest']);
    f.calSources = []; f.calFlags = []; assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new']);
    click('all', 'cal-scope'); assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new', 'rest']);
    click('mine', 'cal-scope'); assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new']);
  });
  test('affichage : pastilles cohérentes, plus de sélecteur « Mes séries / Tout Crunchyroll », « Tout effacer » remet les sources par défaut', () => {
    seed();
    const html = () => E.html(T.renderCalendrier());
    let d = html();
    assert.ok(!d.querySelector('.crrav-calscope'), 'l’ancien sélecteur à deux boutons a disparu');
    for (const v of ['mine', 'new']) assert.equal(d.querySelector(`[data-act="cal-src"][data-v="${v}"]`).getAttribute('aria-pressed'), 'true', v);
    assert.equal(d.querySelector('[data-act="cal-src"][data-v="rest"]').getAttribute('aria-pressed'), 'false');
    assert.ok(!d.querySelector('[data-act="cal-reset"]'), 'sources par défaut : rien à effacer');
    click('rest'); d = html();
    assert.equal(d.querySelector('[data-act="cal-src"][data-v="rest"]').getAttribute('aria-pressed'), 'true');
    assert.ok(d.querySelector('[data-act="cal-reset"]'), 'sources modifiées = filtre actif');
    assert.match(d.querySelector('.crrav-calres').textContent, /Mes séries \+ Nouvelles séries \+ Reste de Crunchyroll/);
    click('x', 'cal-reset'); assert.deepEqual(plain(T.calOpts().sources), ['mine', 'new']);
  });
  test('rien d’affiché à cause des sources : le message propose d’effacer les filtres', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.filters.calView = 'agenda'; T.STATE.filters.calSources = ['new'];
    const d = E.html(T.renderCalendrier());
    assert.match(d.textContent, /Rien ne correspond à ces filtres/);
    assert.ok(d.querySelector('.crrav-msg [data-act="cal-reset"]'));
  });
});
