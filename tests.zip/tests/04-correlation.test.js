'use strict';
// Corrélation de séries : normalisation de titres, filet « déjà vu par titre », choix de
// la fiche AniList, résolution AniList → Crunchyroll, découpage des saisons.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, series, ep } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; });
afterEach(() => E.close());

describe('normalisation et similarité', () => {
  test('aniNorm : minuscules, sans accents ni ponctuation', () => {
    assert.equal(T.aniNorm('  Madan no Ô to Vanadis !! '), 'madan no o to vanadis');
    assert.equal(T.aniNorm('Re:ZERO -Starting Life-'), 're zero starting life');
    assert.equal(T.aniNorm(null), '');
  });
  test('aniDice : 1 pour identique, 0 pour vide, symétrique', () => {
    assert.equal(T.aniDice('Mashle', 'MASHLE'), 1);
    assert.equal(T.aniDice('', 'x'), 0);
    assert.equal(T.aniDice('Bleach', 'Black Clover'), T.aniDice('Black Clover', 'Bleach'));
    assert.ok(T.aniDice('Frieren', 'Frieren: Beyond Journey’s End') > 0.4);
  });
  test('aniSequelNumber : saison en fin de titre, jamais une année', () => {
    assert.equal(T.aniSequelNumber('Attack on Titan 2nd Season'), 2);
    assert.equal(T.aniSequelNumber('Re:Zero Season 2'), 2);
    assert.equal(T.aniSequelNumber('Isekai Quartet 3'), 3);
    assert.equal(T.aniSequelNumber('Fullmetal Alchemist 2003'), null);
    assert.equal(T.aniSequelNumber('Frieren'), null);
  });
});

describe('discoverTitleKey / isWatchedByTitle (filet « déjà vu » v4.5.3)', () => {
  test('retire saisons, parties, doublages', () => {
    const k = T.discoverTitleKey('Mashle');
    for (const v of ['MASHLE Season 2', 'Mashle (VF)', 'Mashle 2nd Season', 'Mashle Saison 2', 'Mashle Part 2', 'Mashle French Dub'])
      assert.equal(T.discoverTitleKey(v), k, v);
  });
  test('vu dans l’historique → détecté sous une autre fiche (doublage, saison à part)', () => {
    T.HISTORY_DETAIL = [{ id: 'A', title: 'MASHLE: MAGIC AND MUSCLES' }];
    T.STATE.series = [];
    T.buildWatchedTitleNet();
    assert.equal(T.isWatchedByTitle('MASHLE: MAGIC AND MUSCLES (French Dub)'), true);
    assert.equal(T.isWatchedByTitle('Mashle: Magic and Muscles Season 2'), true);
    assert.equal(T.isWatchedByTitle('Black Clover'), false);
  });
  test('chiffres différents = autre œuvre (Jujutsu Kaisen 0 ≠ Jujutsu Kaisen)', () => {
    T.HISTORY_DETAIL = [{ id: 'J', title: 'Jujutsu Kaisen' }];
    T.STATE.series = [];
    T.buildWatchedTitleNet();
    assert.equal(T.isWatchedByTitle('Jujutsu Kaisen 0'), false);
  });
  test('les séries des listes comptent aussi', () => {
    T.HISTORY_DETAIL = null;
    T.STATE.series = [series('S', [ep(1, 1)], { title: 'Frieren' })];
    T.buildWatchedTitleNet();
    assert.equal(T.isWatchedByTitle('Frieren (VF)'), true);
  });
  test('titres trop courts : pas de faux positifs par bigrammes', () => {
    T.HISTORY_DETAIL = [{ id: 'X', title: 'K' }];
    T.STATE.series = [];
    T.buildWatchedTitleNet();
    assert.equal(T.isWatchedByTitle('K-On!'), false);
  });
});

describe('aniPickMatch (liaison série CR → fiche AniList)', () => {
  const m = (id, title, extra = {}) => ({ id, title: { romaji: title, english: extra.en || null }, synonyms: [], status: 'FINISHED', startDate: { year: extra.year || 2020 }, episodes: extra.episodes ?? 12, externalLinks: extra.links || [], ...extra });
  test('titre exact retenu', () => {
    const best = T.aniPickMatch([m(1, 'Bleach'), m(2, 'Black Clover')], { title: 'Bleach' });
    assert.equal(best.id, 1);
  });
  test('rien d’assez sûr → null (garde-fou anti faux positif)', () => {
    assert.equal(T.aniPickMatch([m(1, 'Totally Different Show')], { title: 'Mashle' }), null);
    assert.equal(T.aniPickMatch([], { title: 'x' }), null);
  });
  test('lien Crunchyroll de la fiche = même franchise quel que soit le titre', () => {
    const fiche = m(9, 'Yomi no Tsugai', { links: [{ site: 'Crunchyroll', url: 'https://www.crunchyroll.com/series/GTSUGAI/x' }] });
    const best = T.aniPickMatch([m(1, 'Autre chose'), fiche], { id: 'GTSUGAI', title: 'Tsugai - Les démons de l’ombre' });
    assert.equal(best.id, 9);
  });
  test('titre moyen (0.6–0.9) accepté seulement s’il est corroboré par l’année', () => {
    const s = { title: 'Le Chevalier Dragon', lastAired: { air: Date.parse('2023-11-01') } };
    const sc = T.aniDice(s.title, 'Chevalier du Dragon');
    assert.ok(sc >= 0.6 && sc < 0.9, 'cas de test dans la bonne plage (' + sc + ')');
    assert.equal(T.aniPickMatch([m(5, 'Chevalier du Dragon', { year: 2023 })], s).id, 5);
    assert.equal(T.aniPickMatch([m(5, 'Chevalier du Dragon', { year: 2010 })], s), null);
    assert.equal(T.aniPickMatch([m(5, 'Chevalier du Dragon', { year: 2010, status: 'RELEASING' })], { ...s, airing: true }).id, 5, 'ou par la diffusion en cours');
  });
  test('franchise multi-saisons sous une fiche CR : la saison correspondante l’emporte (Isekai Quartet)', () => {
    const s1 = m(4548, 'Isekai Quartet'), s3 = m(194447, 'Isekai Quartet 3');
    assert.equal(T.aniPickMatch([s1, s3], { title: 'Isekai Quartet', seasons: 3 }).id, 194447);
  });
  test('nombre d’épisodes identique départage deux fiches au titre proche', () => {
    const a = m(1, 'Mashle', { episodes: 12 }), b = m(2, 'Mashle', { episodes: 25 });
    assert.equal(T.aniPickMatch([b, a], { title: 'Mashle', episodes: 12 }).id, 1);
  });
  test('correspondance forcée (__forced) prioritaire', () => {
    const f = { ...m(20809, 'Lord Marksman and Vanadis'), __forced: true };
    assert.equal(T.aniPickMatch([m(1, 'Madan no Ou to Vanadis'), f], { title: 'Madan no Ô to Vanadis' }).id, 20809);
  });
  test('table manuelle : titre accentué ou non', () => {
    assert.equal(T.anilistOverrideId('Madan no Ô to Vanadis'), 20809);
    assert.equal(T.anilistOverrideId('madan no o to vanadis'), 20809);
    assert.equal(T.anilistOverrideId('Inconnu'), null);
  });
});

describe('variantes de recherche AniList', () => {
  test('titre composé : chaque partie, la plus longue d’abord', () => {
    const t = T.anilistSearchTerms('Tsugai - Daemons of the Shadow Realm');
    assert.equal(t[0], 'Tsugai - Daemons of the Shadow Realm');
    assert.ok(t.includes('Daemons of the Shadow Realm'));
    assert.ok(t.length <= 3);
  });
  test('ô → ou (Hepburn) et sans accent, plafond 4 dans ce cas', () => {
    const t = T.anilistSearchTerms('Madan no Ô to Vanadis');
    assert.ok(t.includes('Madan no Ou to Vanadis'));
    assert.ok(t.includes('Madan no O to Vanadis'));
    assert.ok(t.length <= 4);
  });
  test('année entre parenthèses retirée', () => {
    assert.ok(T.anilistSearchTerms('Digimon Adventure: (2020)').includes('Digimon Adventure:'));
  });
  test('ne casse pas « Re:Zero » (séparateur sans espaces)', () => {
    assert.deepEqual([...T.anilistSearchTerms('Re:Zero')], ['Re:Zero']);
  });
  test('requête groupée : un alias par terme, un seul aller-retour', () => {
    const q = T.anilistBuildMultiQuery(['a', 'b', 'c']);
    assert.match(q, /\$q0: String, \$q1: String, \$q2: String/);
    assert.equal((q.match(/p\d: Page/g) || []).length, 3);
    assert.match(q, /fragment F on Media/);
  });
});

describe('résolution AniList → Crunchyroll (Nouveautés / reco des favoris)', () => {
  test('lien déclaré par AniList : confirmé, aucune recherche CR', async () => {
    const r = await T.resolveCrunchyrollForPremiere({ id: 1, title: { english: 'X' },
      externalLinks: [{ site: 'Crunchyroll', type: 'STREAMING', url: 'https://www.crunchyroll.com/fr/series/GX1/x' }] });
    assert.equal(r.id, 'GX1'); assert.equal(r.confidence, 'confirmed');
    assert.equal(E.net.count(/discover\/search/), 0);
  });
  test('recherche CR : fort = confirmed, moyen = probable, faible = rien', async () => {
    E.net.on(/discover\/search/, (u) => {
      const q = new URL(u).searchParams.get('q');
      const items = { 'Exact Show': [{ id: 'G1', title: 'Exact Show', slug_title: 'e' }],
        'Medium Show Title': [{ id: 'G2', title: 'Medium Shaw Tit', slug_title: 'm' }] }[q] || [{ id: 'G9', title: 'zzzz qqqq' }];
      return { data: [{ type: 'series', items }] };
    });
    assert.equal((await T.resolveCrunchyrollForPremiere({ id: 10, title: { english: 'Exact Show' } })).confidence, 'confirmed');
    const mid = await T.resolveCrunchyrollForPremiere({ id: 11, title: { english: 'Medium Show Title' } });
    assert.ok(['probable', 'confirmed'].includes(mid.confidence));
    assert.equal((await T.resolveCrunchyrollForPremiere({ id: 12, title: { english: 'Nothing Alike' } })).id, null);
  });
  test('le résultat est mis en cache (2e appel sans requête)', async () => {
    E.net.on(/discover\/search/, () => ({ data: [{ type: 'series', items: [{ id: 'G1', title: 'Show' }] }] }));
    await T.resolveCrunchyrollForPremiere({ id: 20, title: { english: 'Show' } });
    const n = E.net.count(/discover\/search/);
    await T.resolveCrunchyrollForPremiere({ id: 20, title: { english: 'Show' } });
    assert.equal(E.net.count(/discover\/search/), n);
  });
  test('crLinkFromAnilist : STREAMING d’abord, URL non convertible conservée', () => {
    const r = T.crLinkFromAnilist({ externalLinks: [
      { site: 'Crunchyroll', type: 'INFO', url: 'https://www.crunchyroll.com/fr/series/GINFO/x' },
      { site: 'Crunchyroll', type: 'STREAMING', url: 'https://www.crunchyroll.com/fr/series/GSTREAM/y' }] });
    assert.equal(r.id, 'GSTREAM');
    assert.deepEqual({ ...T.crLinkFromAnilist({ externalLinks: [{ site: 'crunchyroll', url: 'https://www.crunchyroll.com/news' }] }) },
      { id: '', slug: '', url: 'https://www.crunchyroll.com/news' });
    assert.equal(T.crLinkFromAnilist({ externalLinks: [{ site: 'Netflix', url: 'x' }] }), null);
  });
});

describe('saisons et métadonnées de panel', () => {
  test('panelSeasons / panelEpisodeCount : null si absent ou ≤ 0', () => {
    assert.equal(T.panelSeasons({ series_metadata: { season_count: 3 } }), 3);
    assert.equal(T.panelSeasons({ season_count: 0 }), null);
    assert.equal(T.panelEpisodeCount({ series_metadata: { episode_count: 24 } }), 24);
    assert.equal(T.panelEpisodeCount({}), null);
  });
  test('dedupeSeasons : une saison par version originale, la VO conservée', () => {
    const out = T.dedupeSeasons([
      { id: 'vf', season_number: 1, versions: [{ guid: 'vo', original: true }, { guid: 'vf' }] },
      { id: 'vo', season_number: 1, versions: [{ guid: 'vo', original: true }, { guid: 'vf' }] },
      { id: 's2', season_number: 2, versions: [] },
    ]);
    assert.equal(out.length, 2);
    assert.equal(out.find((s) => s.season_number === 1).id, 'vo');
  });
  test('extractGenres : objets tenant_categories → libellés (jamais « [object Object] »)', () => {
    const g = T.extractGenres({ series_metadata: { tenant_categories: [{ tenant_category: 'action', localization: { title: 'Action' } }, 'Comédie', 'Comédie'] } });
    assert.deepEqual([...g], ['Action', 'Comédie']);
  });
});
