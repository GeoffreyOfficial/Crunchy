'use strict';
// v4.34.0 — épisode 1 « réécrit » récupéré (Carnets de l’apothicaire), en-tête de jour sans doublon, plus de « hero », animations.
const { test, describe, beforeEach, afterEach, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { fresh, DAY } = require('./lib/env');
const { seed } = require('./lib/scenarios');
const plain = (v) => JSON.parse(JSON.stringify(v));

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const ep = (id, n, avail, air) => ({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, title: '', avail, air: air === undefined ? avail : air });
const build = (id, title, eps) => T.buildSeriesEntry({ id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } }, eps, Math.max(...eps.map((e) => e.air || e.avail)), null, 0, new Map(), null);

describe('RÉGRESSION Carnets de l’apothicaire : l’épisode 1 réécrit n’efface plus l’épisode 1 ni ne transforme E2 en « reprise »', () => {
  const NOW = Date.parse('2026-10-24T19:00:00Z');
  const S = (n) => Date.parse('2026-10-02T16:00:00Z') + (n - 1) * 7 * DAY;           // E1 le 2 oct., E2 le 9, E3 le 16, E4 le 23
  const mk = (e1Avail) => {
    const old = Date.parse('2025-04-01T12:00:00Z');                                      // saison précédente
    const eps = [ep('AP', 1, old, old)];                                                  // (S1)
    eps[0].season = 1;
    const cur = [1, 2, 3, 4].map((n) => Object.assign(ep('AP', n, n === 1 ? e1Avail : S(n), S(n)), { season: 2 }));
    return build('AP', 'Les Carnets de l’apothicaire', eps.concat(cur));
  };
  test('E1 ré-uploadé le 24 (après E2-E4) : E1 est replacé le 2 octobre, E2 n’est pas une reprise', () => {
    E.setNow(NOW);
    T.STATE.series = [mk(Date.parse('2026-10-24T10:00:00Z'))];
    const ev = T.calReleasedEvents(NOW, Date.parse('2026-09-25T00:00:00Z'), NOW + 1).filter((e) => e.sxe && /^S2/.test(e.sxe));
    assert.deepEqual(plain(ev.map((e) => e.label)), ['E1', 'E2', 'E3', 'E4'], 'E1 présent');
    const e1 = ev.find((e) => e.label === 'E1'), e2 = ev.find((e) => e.label === 'E2');
    assert.equal(T.calDayKey(e1.ts), '2026-10-02'); assert.equal(e1.precision, 'day');
    assert.equal(e1.isNew, true); assert.equal(e2.isNew, false, 'E2 n’est plus une « reprise »');
  });
  test('date de mise en ligne normale : rien ne change', () => {
    E.setNow(NOW);
    T.STATE.series = [mk(S(1))];
    const ev = T.calReleasedEvents(NOW, Date.parse('2026-09-25T00:00:00Z'), NOW + 1).filter((e) => /^S2/.test(e.sxe));
    assert.deepEqual(plain(ev.map((e) => e.label)), ['E1', 'E2', 'E3', 'E4']);
    assert.equal(ev[0].precision, 'time');
  });
  test('date de diffusion incohérente (hors de la suite) : l’épisode reste écarté, pas d’invention', () => {
    const now = E.now();
    const eps = [1, 2, 3].map((n) => ep('Q', n, now - (4 - n) * 7 * DAY));
    eps.push(ep('Q', 4, now - 200 * DAY, now - 200 * DAY));
    T.STATE.series = [build('Q', 'Quatre', eps)];
    const ev = T.calReleasedEvents(now, now - 40 * DAY, now + 1);
    assert.deepEqual(plain(ev.map((e) => e.label)), ['E1', 'E2', 'E3']);
  });
});

describe('en-tête de jour et hero', () => {
  test('titre unique « Vendredi 30 Octobre » + « N sorties » ; badge « aujourd’hui » seul', () => {
    const now = E.now();
    const h = (d) => E.html(T.calDayHeader(now + d * DAY, now, 2, '', true)).querySelector('header');
    for (const d of [-3, 0, 5]) {
      const hd = h(d);
      assert.match(hd.querySelector('b').textContent, /^[A-ZÉ][a-zéû]+ \d{1,2} [A-ZÉ][a-zéû]+/);
      assert.equal(hd.querySelector('small').textContent, '2 sorties');
      assert.equal(!!hd.querySelector('.crrav-calwhen'), d === 0); assert.equal(hd.querySelector('.crrav-caldnum'), null);
    }
    assert.equal(h(1).querySelector('small').textContent, 'Demain · 2 sorties');
  });
  test('plus de bloc « prochaine sortie » (crrav-calhero) ni de CSS associé', () => {
    T.STATE.series = [build('A', 'Alpha', [ep('A', 1, E.now() - 3 * DAY)])];
    assert.doesNotMatch(T.renderCalendrier(), /crrav-calhero|PROCHAINE SORTIE/);
    assert.doesNotMatch(T.CSS, /crrav-calhero|crrav-calhbtn/);
  });
});

describe('animation d’entrée : seulement sur une vraie navigation', () => {
  test('ouverture et changement de vue/filtre : classe « enter » ; rafraîchissement en fond : pas de rejeu', () => {
    T.STATE.series = [build('A', 'Alpha', [ep('A', 1, E.now() - 3 * DAY)])];
    assert.match(T.renderCalendrier(), /class="crrav-cal enter"/);
    assert.doesNotMatch(T.renderCalendrier(), /class="crrav-cal enter"/, 'deuxième rendu (fond) : pas d’animation');
    T.calHandleAct({ dataset: { act: 'cal-view', v: 'week' } });
    assert.match(T.renderCalendrier(), /class="crrav-cal enter"/, 'changement de vue : animation');
    assert.doesNotMatch(T.renderCalendrier(), /class="crrav-cal enter"/);
    T.calHandleAct({ dataset: { act: 'cal-open', calkey: 'x' } });
    assert.doesNotMatch(T.renderCalendrier(), /class="crrav-cal enter"/, 'ouvrir une carte ne rejoue rien');
  });
});

function loadPlaywright() { for (const m of ['playwright-core', 'playwright', '/opt/npm-tools/node_modules/playwright']) { try { return require(m); } catch (_) { /* suivant */ } } return null; }
const PW = process.env.CRRAV_E2E === '0' ? null : loadPlaywright();
const EXE = [process.env.CRRAV_CHROMIUM, '/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find((p) => p && fs.existsSync(p));
describe('Chromium réel : animations jouées, puis survol possible (pas de transform figé)', { skip: !PW || !EXE ? 'Chromium absent' : false }, () => {
  let browser, html;
  before(async () => {
    browser = await PW.chromium.launch({ executablePath: EXE });
    const e = fresh(); seed(e, {}); e.T.STATE.tab = 'suivi'; e.T.STATE.filters.calScope = 'all'; e.T.openCalendar(); await e.tick(60);
    html = '<!doctype html>' + e.w.document.documentElement.outerHTML; e.close();
  });
  after(async () => { if (browser) await browser.close(); });
  test('entrée en cascade (jour + tuiles), puis la tuile se soulève au survol', async () => {
    const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
    try {
      await page.route('**/*', (r) => (/^(data|about|blob):/.test(r.request().url()) ? r.continue() : r.abort()));
      await page.setContent(html, { waitUntil: 'load' });
      const a = await page.evaluate(() => ({ card: getComputedStyle(document.querySelector('.crrav-calcard')).animationName, sec: getComputedStyle(document.querySelector('.crrav-agsec')).animationName,
        delays: [...document.querySelectorAll('.crrav-agsec')].slice(0, 3).map((n) => getComputedStyle(n).animationDelay) }));
      assert.equal(a.card, 'crrav-cardin'); assert.equal(a.sec, 'crrav-secin'); assert.ok(new Set(a.delays).size > 1, 'cascade : ' + a.delays);
      await page.waitForTimeout(1600);
      const c = page.locator('.crrav-calcard').nth(1); await c.scrollIntoViewIfNeeded(); await c.hover(); await page.waitForTimeout(450);
      const t = await c.evaluate((el) => getComputedStyle(el).transform);
      assert.notEqual(t, 'none', 'la tuile survolée est soulevée / agrandie : ' + t);
      const op = await page.evaluate(() => { const f = document.querySelector('.crrav-calcard.fut, .crrav-calcard.seen'); return f ? parseFloat(getComputedStyle(f).opacity) : null; });
      assert.ok(op == null || op <= 0.95, 'les tuiles grisées le restent après l’animation : ' + op);
    } finally { await page.close(); }
  });
});
