'use strict';
// Calculs « Reste à voir » : vu/commencé, reprise, temps restant, films, cases de
// progression (régressions v3.90 → v3.94), saison prévue AniList, calendrier.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.CFG.watchedRatio = 0.9; });
afterEach(() => E.close());

const ph = (entries) => new Map(Object.entries(entries));

describe('seenState (seuil « vu »)', () => {
  const e = { ids: ['a', 'b'], dur: 1000 };
  test('drapeau fully_watched = vu', () => assert.equal(T.seenState(e, ph({ a: { p: 0, full: true } })), 'seen'));
  test('≥ 90 % = vu même sans drapeau', () => assert.equal(T.seenState(e, ph({ a: { p: 900 } })), 'seen'));
  test('< 90 % = commencé', () => assert.equal(T.seenState(e, ph({ a: { p: 899 } })), 'started'));
  test('n’importe quelle version audio compte (VF vue, VO non)', () => assert.equal(T.seenState(e, ph({ b: { p: 1000 } })), 'seen'));
  test('rien = none', () => assert.equal(T.seenState(e, ph({})), 'none'));
  test('seuil réglable', () => { T.CFG.watchedRatio = 0.5; assert.equal(T.seenState(e, ph({ a: { p: 600 } })), 'seen'); });
});

describe('buildSeriesEntry (cartes)', () => {
  const panel = { id: 'S', title: 'Série', slug_title: 's', series_metadata: { tenant_categories: ['Action'] } };
  const eps = [1, 2, 3, 4].map((n) => ({ season: 1, n, dur: 1440, ids: ['e' + n], id: 'e' + n, air: E => 0 }));
  test('compteurs, pourcentage, temps restant', () => {
    const s = T.buildSeriesEntry(panel, eps.map((e) => ({ ...e, air: null })), null, 4.5, 0,
      ph({ e1: { full: true, t: 10 }, e2: { full: true, t: 20 } }), null);
    assert.equal(s.total, 4); assert.equal(s.seen, 2); assert.equal(s.remaining, 2);
    assert.equal(s.pct, 50); assert.equal(s.secLeft, 2 * 1440);
    assert.equal(s.next.n, 3); assert.equal(s.resuming, false);
    assert.equal(s.lastWatchedTs, 20); assert.equal(s.lastSeen.n, 2);
  });
  test('reprise intelligente : l’épisode commencé passe devant le premier non vu', () => {
    const s = T.buildSeriesEntry(panel, eps.map((e) => ({ ...e, air: null })), null, null, 0,
      ph({ e3: { p: 300 } }), null);
    assert.equal(s.next.n, 3); assert.equal(s.resuming, true); assert.equal(s.inProgress, 1);
  });
  test('favori = note perso 5★', () => {
    const s = T.buildSeriesEntry(panel, [], null, null, 0, ph({}), 5);
    assert.equal(s.favorite, true); assert.equal(s.pct, 0);
    assert.equal(T.buildSeriesEntry(panel, [], null, null, 0, ph({}), 4).favorite, false);
  });
  test('genres CR complétés par le cache AniList (sans requête)', () => {
    T.cacheSet('anilist:S', { av: T.ANILIST_CACHE_VER, matched: true, genres: ['Comédie', 'action'], tags: [{ name: 'Magic', rank: 80 }] });
    const s = T.buildSeriesEntry(panel, [], null, null, 0, ph({}), null);
    assert.deepEqual([...s.categories], ['Action', 'Comédie']);
    assert.equal(s.tags[0].name, 'Magic');
  });
  test('en diffusion : selon la fenêtre airingWindowDays', () => {
    T.CFG.airingWindowDays = 21;
    assert.equal(T.buildSeriesEntry(panel, [], E.now() - 5 * DAY, null, 0, ph({}), null).airing, true);
    assert.equal(T.buildSeriesEntry(panel, [], E.now() - 30 * DAY, null, 0, ph({}), null).airing, false);
  });
  test('saison de référence AniList = saison du prochain épisode', () => {
    const two = [...eps.map((e) => ({ ...e, air: null })), { season: 2, n: 1, dur: 1440, ids: ['f1'], id: 'f1', air: null }];
    const s = T.buildSeriesEntry(panel, two, null, null, 0, ph({ e1: { full: true }, e2: { full: true }, e3: { full: true }, e4: { full: true } }), null);
    assert.equal(s.targetSeason, 2); assert.equal(s.targetSeasonSeen, 0);
  });
});

describe('films (détection sur la durée, jamais sur le titre)', () => {
  const jjk = () => series('JJK', [
    ...Array.from({ length: 24 }, (_, i) => ep(1, i + 1, { seen: true })),
    ep(2, 1, { dur: 6000, seen: true, title: 'Jujutsu Kaisen 0', id: 'MOVIE' }),
    ...Array.from({ length: 23 }, (_, i) => ep(3, i + 1, { seen: i < 10 })),
  ]);
  test('splitMovies sépare films et épisodes', () => {
    const sp = T.splitMovies(jjk());
    assert.equal(sp.filmTotal, 1); assert.equal(sp.epTotal, 47); assert.equal(sp.epSeen, 34);
    assert.equal(sp.epNext.season, 3); assert.equal(sp.epNext.n, 11);
  });
  test('un épisode long isolé dans une saison = film ; 2 épisodes longs = pas un film', () => {
    assert.ok(T.splitMovies(series('A', [ep(1, 1), ep(2, 1, { dur: 3600 })])));
    assert.equal(T.splitMovies(series('B', [ep(1, 1), ep(2, 1, { dur: 3600 }), ep(2, 2, { dur: 3600 })])), null);
    assert.equal(T.splitMovies(series('C', [ep(1, 1), ep(2, 1, { dur: 3599 })])), null, 'seuil 60 min');
  });
  test('série 100 % films : pas de séparation', () => assert.equal(T.splitMovies(series('F', [ep(1, 1, { dur: 7000 })])), null));
  test('seenLabel compte les épisodes hors films', () => assert.match(T.seenLabel(jjk()), /^34\/47 ép\./));
  test('nextIsMovie (v3.94.0 : « Reprendre · Film » au lieu de « S3 E1 »)', () => {
    const s = series('X', [ep(1, 1, { seen: true }), ep(2, 1, { dur: 6000 })]);
    assert.equal(T.nextIsMovie(s), true);
    assert.equal(T.nextIsMovie(series('Y', [ep(1, 1), ep(1, 2)])), false);
  });
});

describe('resumeLink', () => {
  test('épisodes restants : « Suivant · S3 E11 » (libellé court v3.94.0)', () => {
    const s = series('S', [ep(1, 1, { seen: true }), ep(1, 2), ep(2, 1, { dur: 6000, id: 'M' })]);
    const a = E.html(T.resumeLink(s, 'crrav-resume')).querySelector('a');
    assert.match(a.title, /Suivant · S1 E2/);
    assert.doesNotMatch(a.textContent, /Épisode suivant/);
  });
  test('tous les épisodes vus, film restant : « Film · Titre »', () => {
    const s = series('S', [ep(1, 1, { seen: true }), ep(2, 1, { dur: 6000, id: 'M', title: 'Le Film' })]);
    const a = E.html(T.resumeLink(s, 'r')).querySelector('a');
    assert.match(a.title, /Film · Le Film/);
    assert.ok(a.classList.contains('movie'));
    assert.match(a.getAttribute('href'), /\/watch\/M$/);
  });
  test('rien à voir : aucun bouton', () => {
    const s = series('S', [ep(1, 1, { seen: true }), ep(2, 1, { dur: 6000, seen: true })]);
    assert.equal(T.resumeLink(s, 'r'), '');
  });
  test('jamais commencé : « Commencer »', () => {
    const a = E.html(T.resumeLink(series('S', [ep(1, 1), ep(1, 2)]), 'r')).querySelector('a');
    assert.match(a.title, /Commencer/);
  });
});

describe('cases de progression ticks() — régressions v3.90 → v3.94', () => {
  const q = (html, sel) => E.html(html).querySelectorAll(sel);
  test('saison entièrement vue (≥ 4 ép.) fusionnée en bloc libellé', () => {
    const s = series('S', [...Array.from({ length: 12 }, (_, i) => ep(1, i + 1, { seen: true })), ep(2, 1), ep(2, 2)]);
    const h = T.ticks(s);
    assert.equal(q(h, '.season-block.labeled').length, 1);
    assert.match(E.html(h).textContent, /S1 · 12 ép\./);
  });
  test('saison en cours jamais fusionnée, même entièrement vue', () => {
    const s = series('S', Array.from({ length: 6 }, (_, i) => ep(1, i + 1, { seen: i < 5 })));
    assert.equal(q(T.ticks(s), '.season-block').length, 0);
  });
  test('film vu (1 épisode ≥ 60 min) fusionné malgré le seuil de 4 (v3.90.0)', () => {
    const s = series('S', [ep(1, 1, { dur: 6000, seen: true }), ep(2, 1), ep(2, 2)]);
    const blk = q(T.ticksCore(s), '.season-block.movie');
    assert.equal(blk.length, 1);
    assert.match(blk[0].textContent, /Film · 1 h 40/);
  });
  test('film pas encore vu : case normale teintée (movie-pending)', () => {
    const s = series('S', [ep(1, 1, { seen: true }), ep(2, 1, { dur: 6000 })]);
    // le film fait partie de la saison « en cours » ou non ; dans tous les cas il reste identifiable
    assert.ok(q(T.ticksCore(s), '.movie-pending').length === 1);
  });
  test('place du libellé calculée sur les cases réellement détaillées, pas le total (v3.91.0, JJK 59/60)', () => {
    const s = series('S', [...Array.from({ length: 48 }, (_, i) => ep(1, i + 1, { seen: true })), ...Array.from({ length: 12 }, (_, i) => ep(2, i + 1, { seen: i < 11 }))]);
    assert.equal(q(T.ticks(s), '.season-block.labeled').length, 1, 'total 60 mais 12 cases détaillées : le texte tient');
  });
  test('2+ blocs déjà vus → UNE pastille récapitulative de largeur constante (v3.94.0)', () => {
    const s = series('S', [
      ...Array.from({ length: 25 }, (_, i) => ep(1, i + 1, { seen: true })),
      ...Array.from({ length: 26 }, (_, i) => ep(2, i + 1, { seen: true })),
      ep(3, 1, { dur: 6000, seen: true }),
      ...Array.from({ length: 12 }, (_, i) => ep(4, i + 1, { seen: i < 3 })),
    ]);
    const blocks = q(T.ticksCore(s), '.crrav-season-done');
    assert.equal(blocks.length, 1);
    assert.match(blocks[0].textContent, /3 vues/);
    assert.match(blocks[0].querySelector('span').title, /Saison 1[\s\S]*Saison 2[\s\S]*Film/);
  });
  test('ticks() retire les films des cases quand ils sont séparés (bouton clap, v3.99.0)', () => {
    const s = series('S', [...Array.from({ length: 12 }, (_, i) => ep(1, i + 1, { seen: true })), ep(2, 1, { dur: 6000, seen: true }), ep(3, 1), ep(3, 2)]);
    const h = T.ticks(s);
    assert.equal(q(h, '.season-block.movie').length, 0);
    assert.equal(q(h, '.movie-pending').length, 0);
    assert.equal(q(h, '.season-block.labeled').length, 1, 'S1 seule reste fusionnée');
  });
  test('libellés du récapitulatif : saisons seules / films seuls', () => {
    const g = (isMovie, num) => ({ num, isMovie, eps: [{ dur: 6000 }, { dur: 1 }, { dur: 1 }, { dur: 1 }] });
    assert.match(T.doneSummaryBlock([g(false, 1), g(false, 2)], true), /2 saisons vues/);
    assert.match(T.doneSummaryBlock([g(true, 1), g(true, 2)], true), /2 films vus/);
    assert.doesNotMatch(T.doneSummaryBlock([g(false, 1), g(false, 2)], false), /<b>/, 'sans place : icône seule');
  });
  test('épisodes annoncés pas encore sortis (AniList) en cases « upcoming »', () => {
    const s = series('S', Array.from({ length: 4 }, (_, i) => ep(1, i + 1, { seen: i < 2 })), { airing: true, plannedTotal: 12, targetSeason: 1 });
    assert.equal(q(T.ticks(s), '.upcoming').length, 8);
  });
  test('> 120 épisodes : barre continue au lieu des cases', () => {
    const s = series('S', Array.from({ length: 130 }, (_, i) => ep(1, i + 1, { seen: i < 13 })));
    assert.equal(q(T.ticks(s), '.crrav-bar').length, 1);
    assert.equal(q(T.ticks(s), '.crrav-tick').length, 0);
  });
});

describe('saison prévue (AniList) et calendrier', () => {
  test('plannedRemaining compare à la saison en cours, pas au cumul CR', () => {
    assert.equal(T.plannedRemaining({ plannedTotal: 14, targetSeasonSeen: 10 }), 4);
    assert.equal(T.plannedRemaining({ plannedTotal: 14, targetSeasonSeen: 20 }), 0);
    assert.equal(T.plannedRemaining({ plannedTotal: null }), null);
  });
  test('plannedTotalHint seulement si AniList annonce plus que ce qui est sorti', () => {
    const s = series('S', Array.from({ length: 6 }, (_, i) => ep(1, i + 1)), { airing: true, plannedTotal: 12, targetSeason: 1 });
    assert.match(T.plannedTotalHint(s), /12 prévus/);
    assert.equal(T.plannedTotalHint({ ...s, plannedTotal: 6 }), '');
    assert.equal(T.plannedTotalHint({ ...s, airing: false }), '');
  });
  test('sureNextRelease : uniquement une date AniList confirmée et future', () => {
    const now = E.now();
    assert.deepEqual({ ...T.sureNextRelease({ s: { aniNextTs: now + DAY, aniNextNum: 5 } }, now) }, { ts: now + DAY, n: 5, exact: true, hasTime: true });
    assert.equal(T.sureNextRelease({ s: { aniNextTs: now - 1, aniNextNum: 5 } }, now), null, 'date passée');
    assert.equal(T.sureNextRelease({ s: { aniNextTs: now + DAY } }, now), null, 'sans numéro');
    assert.equal(T.sureNextRelease({ s: { aniNextTs: now + DAY, aniNextNum: 13, plannedTotal: 12 } }, now), null, 'au-delà du total prévu');
  });
  test('estimatedSchedule : prochaine sortie strictement future, numéro = dernier + semaines écoulées', () => {
    T.CFG.airingWindowDays = 21;
    const air = E.now() - 15 * DAY + 3600e3;
    const s = series('S', [ep(1, 1, { air: air - 7 * DAY }), ep(1, 2, { air })], { airing: true, lastAired: { season: 1, n: 2, air } });
    const [r] = T.estimatedSchedule([s]);
    assert.ok(r.nextTs > E.now());
    assert.equal(r.nextNum, 2 + 3, '15 j depuis la dernière sortie → 3 semaines sautées');
  });
  test('estimatedSchedule ignore les séries hors fenêtre de diffusion et les ignorées', () => {
    T.CFG.airingWindowDays = 21;
    const old = E.now() - 40 * DAY;
    const s = series('OLD', [ep(1, 1, { air: old })], { airing: true, lastAired: { season: 1, n: 1, air: old } });
    assert.equal(T.estimatedSchedule([s]).length, 0);
  });
});
