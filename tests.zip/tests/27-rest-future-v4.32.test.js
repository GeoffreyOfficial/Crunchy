'use strict';
// v4.32.0 — « Reste de Crunchyroll » : les épisodes À VENIR des séries hors de tes listes (dates AniList) sont affichés.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
const ANI = /graphql\.anilist\.co/;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

const sec = (days) => Math.floor(E.now() / 1000) + Math.round(days * 86400);
const media = (id, o = {}) => ({ id, title: { english: o.title || 'Live ' + id, romaji: 'Romaji ' + id }, format: o.format || 'TV', genres: o.genres || ['Action'],
  coverImage: { large: 'https://img/' + id + '.jpg' }, season: 'FALL', seasonYear: 2026, averageScore: o.score === undefined ? 78 : o.score,
  nextAiringEpisode: { episode: o.n || 5, airingAt: sec(o.d === undefined ? 2 : o.d) },
  airingSchedule: { nodes: o.nodes || [{ episode: (o.n || 5) + 1, airingAt: sec((o.d === undefined ? 2 : o.d) + 7) }] },
  externalLinks: o.links === undefined ? [{ site: 'Crunchyroll', url: `https://www.crunchyroll.com/series/L${id}ABC/live-${id}`, type: 'STREAMING' }] : o.links });
const mockAni = (list) => E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: list } } }));
const air = (sources, view = 'agenda', horizon = 30) => T.calModel(Object.assign(T.calOpts(), { horizon, view, sources }), E.now()).events.filter((e) => e.type === 'air' && e.crSource === 'anilist');

describe('chargement AniList des séries en cours sur Crunchyroll', () => {
  test('requête : statut RELEASING + licence Crunchyroll (id 5) + prochains épisodes', async () => {
    const bodies = [];
    E.net.on(ANI, (u, o) => { bodies.push(String((o && o.body) || '')); return { data: { Page: { pageInfo: { hasNextPage: false }, media: [] } } }; });
    await T.loadAniLive(true);
    assert.equal(bodies.length, 1);
    assert.match(bodies[0], /status: RELEASING/); assert.match(bodies[0], /licensedById_in: \[5\]/); assert.match(bodies[0], /airingSchedule\(notYetAired: true/);
  });
  test('films, genres exclus, séries sans épisode à venir écartés ; épisodes passés ignorés', async () => {
    mockAni([media(1), media(2, { format: 'MOVIE' }), media(3, { genres: ['Hentai'] }), Object.assign(media(4), { nextAiringEpisode: null, airingSchedule: { nodes: [] } }),
      media(5, { d: -1, nodes: [{ episode: 9, airingAt: sec(3) }] })]);
    await T.loadAniLive(true);
    assert.deepEqual(plain(T.STATE.aniLive.items.map((i) => i.aniId).sort()), [1, 5]);
    assert.deepEqual(plain(T.STATE.aniLive.items.find((i) => i.aniId === 5).eps.map((e) => e.n)), [9], 'E5 (passé) retiré');
  });
  test('erreur GraphQL sur licensedById_in → repli licensedById ; échec total → note d’erreur, cache conservé', async () => {
    const args = []; let down = false;
    E.net.on(ANI, (u, o) => { if (down) return { errors: [{ message: 'boom' }] }; const b = String((o && o.body) || ''); args.push(/licensedById_in/.test(b) ? 'in' : 'eq'); return /licensedById_in/.test(b) ? { errors: [{ message: 'Unknown argument' }] } : { data: { Page: { pageInfo: { hasNextPage: false }, media: [media(1)] } } }; });
    await T.loadAniLive(true);
    assert.deepEqual(plain(args), ['in', 'eq']); assert.equal(T.STATE.aniLive.items.length, 1);
    T.anilistClearCooldown();
    down = true;
    await T.loadAniLive(true);
    assert.ok(T.STATE.aniLive.error); assert.equal(T.STATE.aniLive.items.length, 1, 'anciennes données gardées');
  });
});

describe('événements « Reste de Crunchyroll » dans le futur', () => {
  test('visibles seulement si « Reste de Crunchyroll » est coché ; en Agenda, Semaine et Mois', async () => {
    mockAni([media(1, { d: 2 })]);
    await T.loadAniLive(true);
    assert.equal(air(['mine', 'new']).length, 0, 'source décochée : rien');
    for (const v of ['agenda', 'week', 'month']) {
      const ev = air(['mine', 'new', 'rest'], v, 30);
      assert.ok(ev.some((e) => e.n === 5), v);
    }
    assert.deepEqual(plain(air(['rest']).map((e) => e.n).sort()), [5, 6]);
    const e = air(['rest'])[0];
    assert.equal(e.released, false); assert.equal(e.precision, 'time'); assert.equal(e.score, null); assert.equal(e.ani, 3.9, 'note AniList 78/100 → 3,9/5');
    assert.match(e.urls.web, /series\/L1ABC/);
  });
  test('séries de mes listes, séries ignorées et doublons de titre : jamais en double', async () => {
    const now = E.now();
    const mine = { id: 'L1ABC', title: 'Live 1', eps: [], epsList: [] };
    mockAni([media(1), media(2, { title: 'Ma série' }), media(3), media(4, { title: 'Même' }), media(8, { title: 'Même' })]);
    await T.loadAniLive(true);
    T.STATE.series = [Object.assign(T.buildSeriesEntry({ id: 'L1ABC', title: 'Live 1', slug_title: 'live-1', images: {}, series_metadata: { tenant_categories: [] } },
      [{ season: 1, n: 1, id: 'a', ids: ['a'], dur: 1440, title: '', avail: now - 3 * DAY, air: now - 3 * DAY }], now - 3 * DAY, null, 0, new Map(), null))];
    T.STATE.series.push(Object.assign(T.buildSeriesEntry({ id: 'XX', title: 'Ma série', slug_title: 'ma-serie', images: {}, series_metadata: { tenant_categories: [] } },
      [{ season: 1, n: 1, id: 'b', ids: ['b'], dur: 1440, title: '', avail: now - 3 * DAY, air: now - 3 * DAY }], now - 3 * DAY, null, 0, new Map(), null)));
    T.IGNORED.set('L3ABC', { title: '', source: 'newpremieres', ignoredAt: 0 });
    const ids = new Set(air(['rest']).map((e) => e.title));
    assert.ok(!ids.has('Live 1'), 'dans mes listes (même fiche)'); assert.ok(!ids.has('Ma série'), 'dans mes listes (même titre)');
    assert.ok(!ids.has('Live 3'), 'ignorée'); assert.equal(air(['rest']).filter((e) => e.title === 'Même').length, 2, 'un seul titre (E5+E6), pas deux séries');
  });
  test('épisode déjà daté par le catalogue Crunchyroll : la date AniList ne double pas la carte', async () => {
    const now = E.now();
    mockAni([media(1, { d: 2, nodes: [] })]);
    await T.loadAniLive(true);
    T.STATE.crNew.items = [{ id: 'L1ABC', title: 'Live 1', poster: '', wide: '', synopsis: '', categories: [], ts: now + 2 * DAY, firstN: 5, rank: 1, crId: 'L1ABC', crSlug: 'x', crSource: 'crunchyroll',
      eps: [{ id: 'e5', n: 5, t: '', ts: now + 2 * DAY }] }];
    assert.equal(air(['rest']).length, 0);
  });
  test('rendu : carte grisée (futur), note ★ et libellé ; la source décochée la retire', async () => {
    mockAni([media(1)]);
    await T.loadAniLive(true);
    T.STATE.series = [T.buildSeriesEntry({ id: 'Z0', title: 'Zéro', slug_title: 'zero', images: {}, series_metadata: { tenant_categories: [] } },
      [{ season: 1, n: 1, id: 'z', ids: ['z'], dur: 1440, title: '', avail: E.now() - 2 * DAY, air: E.now() - 2 * DAY }], E.now() - 2 * DAY, null, 0, new Map(), null)];
    T.STATE.filters.calSources = ['mine', 'rest'];
    const dom = E.html(T.renderCalendrier());
    const card = [...dom.querySelectorAll('.crrav-calcard')].find((c) => /Live 1/.test(c.textContent));
    assert.ok(card, 'carte affichée'); assert.match(card.className, /fut/); assert.match(card.textContent, /E5/);
    T.STATE.filters.calSources = ['mine'];
    const dom2 = E.html(T.renderCalendrier());
    assert.ok(![...dom2.querySelectorAll('.crrav-calcard')].some((c) => /Live 1/.test(c.textContent)));
  });
  test('cocher « Reste de Crunchyroll » déclenche le chargement (une seule fois)', async () => {
    let n = 0;
    E.net.on(ANI, () => { n++; return { data: { Page: { pageInfo: { hasNextPage: false }, media: [media(1)] } } }; });
    T.STATE.filters.calSources = ['mine'];
    T.calEnsureAniLive(); await E.tick(30); assert.equal(n, 0, 'non coché : aucune requête');
    T.STATE.filters.calSources = ['mine', 'rest'];
    T.calEnsureAniLive(); T.calEnsureAniLive(); await E.tick(30);
    assert.equal(n, 1); assert.equal(T.STATE.aniLive.items.length, 1);
  });
});
