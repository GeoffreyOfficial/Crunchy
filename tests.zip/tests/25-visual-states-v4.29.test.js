'use strict';
// v4.29.0 — Lisibilité « qu'est-ce que j'ai à voir » : à venir = grisé ; sorti et vu = grisé + ✓ Vu ; sorti et pas vu = normal.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());

function mk(id, title, nEps, seen) {
  const now = E.now(), eps = [];
  for (let n = 1; n <= nEps; n++) { const air = now - (nEps - n) * 7 * DAY - 2 * DAY; eps.push({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, air, avail: air, title: '' }); }
  const ph = new Map(eps.slice(0, seen).map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
  s.aniNextTs = now + 3 * DAY; s.aniNextNum = nEps + 1; s.plannedTotal = 12; s.poster = '';
  return s;
}
const cards = (view) => {
  T.STATE.filters.calView = view;
  const d = E.html(T.renderCalendrier());
  return [...d.querySelectorAll('.crrav-calcard')];
};

describe('états visuels des cartes', () => {
  test('semaine : épisode à venir grisé (fut), vu = grisé + ✓ Vu, sorti pas vu = normal', () => {
    T.STATE.series = [mk('A', 'Alpha', 4, 3)];                  // E1-E3 vus, E4 sorti il y a 2 j (pas vu), E5 dans 3 j (à venir)
    const cs = cards('week');
    const by = (re) => cs.filter((c) => re.test(c.getAttribute('data-calkey') || ''));
    const out = cs.filter((c) => c.classList.contains('out'));
    const unseen = out.filter((c) => c.classList.contains('unseen'));
    const seen = out.filter((c) => c.classList.contains('seen'));
    const fut = cs.filter((c) => c.classList.contains('fut'));
    assert.ok(unseen.length === 1, 'un épisode sorti pas vu'); assert.ok(!unseen[0].classList.contains('fut'), 'normal, pas grisé');
    assert.ok(fut.length >= 1 && fut.every((c) => !c.classList.contains('out')), 'à venir : grisé');
    for (const c of seen) assert.match(c.textContent, /✓ Vu/);
    assert.ok(unseen[0].textContent.includes('À voir'));
    assert.ok(by(/./).length === cs.length);
  });
  test('un épisode sorti n’est jamais « fut » ; une nouveauté déjà sortie non plus ; une annonce future oui', () => {
    const now = E.now();
    assert.equal(T.calIsFuture({ type: 'out', ts: now - 1, precision: 'time' }, now), false);
    assert.equal(T.calIsFuture({ type: 'ep', ts: now + 3600e3, precision: 'time' }, now), true);
    assert.equal(T.calIsFuture({ type: 'prem', released: true, ts: now - DAY, precision: 'time' }, now), false);
    assert.equal(T.calIsFuture({ type: 'prem', released: false, ts: now + 30 * DAY, precision: 'month' }, now), true);
    const noon = T.calStartOfDay(now) + 12 * 3600e3;
    assert.equal(T.calIsFuture({ type: 'prem', released: false, ts: noon, precision: 'day' }, noon - 5 * 3600e3), false, 'sortie « aujourd’hui » (jour seul) : déjà regardable');
    assert.equal(T.calIsFuture({ type: 'air', ts: now - 3600e3, precision: 'time' }, now), false);
  });
  test('vue Mois : vignettes grisées (fut / vu)', () => {
    T.STATE.series = [mk('A', 'Alpha', 4, 3)];
    T.STATE.filters.calView = 'month';
    const d = E.html(T.renderCalendrier());
    assert.ok(d.querySelector('.crrav-calth.vu, .crrav-calmini.vu') || d.querySelector('.crrav-calth.fut, .crrav-calmini.fut'), 'au moins une vignette grisée');
    assert.ok([...d.querySelectorAll('.crrav-calth')].every((c) => !(c.classList.contains('fut') && c.classList.contains('vu'))), 'jamais les deux');
    assert.ok([...d.querySelectorAll('.crrav-calth.out')].every((c) => c.classList.contains('vu')), 'tout « vu » est marqué');
  });
});
