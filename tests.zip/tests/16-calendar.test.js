'use strict';
// v4.19.0 — Calendrier : agenda des sorties (vues Agenda / Semaine / Mois, horizon jusqu'à un an,
// nouveautés lointaines AniList, séries ignorées jamais affichées, export .ics, robustesse).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
const ANI = /graphql\.anilist\.co/;
// (v4.24.0) Nouvelle série lue chez Crunchyroll : { id, title, ts de l'épisode 1, + épisodes suivants }.
const crSeries = (id, title, ts, more = [], o = {}) => ({ id, title, poster: '', wide: o.wide || '', synopsis: '', categories: o.categories || ['Action'], ts, firstN: 1, rank: 1, crId: id, crSlug: id.toLowerCase(), crSource: 'crunchyroll',
  eps: [ts].concat(more).map((t, i) => ({ id: id + 'e' + (i + 1), n: i + 1, t: '', ts: t })) });
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

// Série en diffusion : `nEps` épisodes déjà sortis (hebdo), le prochain annoncé par AniList dans `inDays` jours.
function mk(id, title, o = {}) {
  const now = E.now();
  const nEps = o.nEps ?? 5, seen = o.seen ?? nEps;
  const eps = [];
  for (let n = 1; n <= nEps; n++) {
    const air = now - (nEps - n) * 7 * DAY - 2 * DAY;
    eps.push({ season: 1, n, id: `${id}e${n}`, ids: [`${id}e${n}`], dur: 1440, air, avail: air, title: '' });
  }
  const ph = new Map(eps.slice(0, seen).map((e) => [e.id, { p: 1440, full: true }]));
  const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
  const s = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, o.rating ?? null);
  if (o.noNext !== true) { s.aniNextTs = now + (o.inDays ?? 3) * DAY; s.aniNextNum = nEps + 1; }
  s.plannedTotal = o.total === undefined ? 12 : o.total;
  if (o.future) s.aniFuture = o.future;
  s.poster = o.poster ?? '';
  return s;
}
const opts = (over = {}) => ({ view: 'agenda', horizon: 365, filter: 'all', proj: true, est: false, onlyCr: false, ...over });
const evs = (m, type) => m.events.filter((e) => e.type === type);

describe('épisodes : au-delà de la semaine', () => {
  test('projection hebdomadaire jusqu’au total prévu, sans jamais le dépasser', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 12 })];            // prochain = E6 dans 3 j
    const m = T.calModel(opts(), E.now());
    const a = evs(m, 'ep');
    assert.deepEqual(plain(a.map((e) => e.n)), [6, 7, 8, 9, 10, 11, 12]);
    assert.equal(a.filter((e) => e.final).length, 1);
    assert.equal(a[a.length - 1].final, true);
    for (let i = 1; i < a.length; i++) assert.equal(a[i].ts - a[i - 1].ts, 7 * DAY);
    assert.equal(a[0].exact, true); assert.equal(a[1].exact, false);
  });
  test('l’horizon borne la liste (7 j = le prochain seulement, 30 j = ~5)', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: 24 })];
    assert.equal(evs(T.calModel(opts({ horizon: 7 }), E.now()), 'ep').length, 1);
    const n30 = evs(T.calModel(opts({ horizon: 30 }), E.now()), 'ep').length;
    assert.ok(n30 >= 4 && n30 <= 5, 'n30=' + n30);
  });
  test('projection désactivée : uniquement la prochaine sortie annoncée', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    assert.equal(evs(T.calModel(opts({ proj: false }), E.now()), 'ep').length, 1);
  });
  test('total inconnu : projection plafonnée (jamais 52 semaines inventées)', () => {
    T.STATE.series = [mk('A', 'Alpha', { total: null })];
    const n = evs(T.calModel(opts(), E.now()), 'ep').length;
    assert.ok(n > 1 && n <= 13, 'n=' + n);
  });
  test('dates exactes d’AniList (semaine de pause) prioritaires sur la projection', () => {
    const now = E.now();
    const s = mk('A', 'Alpha', { total: 9, future: [[7, now + 10 * DAY], [8, now + 17 * DAY], [9, now + 24 * DAY]] });
    T.STATE.series = [s];
    const a = evs(T.calModel(opts(), now), 'ep');
    assert.deepEqual(plain(a.map((e) => e.n)), [6, 7, 8, 9]);
    assert.equal(a[1].ts, now + 10 * DAY, 'pause d’une semaine respectée (3 j puis 10 j)');
    assert.ok(a.every((e) => e.exact), 'toutes annoncées');
  });
  test('numérotation continue (S3 = 49-51) : « E4 » et jamais E52', () => {
    const now = E.now();
    const eps = [];
    const add = (season, n, age) => eps.push({ season, n, id: `e${n}`, ids: [`e${n}`], dur: 1440, air: now - age * DAY, avail: now - age * DAY, title: '' });
    for (let n = 1; n <= 24; n++) add(1, n, 400 - n);
    for (let n = 25; n <= 48; n++) add(2, n, 200 - n);
    for (let n = 49; n <= 51; n++) add(3, n, (51 - n) * 7 + 3);
    const ph = new Map(eps.map((e) => [e.id, { p: 1440, full: true }]));
    const s = T.buildSeriesEntry({ id: 'APO', title: 'Apo', slug_title: 'apo', images: {}, series_metadata: { tenant_categories: [] } },
      eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
    s.aniNextTs = now + 4 * DAY; s.aniNextNum = 4; s.plannedTotal = 12;
    T.STATE.series = [s];
    const a = evs(T.calModel(opts(), now), 'ep');
    assert.equal(a[0].n, 4); assert.equal(a[3].n, 7);
    assert.match(a[0].label, /^S3 E4$/);
    assert.doesNotMatch(T.renderCalendrier(), /E5[0-9]/);
  });
  test('sans date AniList : absente par défaut (signalée), présente et marquée « estimée » sur demande', () => {
    T.STATE.series = [mk('A', 'Alpha', { noNext: true })];
    const m0 = T.calModel(opts(), E.now());
    assert.equal(m0.events.length, 0);
    assert.equal(m0.noDate.length, 1);
    const m1 = T.calModel(opts({ est: true }), E.now());
    assert.ok(m1.events.length >= 1 && m1.events.every((e) => e.est));
    assert.match(T.renderCalendrier(), /sans date annoncée/);
  });
  test('le héros est la sortie confirmée la plus proche, quelle que soit la vue', () => {
    T.STATE.series = [mk('A', 'Alpha', { inDays: 5 }), mk('B', 'Bravo', { inDays: 2 })];
    assert.equal(T.calModel(opts({ view: 'month' }), E.now()).hero.title, 'Bravo');
  });
});

describe('séries IGNORÉES : jamais affichées', () => {
  test('ni épisodes, ni héros, ni compteurs, ni export, ni liste « sans date »', () => {
    const a = mk('A', 'Alpha'), b = mk('B', 'Bravo', { inDays: 1 }), c = mk('C', 'Charlie', { noNext: true });
    T.STATE.series = [a, b, c];
    T.IGNORED.set('B', { title: 'Bravo', source: 'watchlist', ignoredAt: 1 });
    T.IGNORED.set('C', { title: 'Charlie', source: 'watchlist', ignoredAt: 1 });
    const m = T.calModel(opts({ est: true }), E.now());
    assert.ok(m.events.every((e) => e.id === 'A'));
    assert.equal(m.hero.title, 'Alpha');
    assert.equal(m.noDate.length, 0);
    assert.equal(m.counts.all, m.events.length);
    const html = T.renderCalendrier();
    assert.doesNotMatch(html, /Bravo|Charlie/);
    assert.doesNotMatch(T.calBuildIcs(m.events, E.now()).text, /Bravo|Charlie/);
  });
  test('sorti aujourd’hui : une série ignorée n’y figure pas non plus', () => {
    const s = mk('A', 'Alpha');
    const last = s.episodes[s.episodes.length - 1];
    last.air = last.avail = E.now() - 3600e3;
    T.STATE.series = [s];
    assert.equal(T.calTodayOut(E.now()).length, 1);
    T.IGNORED.set('A', { title: 'Alpha', source: 'watchlist', ignoredAt: 1 });
    assert.equal(T.calTodayOut(E.now()).length, 0);
  });
  test('nouveautés : série ignorée (id Crunchyroll) = invisible, récente comme à venir', () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [crSeries('CR1', 'Récent', now - 3600e3), crSeries('CR2', 'Lointain', now + 9 * DAY)];
    assert.equal(evs(T.calModel(opts(), now), 'prem').length, 2);
    T.IGNORED.set('CR1', { title: 'Récent', source: 'newpremieres', ignoredAt: 1 });
    T.IGNORED.set('CR2', { title: 'Lointain', source: 'newpremieres', ignoredAt: 1 });
    const m = T.calModel(opts(), now);
    assert.equal(evs(m, 'prem').length, 0);
    assert.doesNotMatch(T.renderCalendrier(), /Récent|Lointain/);
  });
  test('chaque carte porte son bouton « ignorer » (source adaptée)', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [crSeries('CR2', 'Lointain', E.now() + 9 * DAY)];
    const html = T.renderCalendrier();
    assert.match(html, /data-ignore="A"[^>]*data-source="watchlist"/);
    assert.match(html, /data-ignore="CR2"[^>]*data-source="newpremieres"/);
  });
});

describe('nouvelles séries (Crunchyroll)', () => {
  test('l’horizon borne les nouveautés à venir ; le passé récent reste dans « Vient de sortir »', () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [crSeries('CR1', 'Dans 9 jours', now + 9 * DAY), crSeries('CR2', 'Hier', now - DAY)];
    assert.deepEqual(plain(evs(T.calModel(opts({ horizon: 7 }), now), 'prem').map((e) => e.title)), ['Hier']);
    assert.deepEqual(plain(evs(T.calModel(opts({ horizon: 30 }), now), 'prem').map((e) => e.title).sort()), ['Dans 9 jours', 'Hier']);
  });
  test('suite d’une série suivie reconnue par son titre → « Nouvelle saison », lien vers la série', () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [crSeries('CR9', 'Alpha', now + 3 * DAY)];
    const p = evs(T.calModel(opts(), now), 'prem')[0];
    assert.ok(p && p.followed && p.followed.id === 'A');
    assert.match(T.renderCalendrier(), /Suite de « Alpha »/);
  });
  test('catégories exclues et séries sans épisode daté ne produisent aucune carte', () => {
    const now = E.now();
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [{ ...crSeries('CR1', 'Vide', now), eps: [] }];
    assert.equal(evs(T.calModel(opts(), now), 'prem').length, 0);
  });
});

describe('vues Agenda / Semaine / Mois', () => {
  test('options corrompues → valeurs par défaut sûres', () => {
    T.STATE.filters.calView = 'zzz'; T.STATE.filters.calHorizon = 'abc'; T.STATE.filters.calFilter = 42;
    const o = T.calOpts();
    assert.equal(o.view, 'agenda'); assert.equal(o.horizon, 90); assert.equal(o.filter, 'all');
  });
  test('Semaine : du lundi au dimanche, navigation bornée', () => {
    T.STATE.filters.calView = 'week'; T.STATE.filters.calWeekMode = 'calendar';
    const r = T.calRange(T.calOpts(), E.now());
    assert.equal(new Date(r.start).getDay(), 1);
    assert.equal(r.end - r.start, 7 * DAY);
    T.calUi().off = 1;
    assert.equal(T.calRange(T.calOpts(), E.now()).start - r.start, 7 * DAY);
    T.calUi().off = -5;      // v4.22.0 : on peut remonter dans le passé (jusqu'à 26 semaines)
    assert.equal(r.start - T.calRange(T.calOpts(), E.now()).start, 5 * 7 * DAY);
    T.calUi().off = -999;
    assert.equal(r.start - T.calRange(T.calOpts(), E.now()).start, 26 * 7 * DAY, 'borne arrière');
  });
  test('Semaine : 7 jours rendus, l’événement est dans le bon jour', () => {
    T.STATE.filters.calView = 'week';
    T.calUi().off = 1;                                   // semaine suivante (le « maintenant » du test est un dimanche)
    const start = T.calRange(T.calOpts(), E.now()).start;
    const when = start + 2 * DAY + 12 * 3600e3;          // mercredi midi
    T.STATE.series = [mk('A', 'Alpha', { inDays: (when - E.now()) / DAY })];
    const html = T.renderCalendrier();
    assert.equal((html.match(/<section class="crrav-agsec/g) || []).length, 7);
    const day = T.calDayKey(when);
    const sec = html.split('<section').find((x) => x.includes(`data-calday="${day}"`));
    assert.match(sec, /Alpha/);
  });
  test('Mois : grille complète, jour sélectionné, détail du jour', () => {
    T.STATE.series = [mk('A', 'Alpha', { inDays: 2 })];
    T.STATE.filters.calView = 'month';
    T.calUi().off = 1;
    T.calUi().sel = null;
    const html = T.renderCalendrier();
    const d = new Date(E.now());
    const days = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    assert.equal((html.match(/crrav-calcell[ "]/g) || []).length >= days, true);
    assert.match(html, /crrav-calselday/);
    assert.match(html, /aria-label="\d+ \w+ — \d+ sortie/);
  });
  test('Mois suivant : navigation, aucune erreur même sans événement', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.filters.calView = 'month';
    T.calHandleAct({ dataset: { act: 'cal-nav', d: '1' } });
    assert.equal(T.calUi().off, 1);
    assert.ok(T.renderCalendrier().includes('crrav-calmgrid'));
    for (let i = 0; i < 40; i++) T.calHandleAct({ dataset: { act: 'cal-nav', d: '1' } });
    assert.equal(T.calUi().off, 12, 'borné à un an');
  });
  test('Agenda 1 an : barres de mois repliables, premiers mois ouverts', () => {
    // (v4.25.0) plus de projection : les mois lointains viennent des dates ANNONCÉES par AniList.
    T.STATE.series = [mk('A', 'Alpha', { total: 40, future: Array.from({ length: 30 }, (_, i) => [7 + i, E.now() + (10 + i * 7) * DAY]) })];
    T.STATE.filters.calHorizon = 365;
    const html = T.renderCalendrier();
    assert.ok((html.match(/crrav-calmonthbar/g) || []).length >= 3);
    assert.match(html, /aria-expanded="false"/, 'mois lointains repliés par défaut');
    const bar = html.match(/data-act="cal-fold" data-m="(\d{4}-\d{2})"/)[1];
    T.calHandleAct({ dataset: { act: 'cal-fold', m: bar }, classList: { contains: () => false } });
    assert.equal(T.calUi().fold[bar], true);
  });
  test('filtres : en retard / nouveautés + compteurs', () => {
    T.STATE.series = [mk('A', 'Alpha', { seen: 3 }), mk('B', 'Bravo', { rating: 5 })];
    T.STATE.crNew.items = [crSeries('CR1', 'Neuf', E.now() + 9 * DAY)];
    const base = T.calModel(opts(), E.now());
    assert.ok(base.counts.late > 0 && base.counts.src_new === 1 && base.counts.src_mine > 0, 'sources : nombre de séries nouvelles / à toi');
    assert.ok(T.calModel(opts({ filter: 'late', sources: ['mine'] }), E.now()).events.every((e) => e.id === 'A'));
    assert.ok(T.calModel(opts({ sources: ['new'] }), E.now()).events.every((e) => e.type === 'prem'));
  });
  test('actions : période, filtre et options sont mémorisés', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.calHandleAct({ dataset: { act: 'cal-horizon', v: '180' } });
    T.calHandleAct({ dataset: { act: 'cal-filter', v: 'late' } });
    T.calHandleAct({ dataset: { act: 'cal-view', v: 'week' } });
    T.calHandleAct({ dataset: { act: 'cal-opt', k: 'calConfirmed' } });
    assert.equal(T.STATE.filters.calHorizon, 180);
    assert.equal(T.STATE.filters.calFilter, 'late');
    assert.equal(T.STATE.filters.calView, 'week');
    assert.equal(T.STATE.filters.calConfirmed, true);
    assert.equal(T.calHandleAct({ dataset: { act: 'cal-horizon', v: '999' } }), true);
    assert.equal(T.STATE.filters.calHorizon, 180, 'valeur invalide ignorée');
    assert.equal(T.calHandleAct({ dataset: { act: 'autre' } }), false);
  });
  test('état vide : message + actions pour élargir, pas de page blanche', () => {
    T.STATE.series = [mk('A', 'Alpha', { noNext: true })];
    T.STATE.filters.calHorizon = 7;
    const html = T.renderCalendrier();
    assert.match(html, /Rien à afficher/);
    assert.match(html, /Élargir à 14 j/);
  });
  test('compte à rebours lisible', () => {
    const n = E.now();
    assert.equal(T.calCountdown(n + 30 * 60e3, n), 'dans 30 min');
    assert.match(T.calCountdown(n + 5 * 3600e3 + 12 * 60e3, n), /^dans 5 h 12$/);
    assert.equal(T.calCountdown(n + 3 * DAY, n), 'dans 3 j');
    assert.equal(T.calCountdown(n + 100 * DAY, n), 'dans 3 mois');
    assert.equal(T.calCountdown(n - 5, n), 'maintenant');
  });
  test('beaucoup de séries sur un an : rendu borné, sans exception', () => {
    T.STATE.series = Array.from({ length: 120 }, (_, i) => mk('S' + i, 'Série ' + i, { total: 52, inDays: 1 + (i % 6) }));
    T.STATE.filters.calHorizon = 365; T.STATE.filters.calShowProj = true;
    const m = T.calModel(T.calOpts(), E.now());
    assert.ok(m.events.length <= 1500);
    const html = T.renderCalendrier();
    assert.ok(html.length > 1000);
  });
});

describe('export .ics', () => {
  const sample = () => {
    const now = E.now();
    return [
      { type: 'ep', key: 'ep:A:6', id: 'A', title: 'Alpha, le "retour"; v2', label: 'S1 E6', ts: now + DAY, precision: 'time', dur: 24, urls: { web: 'https://www.crunchyroll.com/fr/series/A/', watch: 'https://www.crunchyroll.com/watch/X1' }, exact: true },
      { type: 'prem', key: 'prem:ani:2', id: 'ani:2', title: 'Nouveauté', ts: now + 40 * DAY, precision: 'day', urls: { web: 'x', watch: 'x' } },
      { type: 'prem', key: 'prem:ani:3', id: 'ani:3', title: 'Mois seul', ts: now + 60 * DAY, precision: 'month' },
      { type: 'out', key: 'out:A:1', id: 'A', title: 'Sorti', ts: now - 3600e3, precision: 'time' },
    ];
  };
  test('format iCalendar valide : CRLF, UTC, rappel, échappements, dates imprécises exclues', () => {
    const { text, count } = T.calBuildIcs(sample(), E.now());
    assert.equal(count, 2, 'ni « mois seul » ni « sorti aujourd’hui »');
    assert.match(text, /^BEGIN:VCALENDAR\r\nVERSION:2\.0\r\n/);
    assert.match(text, /\r\nEND:VCALENDAR\r\n$/);
    assert.match(text, /DTSTART:\d{8}T\d{6}Z/);
    assert.match(text, /DTSTART;VALUE=DATE:\d{8}/);
    assert.match(text, /TRIGGER:-PT15M/);
    assert.match(text, /SUMMARY:Alpha\\, le "retour"\\; v2 — S1 E6/);
    assert.doesNotMatch(text, /Mois seul|Sorti\r/);
    assert.equal((text.match(/BEGIN:VEVENT/g) || []).length, 2);
    assert.equal(text.split('\r\n').every((l) => Buffer.byteLength(l) <= 75), true, 'lignes pliées à 75 octets');
  });
  test('ligne très longue (accents) pliée sans couper un caractère', () => {
    const folded = T.icsFold('SUMMARY:' + 'é'.repeat(100));
    const lines = folded.split('\r\n');
    assert.ok(lines.length > 1);
    assert.ok(lines.every((l) => Buffer.byteLength(l) <= 75));
    assert.equal(lines.map((l, i) => (i ? l.slice(1) : l)).join(''), 'SUMMARY:' + 'é'.repeat(100));
  });
  test('v4.33.0 : plus aucun bouton ni action « .ics » (carte, fiche série, barre) ; la génération du fichier reste interne', () => {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo')];
    const html = T.renderCalendrier();
    assert.doesNotMatch(html, /data-act="cal-(sa-)?ics/); assert.doesNotMatch(html, /\.ics/);
    T.STATE.serieAgenda = { id: 'A' };
    assert.doesNotMatch(T.renderCalendrier(), /data-act="cal-sa-ics|Tout ajouter à mon agenda/);
    assert.equal(T.calHandleAct({ dataset: { act: 'cal-ics-all' } }), false, 'action supprimée');
    assert.equal(T.calHandleAct({ dataset: { act: 'cal-ics', k: 'x' } }), false);
  });
});

describe('intégration', () => {
  test('l’onglet Calendrier se rend dans le panneau complet sans exception', () => {
    T.STATE.series = [mk('A', 'Alpha'), mk('B', 'Bravo', { seen: 2 })];
    T.STATE.tab = 'calendrier';
    assert.doesNotThrow(() => T.renderCalendrier());
    const dom = E.html(T.renderCalendrier());
    assert.ok(dom.querySelector('.crrav-cal'));
    assert.ok(dom.querySelectorAll('.crrav-calcard').length >= 2);
    assert.ok(dom.querySelector('[data-act="cal-view"][aria-selected="true"]'));
  });
  test('toutes les cartes ont une action accessible (étiquette) et un lien valide', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    const dom = E.html(T.renderCalendrier());
    for (const b of dom.querySelectorAll('.crrav-calqa')) assert.ok(b.getAttribute('aria-label') || b.textContent.trim());
    for (const a of dom.querySelectorAll('a.crrav-calqa')) assert.match(a.getAttribute('href'), /^(https:|intent:)/);
  });
  test('texte injecté dans un titre : échappé', () => {
    T.STATE.series = [mk('A', '<img src=x onerror=alert(1)>')];
    const html = T.renderCalendrier();
    assert.doesNotMatch(html, /<img src=x onerror/);
  });
  test('réglage « nouveautés lointaines » présent dans les Réglages', () => {
    assert.ok(T.SETTINGS_KEYS.includes('calFutureEnabled'));
  });
  test('cache AniList d’avant (sans futureEps) : tout fonctionne par projection', () => {
    const s = mk('A', 'Alpha'); delete s.aniFuture;
    T.STATE.series = [s];
    assert.ok(evs(T.calModel(opts(), E.now()), 'ep').length > 1);
  });
  test('computeAniSchedule publie les dates exactes à venir', () => {
    const now = E.now();
    const r = T.computeAniSchedule({ episodes: 12, nextAiringEpisode: { episode: 6, airingAt: Math.floor((now + 3 * DAY) / 1000) },
      airingSchedule: { nodes: [{ episode: 5, airingAt: Math.floor((now - 4 * DAY) / 1000) }, { episode: 6, airingAt: Math.floor((now + 3 * DAY) / 1000) }, { episode: 7, airingAt: Math.floor((now + 10 * DAY) / 1000) }] } }, {});
    assert.deepEqual(plain(r.futureEps.map((x) => x[0])), [6, 7]);
  });
});

describe('responsive et distinction des nouveautés', () => {
  test('nouveautés : classe dédiée (bleu, pastille NEW, libellé), épisodes inchangés', () => {
    T.STATE.series = [mk('A', 'Alpha')];
    T.STATE.crNew.items = [crSeries('G9', 'Neuf', E.now() + 3600e3)];
    const dom = E.html(T.renderCalendrier());
    const prem = dom.querySelector('.crrav-calcard.prem');
    assert.ok(prem, 'carte nouveauté');
    assert.match(prem.textContent, /Nouveau/);
    assert.ok(dom.querySelector('.crrav-calcard.ep'));
    assert.ok(!dom.querySelector('.crrav-calcard.ep.prem'));
    assert.match(T.CSS, /\.crrav-calcard\.prem\{/);
    assert.match(T.CSS, /\.crrav-calnew\{/);
    assert.ok(!/crrav-calnew/.test(dom.querySelector('.crrav-calcard.prem').innerHTML), 'une nouvelle série porte « Nouveau », pas le repère de reprise');
  });
  test('feuille de style : paliers de conteneur du Z Fold fermé (≤340) au très grand écran (≥2100)', () => {
    for (const q of ['(max-width:340px)', '(min-width:560px)', '(min-width:720px)', '(min-width:1060px)', '(min-width:1480px)', '(min-width:1500px)', '(min-width:2100px)']) {
      assert.ok(T.CSS.includes('@container cal ' + q), q);
    }
    assert.match(T.CSS, /container-type:inline-size;container-name:cal/);
    assert.match(T.CSS, /\.crrav-calbar\{display:flex;flex-wrap:wrap/);
  });
  test('cibles tactiles : boutons d’action ≥ 44 px sur mobile (déclaré dans le CSS)', () => {
    assert.match(T.CSS, /\.crrav-calqa\{display:inline-flex;[^}]*min-height:44px/);
    assert.match(T.CSS, /\.crrav-calmonthbar\{[^}]*min-height:44px/);
  });
});

