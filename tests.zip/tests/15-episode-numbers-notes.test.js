'use strict';
// v4.18.0 — (1) numéro d'épisode relatif à la saison (plus de « S3 E4 » à côté de « S3 E51 »),
// (2) notes perso (★) archivées, exportées, importées.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

// Série à numérotation CONTINUE : S1 = 1-24, S2 = 25-48, S3 = 49-51 (comme Les Carnets de l'apothicaire).
function continuous(now, { last = 51 } = {}) {
  const eps = [];
  const mk = (season, n, ageDays) => eps.push({ season, n, id: `e${n}`, ids: [`e${n}`], dur: 1440, air: now - ageDays * DAY, avail: now - ageDays * DAY, title: '' });
  for (let n = 1; n <= 24; n++) mk(1, n, 400 - n);
  for (let n = 25; n <= 48; n++) mk(2, n, 200 - n);
  for (let n = 49; n <= last; n++) mk(3, n, (last - n) * 7 + 3);
  return eps;
}
const panel = { id: 'APO', title: 'Les Carnets de l\'apothicaire', slug_title: 'apo', images: {}, series_metadata: { tenant_categories: [] } };

describe('numéro d’épisode relatif à la saison', () => {
  test('numérotation continue : le 51e est le 3e de la S3', () => {
    const s = { episodes: continuous(E.now()) };
    const ep = (n) => s.episodes.find((e) => e.n === n);
    assert.equal(T.epRelN(s, ep(49)), 1);
    assert.equal(T.epRelN(s, ep(51)), 3);
    assert.equal(T.epRelN(s, ep(25)), 1);
    assert.equal(T.epRelN(s, ep(24)), 24);
    assert.equal(T.epRelN(s, ep(1)), 1);
  });
  test('numérotation normale (chaque saison repart de 1) : inchangée', () => {
    const eps = [];
    for (const season of [1, 2]) for (let n = 1; n <= 12; n++) eps.push({ season, n, id: `s${season}e${n}` });
    const s = { episodes: eps };
    assert.equal(T.epRelN(s, eps[23]), 12);
    assert.equal(T.epRelN(s, eps[12]), 1);
  });
  test('saison qui ne démarre pas à 1 SANS continuité avec la précédente : inchangée (épisodes manquants)', () => {
    const eps = [{ season: 1, n: 1 }, { season: 1, n: 12 }, { season: 2, n: 3 }, { season: 2, n: 4 }];
    const s = { episodes: eps };
    assert.equal(T.epRelN(s, eps[2]), 3);
  });
  test('entrées invalides / spéciaux / absents : jamais d’exception', () => {
    assert.equal(T.epRelN(null, null), null);
    assert.equal(T.epRelN({ episodes: null }, { n: 5, season: 1 }), 5);
    const s = { episodes: [{ season: 1, n: 1 }, { season: 1, n: 12.5 }, { season: 2, n: null }, null] };
    assert.equal(T.epRelN(s, { season: 1, n: 12.5 }), 12.5);
  });
  test('AniList par saison (4) ou en continu (52) : ramené à la saison', () => {
    const now = E.now();
    const s = { episodes: continuous(now), lastAired: null };
    s.lastAired = s.episodes[s.episodes.length - 1];
    assert.equal(T.aniNextRel(s, 4), 4, 'déjà relatif');
    assert.equal(T.aniNextRel(s, 52), 4, 'continu → relatif');
    assert.equal(T.aniNextRel(s, undefined), undefined);
    assert.equal(T.aniNextRel({ episodes: [], lastAired: null }, 7), 7, 'rien à comparer');
  });
  test('Calendrier : « S3 E4 » et « tu en es à S3 E3 », jamais E51', () => {
    const now = E.now();
    const eps = continuous(now);
    const ph = new Map(eps.map((e) => [e.id, { p: 1440, full: true }]));
    const entry = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
    entry.aniNextTs = now + 4 * DAY; entry.aniNextNum = 4;
    T.STATE.series = [entry];
    const html = T.renderCalendrier();
    assert.match(html, /S3 E4/);
    assert.match(html, /tu en es à S3 E3/);
    assert.doesNotMatch(html, /E51/);
  });
  test('Calendrier : AniList qui compte en continu (52) donne aussi « S3 E4 »', () => {
    const now = E.now();
    const eps = continuous(now);
    const ph = new Map(eps.map((e) => [e.id, { p: 1440, full: true }]));
    const entry = T.buildSeriesEntry(panel, eps, Math.max(...eps.map((e) => e.air)), null, 0, ph, null);
    entry.aniNextTs = now + 4 * DAY; entry.aniNextNum = 52;
    T.STATE.series = [entry];
    assert.match(T.renderCalendrier(), /S3 E4/);
  });
  test('les clés d’archive restent en numérotation d’origine (s3e51)', () => {
    T.historyArchiveMerge('acc', [{ id: 'APO', title: 'A', eps: ['s3e51'], seconds: 1440, genres: [] }], 'history');
    assert.deepEqual(plain(T.historyArchiveLoad('acc').series.APO.eps), ['s3e51']);
  });
});

describe('notes perso (★)', () => {
  const file = (items, extra = {}) => ({ kind: 'mon-crunchy-config', version: '4.18.0', notes: { v: 1, items }, ...extra });

  test('une note renvoyée par Crunchyroll est archivée', async () => {
    E.net.on(/rating\/series\/APO/, () => ({ rating: '5s' }));
    assert.equal(await T.getMyRating('acc', 'APO'), 5);
    assert.equal(T.noteArchived('APO'), 5);
    assert.ok(T.cacheGetStale('histnotes:acc'));
  });
  test('compte sans note côté Crunchyroll : repli sur l’archive (affichage + réseau)', async () => {
    T.notesRemember('acc', 'APO', 5, 'Apothicaire');
    assert.equal(T.getMyRatingCached('APO'), 5);
    E.net.on(/rating\/series\/APO/, () => ({ __status: 404, body: {} }));
    assert.equal(await T.getMyRating('acc', 'APO'), 5);
    T.cacheSet('myrating:APO', { r: null });
    assert.equal(T.getMyRatingCached('APO'), 5);
  });
  test('une note Crunchyroll prime sur l’archive et la met à jour', async () => {
    T.notesRemember('acc', 'APO', 3);
    E.net.on(/rating\/series\/APO/, () => ({ rating: 4 }));
    assert.equal(await T.getMyRating('acc', 'APO'), 4);
    assert.equal(T.noteArchived('APO'), 4);
  });
  test('l’export contient les notes (archive + cache myrating + séries chargées) et la photo des listes', async () => {
    T.cacheSet('myrating:CACHED', { r: 4 });
    T.STATE.series = [{ id: 'LOADED', title: 'Chargée', myRating: 5, seen: 3, total: 12, episodes: [] }];
    T.notesRemember('acc', 'OLD', 2, 'Ancienne');
    const p = plain(T.buildBackupPayload());
    const byId = Object.fromEntries(p.notes.items.map((n) => [n.id, n.r]));
    assert.deepEqual(byId, { CACHED: 4, LOADED: 5, OLD: 2 });
    assert.deepEqual(p.lists.series, [{ id: 'LOADED', title: 'Chargée', seen: 3, total: 12, rating: 5 }]);
  });
  test('export normal = profil actif ; « tout » = tous les profils', () => {
    T.setProfile('p1', 'Geo');
    T.notesRemember('acc', 'A', 5);
    T.cacheSet('histnotes:acc~p2', { v: 1, series: { B: { id: 'B', r: 3, t: '', at: 1 } } });
    assert.deepEqual(plain(T.buildBackupPayload().notes.items.map((n) => n.id)), ['A']);
    assert.deepEqual(plain(T.buildBackupPayload({ all: true }).notes.items.map((n) => n.id)).sort(), ['A', 'B']);
  });
  test('import : ajoute les notes absentes, ne remplace jamais une note déjà connue', async () => {
    T.notesRemember('acc', 'KEEP', 5);
    const res = await T.applyBackup(plain(file([{ id: 'NEW', r: 4, t: 'N' }, { id: 'KEEP', r: 1, t: 'K' }])));
    assert.equal(res.ok, true);
    assert.equal(res.history.notes.added, 1);
    assert.equal(res.history.notes.kept, 1);
    assert.equal(T.noteArchived('NEW'), 4);
    assert.equal(T.noteArchived('KEEP'), 5);
    const again = await T.applyBackup(plain(file([{ id: 'NEW', r: 4 }])));
    assert.equal(again.history.notes.added, 0, 'idempotent');
  });
  test('import : notes invalides ignorées, fichier de notes seules accepté', async () => {
    const res = await T.applyBackup(plain(file([null, 7, { id: '', r: 3 }, { id: 'X', r: 99 }, { id: 'Y', r: 'abc' }, { id: 'OK', r: '4,5' }])));
    assert.equal(res.ok, true);
    assert.equal(T.noteArchived('OK'), 4.5);
    assert.equal(T.noteArchived('X'), null);
    assert.equal(T.noteArchived('Y'), null);
  });
  test('scénario : export sur le compte de l’ami, import sur le compte perso → notes visibles', async () => {
    T.ACCOUNT_ID = 'ami';
    T.notesRemember('ami', 'APO', 5, 'Apothicaire');
    const f = plain(T.buildBackupPayload());
    const E2 = fresh();
    try {
      E2.T.ACCOUNT_ID = 'perso';
      await E2.T.applyBackup(f);
      assert.equal(E2.T.getMyRatingCached('APO'), 5);
    } finally { E2.close(); }
  });
  test('l’archive des notes survit à « Vider le cache » et n’est pas évictable', () => {
    T.notesRemember('acc', 'APO', 5);
    assert.equal(T.EVICTABLE.some((p) => 'histnotes:acc'.startsWith(p)), false);
    T.clearCache();
    assert.equal(T.noteArchived('APO'), 5);
  });
  test('écritures suspendues si le profil a changé : aucune note mélangée', () => {
    T.setProfile('p1', 'Geo'); T.setProfile('p2', 'Ami');
    assert.equal(T.notesRemember('acc', 'APO', 5), false);
    assert.equal(T.noteArchived('APO'), null);
  });
  test('modale : l’étape historique annonce les notes ajoutées', async () => {
    T.open();
    const f = new E.w.File([JSON.stringify(file([{ id: 'NEW', r: 4, t: 'N' }]))], 's.json', { type: 'application/json' });
    T.importSettings(f, { assumeYes: true });
    for (let i = 0; i < 400 && !(T.STATE.importModal && T.STATE.importModal.done); i++) await E.tick(10);
    assert.match(E.w.document.querySelector('#crrav-imp li[data-k="history"] small').textContent, /\+1 note/);
    assert.match(E.w.document.querySelector('#crrav-imp li[data-k="check"] small').textContent, /1 note/);
  });
});
