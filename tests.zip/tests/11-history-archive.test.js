'use strict';
// v4.10.0 — Mémoire permanente de l'historique + complétion par l'avancement réel.
// Contexte : l'API Crunchyroll ne sert que les ~1000 dernières entrées de watch-history.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, historyEntry, routeHistory, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.CFG.concurrency = 3; T.PACE.limit = 3; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => E.close());

const panel = (id, title) => ({ id, type: 'series', title, slug_title: id.toLowerCase(), images: {},
  series_metadata: { season_count: 1, episode_count: 12, tenant_categories: ['Action'] } });
// Catalogue simulé : séries de 12 épisodes ; `watched` = ids d'épisodes vus.
function routeCatalog({ catalog, watched = new Set(), started = new Set() }) {
  E.net.on(/discover\/browse/, (u) => { const q = new URL(u).searchParams; const s = +q.get('start'), n = +q.get('n');
    return { data: catalog.slice(s, s + n), total: catalog.length }; });
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\/seasons/, (u, o, m) => ({ data: [{ id: m[1] + '-S1', season_number: 1, number_of_episodes: 12, title: 'S1', versions: [] }] }));
  E.net.on(/cms\/seasons\/([A-Za-z0-9]+)-S1\/episodes/, (u, o, m) => ({ data: Array.from({ length: 12 }, (_, i) => ({ id: `${m[1]}-e${i + 1}`, episode_number: i + 1, season_number: 1, sequence_number: i + 1, duration_ms: 1440000, title: '', versions: [] })) }));
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\?/, (u, o, m) => ({ data: [catalog.find((p) => p.id === m[1]) || panel(m[1], m[1])] }));
  E.net.on(/playheads/, (u) => {
    const ids = new URL(u).searchParams.get('content_ids').split(',');
    return { data: ids.filter((id) => watched.has(id) || started.has(id)).map((id) => ({ content_id: id, playhead: watched.has(id) ? 1440 : 300, fully_watched: watched.has(id) })) };
  });
  E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
}
const epsOf = (sid, n) => Array.from({ length: n }, (_, i) => `${sid}-e${i + 1}`);
// Historique plafonné comme Crunchyroll : page > maxPage refusée.
function routeCappedHistory(list, maxPage = 1) {
  E.net.on(/watch-history\?/, (u) => {
    const p = +new URL(u).searchParams.get('page');
    if (p > maxPage) return { __status: 400, body: {} };
    const d = list.slice((p - 1) * 100, p * 100); return { total: d.length, data: d };
  });
}

describe('mémoire permanente de l’historique', () => {
  test('une série sortie de la fenêtre Crunchyroll reste connue (ids, détail, Hors listes)', async () => {
    routeHistory(E.net, [historyEntry('OLD', 1, 1, E.now() - 5 * DAY, { title: 'Ancienne' }), historyEntry('NEW', 1, 1, E.now())]);
    await T.getWatchedSeriesIds('acc', null, true);
    E.net.clear();
    E.advance(8 * DAY);                                         // force un nouveau scan COMPLET
    routeHistory(E.net, [historyEntry('NEW', 1, 2, E.now())]);   // OLD n'est plus servie
    const ids = await T.getWatchedSeriesIds('acc', null, true);
    assert.ok(ids.has('OLD') && ids.has('NEW'));
    const d = T.HISTORY_DETAIL.find((x) => x.id === 'OLD');
    assert.ok(d && d.archived && d.title === 'Ancienne');
    assert.ok(T.cachedWatchedIds().ids.has('OLD'), 'aussi sans requête (Stats / Hors listes)');
    assert.equal(T.cacheGetStale('watchedids:acc').ids.includes('OLD'), false, 'le cache du scan reste pur (diagnostic exact)');
  });
  test('la clé d’archive n’est jamais évictable', () => {
    assert.equal(T.EVICTABLE.some((p) => 'histarchive:acc'.startsWith(p)), false);
  });
  test('fusion : union des épisodes, durée cohérente, pas de doublon', () => {
    T.historyArchiveMerge('acc', [{ id: 'S', title: 'S', eps: ['s1e1', 's1e2'], seconds: 2880, genres: [] }], 'history');
    T.historyArchiveMerge('acc', [{ id: 'S', title: 'S', eps: ['s1e2', 's1e3'], seconds: 2880, genres: ['Action'] }], 'recovered');
    const a = T.historyArchiveLoad('acc').series.S;
    assert.deepEqual([...a.eps].sort(), ['s1e1', 's1e2', 's1e3']);
    assert.equal(a.seconds, 3 * 1440);
    assert.deepEqual([...a.genres], ['Action']);
  });
  test('watchedDetailFromPlayheads : vu = durée pleine, commencé = progression', () => {
    const eps = [1, 2, 3].map((n) => ({ season: 1, n, dur: 1440, ids: ['e' + n] }));
    const ph = new Map([['e1', { p: 1440, full: true }], ['e2', { p: 300 }]]);
    const d = T.watchedDetailFromPlayheads('S', 'T', eps, ph);
    assert.deepEqual([...d.eps], ['s1e1', 's1e2']);
    assert.equal(d.seconds, 1440 + 300);
    assert.equal(T.watchedDetailFromPlayheads('S', 'T', eps, new Map()), null);
  });
});

describe('Découverte alimente la mémoire', () => {
  test('série écartée car déjà vue (playheads) → ajoutée à l’historique', async () => {
    routeCatalog({ catalog: [panel('GMASH', 'Mashle')], watched: new Set(epsOf('GMASH', 12)) });
    T.historyComplete = false;
    const REJ = new Proxy({}, { get: (o, k) => o[k] || 0, set: (o, k, v) => ((o[k] = v), true) });
    const r = await T.fetchCandidateEpisodes({ p: panel('GMASH', 'Mashle'), ctx: { accountId: 'acc', REJ, D: T.STATE.discover } });
    assert.equal(r.ok, false);
    const a = T.historyArchiveLoad('acc').series.GMASH;
    assert.equal(a.src, 'discover'); assert.equal(a.eps.length, 12);
  });
});

describe('complétion de l’historique (bouton du diagnostic)', () => {
  test('retrouve les séries vues hors fenêtre, saute les connues sans requête, mémorise', async () => {
    T.cacheSet('watchedids:acc', { ids: ['KNOWN'], complete: false, detail: [], cv: T.HISTORY_CACHE_CV });
    routeCatalog({ catalog: [panel('KNOWN', 'Connue'), panel('GMASH', 'Mashle'), panel('GNONE', 'Jamais vue'), panel('GHALF', 'Commencée')],
      watched: new Set(epsOf('GMASH', 12)), started: new Set(['GHALF-e1']) });
    await T.runHistoryRecovery({ manual: true });
    const a = T.historyArchiveLoad('acc').series;
    assert.ok(a.GMASH && a.GHALF, 'vue et commencée retrouvées');
    assert.equal(a.GNONE, undefined);
    assert.equal(E.net.count(/cms\/series\/KNOWN\/seasons/), 0, 'série connue : aucune requête');
    const st = T.historyRecoverLoad('acc');
    assert.deepEqual([...st.found.map((f) => f.id)].sort(), ['GHALF', 'GMASH']);
    assert.equal(st.done, true);
    const ids = await T.getWatchedSeriesIds('acc', null, false);
    assert.ok(ids.has('GMASH'), 'visible pour Hors listes / Découverte');
  });
  test('reprise : une 2e session ne revérifie pas ce qui l’a déjà été', async () => {
    routeCatalog({ catalog: [panel('GA', 'A'), panel('GB', 'B')] });
    T.CFG.locale = 'fr-FR';
    await T.runHistoryRecovery({ manual: true });
    const before = E.net.count(/seasons\/?/);
    const st = T.historyRecoverLoad('acc'); st.done = false; st.start = 0; T.historyRecoverSave('acc', st);
    await T.runHistoryRecovery({ manual: false });
    assert.equal(E.net.count(/seasons\/?/), before);
  });
  test('automatique : s’efface si un autre scan tourne (l’IHM d’abord)', async () => {
    routeCatalog({ catalog: [panel('GA', 'A')] });
    T.STATE.discover.loading = true;
    await T.runHistoryRecovery({ manual: false });
    assert.equal(T.historyRecoverLoad('acc').checked.length, 0);
    T.STATE.discover.loading = false;
  });
  test('automatique : budget limité par session', async () => {
    const cat = Array.from({ length: 80 }, (_, i) => panel('G' + i, 'S' + i));
    routeCatalog({ catalog: cat });
    await T.runHistoryRecovery({ manual: false });
    assert.equal(T.historyRecoverLoad('acc').checked.length, T.HIST_RECOVER_AUTO_BUDGET);
  });
  test('une série en erreur ne bloque pas la complétion (pas de boucle)', async () => {
    routeCatalog({ catalog: [panel('GERR', 'Err'), panel('GOK', 'Ok')], watched: new Set(epsOf('GOK', 1)) });
    E.net.clear();
    E.net.on(/cms\/series\/GERR\/seasons/, () => ({ __status: 500, body: {} }));
    routeCatalog({ catalog: [panel('GERR', 'Err'), panel('GOK', 'Ok')], watched: new Set(epsOf('GOK', 1)) });
    await T.runHistoryRecovery({ manual: true });
    assert.ok(T.historyArchiveLoad('acc').series.GOK);
    assert.equal(T.historyRecoverLoad('acc').done, true);
  });
  test('pause demandée : arrêt propre', async () => {
    routeCatalog({ catalog: Array.from({ length: 20 }, (_, i) => panel('G' + i, 'S' + i)) });
    const run = T.runHistoryRecovery({ manual: true });
    await E.tick(1);
    T.STATE.histRecover.stopRequested = true;
    await run;
    assert.ok(T.historyRecoverLoad('acc').checked.length < 20);
    assert.equal(T.STATE.histRecover.running, false);
  });
});

describe('bloc du diagnostic', () => {
  test('affiché quand l’historique est partiel, avec le bouton', () => {
    T.cacheSet('watchedids:acc', { ids: ['A'], complete: false, detail: [], cv: T.HISTORY_CACHE_CV, scanInfo: { tailErrors: true } });
    const d = E.html(T.historyRecoverBlockHtml());
    assert.ok(d.querySelector('[data-act="hist-recover"]'));
    assert.match(d.textContent, /1000 dernières entrées/);
  });
  test('masqué quand l’historique est complet et la mémoire vide', () => {
    T.cacheSet('watchedids:acc', { ids: ['A'], complete: true, detail: [], cv: T.HISTORY_CACHE_CV, scanInfo: {} });
    assert.equal(E.html(T.historyRecoverBlockHtml()).textContent.trim(), '');
  });
});

describe('Hors listes de bout en bout avec l’historique plafonné', () => {
  test('série retrouvée par la complétion → comptée dans le Bilan (terminée)', async () => {
    const t = E.now();
    routeCappedHistory([historyEntry('GREC', 1, 1, t, { title: 'Récente' })], 1);
    routeCatalog({ catalog: [panel('GMASH', 'Mashle')], watched: new Set([...epsOf('GMASH', 12), 'GREC-e1']) });
    await T.getWatchedSeriesIds('acc', null, true);
    assert.equal(T.historyComplete, true, 'page partielle = fin (ici 1 entrée)');
    await T.runHistoryRecovery({ manual: true });
    await T.loadOrphelines(() => {});
    const O = T.STATE.orphan;
    assert.equal(O.error, null);
    assert.equal(O.stats.history, 2);
    assert.equal(O.stats.finished, 1, 'Mashle compté comme terminé');
    assert.deepEqual([...O.series.map((s) => s.id)], ['GREC']);
  });
});
