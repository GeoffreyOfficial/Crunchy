'use strict';
// v4.31.0 — Une note (★) pour TOUTES les cartes : séries du catalogue « reste de Crunchyroll », nouvelles séries, annonces AniList.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

const plain = (v) => JSON.parse(JSON.stringify(v));
let E, T;
const ANI = /graphql\.anilist\.co/;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const crItem = (id, title, inDays) => ({ id, title, poster: '', wide: '', synopsis: '', categories: [], ts: E.now() + inDays * DAY, firstN: 1, rank: 1, crId: id, crSlug: id.toLowerCase(), crSource: 'crunchyroll',
  eps: [1, 2, 3].map((n) => ({ id: id + 'e' + n, n, t: '', ts: E.now() + (inDays + (n - 1) * 7) * DAY })) });
const model = () => T.calModel({ view: 'agenda', horizon: 365, filter: 'all', flags: [], sources: ['mine', 'new', 'rest'] }, E.now());
const ratingRoute = (map) => E.net.on(/\/content-reviews\/v2\/rating\/series\/([^/?]+)/, (u, o, m) => ({ average: map[m[1]] ?? null }));

describe('notes pour toutes les séries', () => {
  test('catalogue (nouvelle série + reste de Crunchyroll) : note Crunchyroll lue en fond puis affichée', async () => {
    T.STATE.series = [];
    T.STATE.crNew.items = [crItem('N1', 'Inconnue', 5)];
    T.STATE.crSeason.items = [crItem('R1', 'Catalogue', 6)];
    assert.ok(model().events.every((e) => e.score == null), 'avant : pas de note');
    ratingRoute({ N1: '4.7', R1: '4.2' });
    await T.calEnsureRatings(); await E.tick(10);
    const ev = model().events;
    assert.ok(ev.some((e) => e.type === 'prem' && e.score === 4.7));
    assert.ok(ev.filter((e) => e.type === 'air' && e.id === 'R1').every((e) => e.score === 4.2) && ev.some((e) => e.type === 'air' && e.id === 'R1'));
    assert.ok(ev.filter((e) => e.type === 'air' && e.id === 'N1').every((e) => e.score === 4.7), 'les épisodes suivants d’une nouvelle série aussi');
  });
  test('affichée sur la carte (★ 4.7) pour une série hors de tes listes', async () => {
    T.STATE.series = [(() => { const now = E.now(); const eps = [{ season: 1, n: 1, id: 'Ae1', ids: ['Ae1'], dur: 1440, air: now - 2 * DAY, avail: now - 2 * DAY, title: '' }];
      return T.buildSeriesEntry({ id: 'A', title: 'Alpha', slug_title: 'a', images: {}, series_metadata: { tenant_categories: [] } }, eps, eps[0].air, null, 0, new Map(), null); })()];
    T.STATE.crSeason.items = [crItem('R1', 'Catalogue', 2)];
    T.STATE.filters.calSources = ['rest']; T.STATE.filters.calView = 'agenda';
    ratingRoute({ R1: '4.2' });
    await T.calEnsureRatings(); await E.tick(10);
    const d = E.html(T.renderCalendrier());
    const card = [...d.querySelectorAll('.crrav-calcard.air')].find((c) => /Catalogue/.test(c.textContent));
    assert.ok(card); assert.match(card.querySelector('.crrav-calstar').textContent, /4\.2/);
  });
  test('annonces AniList : note Crunchyroll si la fiche est liée, sinon note AniList (/20 → /5), sinon rien', async () => {
    const NOWS = Math.floor(E.now() / 1000);
    const m = (id, o) => ({ id, averageScore: o.score ?? null, title: { english: 'Show ' + id, romaji: 'R' + id }, format: 'TV', genres: ['Action'], description: '', coverImage: { large: '' }, season: null, seasonYear: null,
      startDate: { year: null, month: null, day: null }, nextAiringEpisode: { episode: 1, airingAt: NOWS + 9 * 86400 },
      externalLinks: o.link ? [{ site: 'Crunchyroll', url: `https://www.crunchyroll.com/series/${o.link}/x`, type: 'STREAMING' }] : [] });
    const bodies = [];
    E.net.on(ANI, (u, o) => { bodies.push(String(o.body || '')); return { data: { Page: { pageInfo: { hasNextPage: false }, media: [m(1, { link: 'GAAA', score: 80 }), m(2, { score: 84 }), m(3, {})] } } }; });
    ratingRoute({ GAAA: '4.9' });
    await T.loadAniFuture(true);
    assert.match(bodies[0], /averageScore/);
    await T.calEnsureRatings(); await E.tick(10);
    const by = Object.fromEntries(model().events.filter((e) => e.type === 'prem').map((e) => [e.key, [e.score, e.ani]]));
    assert.deepEqual(plain(by['premani:1']), [4.9, 4], 'Crunchyroll ET AniList (80/20)');
    assert.deepEqual(plain(by['premani:2']), [null, 4.2], 'AniList seule, étiquetée comme telle — jamais à la place de Crunchyroll');
    assert.deepEqual(plain(by['premani:3']), [null, null]);
  });
  test('cache : une note déjà connue n’est pas redemandée ; une note absente est mémorisée (pas de boucle)', async () => {
    T.STATE.crSeason.items = [crItem('R1', 'Catalogue', 6), crItem('R2', 'Sans note', 7)];
    ratingRoute({ R1: '4.0' });
    await T.calEnsureRatings();
    const n1 = E.net.log.filter((l) => /rating\/series/.test(l.url)).length;
    assert.equal(n1, 2);
    await T.calEnsureRatings(); await T.calEnsureRatings();
    assert.equal(E.net.log.filter((l) => /rating\/series/.test(l.url)).length, n1, 'aucune requête de plus');
  });
  test('panne du service de notes : le calendrier reste affichable', async () => {
    T.STATE.crSeason.items = [crItem('R1', 'Catalogue', 6)];
    E.net.on(/\/content-reviews\/v2\/rating/, () => ({ __status: 500, body: 'boom' }));
    await assert.doesNotReject(() => T.calEnsureRatings());
    assert.ok(model().events.length > 0);
  });
});
