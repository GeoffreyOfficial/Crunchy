'use strict';
// Liaison AniList : planning, genres/tags, requêtes groupées, reprises, coupe-circuit.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; });
afterEach(() => E.close());
const ANI = /graphql\.anilist\.co/;
const sec = (ms) => Math.floor(ms / 1000);

describe('computeAniSchedule (total prévu, fin de saison, prochain épisode)', () => {
  test('total officiel + date exacte du dernier épisode dans le calendrier', () => {
    const now = E.now();
    const nodes = Array.from({ length: 12 }, (_, i) => ({ episode: i + 1, airingAt: sec(now) + i * 7 * 86400 }));
    const r = T.computeAniSchedule({ episodes: 12, status: 'RELEASING', airingSchedule: { nodes },
      nextAiringEpisode: { episode: 3, airingAt: nodes[2].airingAt } }, {});
    assert.equal(r.plannedTotal, 12);
    assert.equal(r.seasonEndTs, nodes[11].airingAt * 1000);
    assert.equal(r.plannedApprox, false);
    assert.equal(r.nextEpNum, 3);
    assert.equal(r.nextEpTs, nodes[2].airingAt * 1000);
  });
  test('sans total officiel : plus haut épisode daté (s’il dépasse le prochain) — cas Tsugai', () => {
    const r = T.computeAniSchedule({ status: 'RELEASING', nextAiringEpisode: { episode: 5, airingAt: 1000 },
      airingSchedule: { nodes: [{ episode: 5, airingAt: 1000 }, { episode: 13, airingAt: 9000 }] } }, {});
    assert.equal(r.plannedTotal, 13);
    assert.equal(r.seasonEndTs, 9000 * 1000);
  });
  test('jamais un total = prochain épisode (serait trop bas)', () => {
    const r = T.computeAniSchedule({ status: 'RELEASING', nextAiringEpisode: { episode: 5, airingAt: 1000 },
      airingSchedule: { nodes: [{ episode: 5, airingAt: 1000 }] } }, {});
    assert.equal(r.plannedTotal, null);
  });
  test('projection hebdomadaire depuis le prochain épisode, marquée approximative', () => {
    const r = T.computeAniSchedule({ episodes: 12, nextAiringEpisode: { episode: 10, airingAt: 1000 } }, {});
    assert.equal(r.seasonEndTs, (1000 + 2 * 7 * 86400) * 1000);
    assert.equal(r.plannedApprox, true);
    const last = T.computeAniSchedule({ episodes: 12, nextAiringEpisode: { episode: 12, airingAt: 1000 } }, {});
    assert.equal(last.plannedApprox, false, 'le prochain EST le dernier');
  });
  test('champs Stats gratuits, genres traduits, tags nettoyés', () => {
    const r = T.computeAniSchedule({ genres: ['Comedy', 'Slice of Life', 'Inconnu'], meanScore: 76, duration: 24, format: 'TV',
      studios: { nodes: [{ name: 'A-1' }] }, startDate: { year: 2023 },
      tags: [{ name: 'Magic', rank: 90 }, { name: 'Spoil', rank: 99, isMediaSpoiler: true }, { name: 'Zero', rank: 0 }] }, {});
    assert.deepEqual([...r.genres], ['Comédie', 'Tranche de vie', 'Inconnu']);
    assert.deepEqual(r.tags.map((t) => t.name), ['Magic']);
    assert.equal(r.studio, 'A-1'); assert.equal(r.meanScore, 76); assert.equal(r.seasonYear, 2023);
  });
});

describe('genres et tags', () => {
  test('mergeGenreLists : sans doublon accent/casse, la base garde la priorité', () => {
    assert.deepEqual([...T.mergeGenreLists(['Comédie', 'Action'], ['comedie', 'Drame'])], ['Comédie', 'Action', 'Drame']);
    assert.deepEqual([...T.mergeGenreLists(null, ['A'])], ['A']);
  });
  test('cleanAniTags : plafonné à 12, trié par rank', () => {
    const tags = Array.from({ length: 20 }, (_, i) => ({ name: 'T' + i, rank: i + 1 }));
    const out = T.cleanAniTags(tags);
    assert.equal(out.length, T.TAG_CAP);
    assert.equal(out[0].name, 'T19');
  });
  test('mergeTagLists : garde le rank le plus haut, replafonne', () => {
    const out = T.mergeTagLists([{ name: 'Magic', rank: 50 }], [{ name: 'magic', rank: 80 }, { name: 'Gag', rank: 60 }]);
    assert.deepEqual(out.map((t) => [t.name, t.rank]), [['Magic', 80], ['Gag', 60]]);
  });
});

describe('durée et dates estimées (Découverte)', () => {
  test('secTotalFromAni = nb épisodes × durée AniList ; 0 si inconnue', () => {
    assert.equal(T.secTotalFromAni(12, { duration: 24 }), 12 * 1440);
    assert.equal(T.secTotalFromAni(12, { duration: null }), 0);
    assert.equal(T.secTotalFromAni(0, { duration: 24 }), 0);
  });
  test('aniMaxAir : prochain épisode si en cours, sinon fin de saison', () => {
    assert.equal(T.aniMaxAir({ anilistStatus: 'RELEASING', nextEpTs: 5, seasonEndTs: 9 }), 5);
    assert.equal(T.aniMaxAir({ anilistStatus: 'FINISHED', nextEpTs: 5, seasonEndTs: 9 }), 9);
    assert.equal(T.aniMaxAir(null), null);
  });
});

describe('classification des échecs AniList', () => {
  test('anilistRetryable : réseau, 429, 5xx oui ; 403/400 non', () => {
    assert.equal(T.anilistRetryable(0, true), true);
    assert.equal(T.anilistRetryable(429), true);
    assert.equal(T.anilistRetryable(503), true);
    assert.equal(T.anilistRetryable(403), false);
    assert.equal(T.anilistRetryable(400), false);
  });
  test('parseRetryAfterMs : secondes, date HTTP, plafond 1 h', () => {
    assert.equal(T.parseRetryAfterMs('30'), 30000);
    assert.equal(T.parseRetryAfterMs('99999'), 3600000);
    assert.equal(T.parseRetryAfterMs(new Date(E.now() + 60000).toUTCString()), 60000);
    assert.equal(T.parseRetryAfterMs(null), 0);
    assert.equal(T.parseRetryAfterMs('n’importe quoi'), 0);
  });
  test('anilistReason : message GraphQL, Cloudflare, 403, 429', () => {
    assert.equal(T.anilistReason(400, JSON.stringify({ errors: [{ message: 'Bad' }] })), 'Bad');
    assert.match(T.anilistReason(403, '<!DOCTYPE html> cloudflare'), /Cloudflare/);
    assert.match(T.anilistReason(403, ''), /IP bloquée/);
    assert.match(T.anilistReason(429, ''), /trop de requêtes/);
  });
});

describe('coupe-circuit AniList', () => {
  test('403/429 : pause croissante 30 → 60 → 120 min (plafond)', () => {
    T.anilistTripCooldown(429);
    assert.equal(T.anilistCooldownRemainingMs(), 30 * 60000);
    T.anilistTripCooldown(429);
    assert.equal(T.anilistCooldownRemainingMs(), 60 * 60000);
    T.anilistTripCooldown(429); T.anilistTripCooldown(429);
    assert.equal(T.anilistCooldownRemainingMs(), 120 * 60000);
  });
  test('Retry-After plus long que notre back-off est respecté', () => {
    T.anilistTripCooldown(429, 90 * 60000);
    assert.equal(T.anilistCooldownRemainingMs(), 90 * 60000);
  });
  test('la pause expire d’elle-même', () => {
    T.anilistTripCooldown(403);
    E.advance(30 * 60000 + 1);
    assert.equal(T.anilistCooldownRemainingMs(), 0);
  });
  test('anilistClearCooldown lève bien la pause « dure » (après un succès AniList)', () => {
    T.anilistTripCooldown(429);
    T.anilistClearCooldown();
    assert.equal(T.anilistCooldownRemainingMs(), 0,
      'BUG : la pause est stockée dans le cache IndexedDB mais anilistClearCooldown ne nettoie que localStorage');
  });
});

describe('anilistQuery (réseau simulé)', () => {
  test('succès : renvoie data et note le statut OK', async () => {
    E.net.on(ANI, () => ({ data: { Media: { id: 1 } } }));
    const d = await T.anilistQuery('q', {});
    assert.equal(d.Media.id, 1);
    assert.equal(T.anilistLastStatus().ok, true);
  });
  test('erreur GraphQL applicative : levée, pas de reprise', async () => {
    E.net.on(ANI, () => ({ errors: [{ message: 'Unknown argument "sort"' }] }));
    await assert.rejects(T.anilistQuery('q', {}), /Unknown argument/);
    assert.equal(E.net.count(ANI), 1);
  });
  test('429 transitoire puis succès : reprise transparente', async () => {
    let n = 0;
    E.net.on(ANI, () => (++n === 1 ? { __status: 429, body: '' } : { data: { ok: true } }));
    assert.deepEqual({ ...(await T.anilistQuery('q', {})) }, { ok: true });
    assert.equal(T.anilistCooldownRemainingMs(), 0);
  });
  test('403 : aucun nouvel essai, coupe-circuit posé', async () => {
    E.net.on(ANI, () => ({ __status: 403, body: 'API disabled' }));
    await assert.rejects(T.anilistQuery('q', {}), (e) => e.httpStatus === 403);
    assert.equal(E.net.count(ANI), 1);
    assert.ok(T.anilistCooldownRemainingMs() > 0);
  });
  test('429 persistant : 3 essais puis coupe-circuit', async () => {
    E.net.on(ANI, () => ({ __status: 429, body: '' }));
    await assert.rejects(T.anilistQuery('q', {}));
    assert.equal(E.net.count(ANI), 3);
    assert.ok(T.anilistCooldownRemainingMs() >= 30 * 60000);
  });
  test('AniList injoignable : coupe-circuit court 45 s, en mémoire seulement', async () => {
    E.net.on(ANI, () => new Error('network down'));
    await assert.rejects(T.anilistQuery('q', {}));
    const r = T.anilistCooldownRemainingMs();
    assert.ok(r > 0 && r <= 45000);
    assert.equal(T.cacheGetStale('anilist:cooldown'), null, 'pas persisté');
    E.advance(45001);
    assert.equal(T.anilistCooldownRemainingMs(), 0);
  });
});

describe('recherche groupée (anti-429 : ~6 séries par requête)', () => {
  test('alias s{i}_{j}, un seul aller-retour, résultats ventilés et dédoublonnés', async () => {
    let body = null;
    E.net.on(ANI, (u, o) => {
      body = JSON.parse(o.body);
      const data = {};
      for (const k of Object.keys(body.variables)) {
        const alias = 's' + k.slice(1);
        const term = body.variables[k];
        data[alias] = { media: [{ id: term.length, title: { romaji: term } }, { id: 999, title: { romaji: 'commun' } }] };
      }
      return { data };
    });
    const out = await T.anilistSearchBatch([{ key: 'A', title: 'Frieren' }, { key: 'B', title: 'Tsugai - Daemons of the Shadow Realm' }]);
    assert.equal(E.net.count(ANI), 1);
    assert.match(body.query, /s0_0: Page/);
    assert.match(body.query, /s1_1: Page/);
    assert.doesNotMatch(body.query, /airingSchedule/, 'phase 1 légère : pas de calendrier');
    assert.equal(out.get('A').media.length, 2);
    assert.equal(new Set(out.get('B').media.map((m) => m.id)).size, out.get('B').media.length, 'dédoublonné');
  });
  test('titre à correspondance forcée : résolu par ID, hors lot texte', async () => {
    const seen = [];
    E.net.on(ANI, (u, o) => { const b = JSON.parse(o.body); seen.push(b.variables);
      return b.variables.id ? { data: { Media: { id: b.variables.id, title: { romaji: 'Lord Marksman' } } } } : { data: {} }; });
    const out = await T.anilistSearchBatch([{ key: 'V', title: 'Madan no Ô to Vanadis' }]);
    assert.equal(out.get('V').media[0].id, 20809);
    assert.equal(out.get('V').media[0].__forced, true);
    assert.ok(seen.every((v) => !('q0_0' in v)), 'aucune recherche texte pour ce titre');
  });
  test('lot vide : aucune requête', async () => {
    assert.equal((await T.anilistSearchBatch([])).size, 0);
    assert.equal(E.net.count(ANI), 0);
  });
});
