'use strict';
// v4.11.0 — Hors listes : bouton « Retrouver mes séries déjà vues » (à la place du Bilan) ;
// fiche série ouverte sur Crunchyroll → ajout à l'historique si des épisodes sont vus.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => E.close());

const panel = (id, title) => ({ id, type: 'series', title, slug_title: id.toLowerCase(), images: {},
  series_metadata: { season_count: 1, episode_count: 12, tenant_categories: ['Action'] } });
function routeSeries({ watched = new Set() } = {}) {
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\/seasons/, (u, o, m) => ({ data: [{ id: m[1] + '-S1', season_number: 1, number_of_episodes: 3, title: 'S1', versions: [] }] }));
  E.net.on(/cms\/seasons\/([A-Za-z0-9]+)-S1\/episodes/, (u, o, m) => ({ data: [1, 2, 3].map((n) => ({ id: `${m[1]}-e${n}`, episode_number: n, season_number: 1, sequence_number: n, duration_ms: 1440000, title: '', versions: [] })) }));
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\?/, (u, o, m) => ({ data: [panel(m[1], 'Titre ' + m[1])] }));
  E.net.on(/playheads/, (u) => {
    const ids = new URL(u).searchParams.get('content_ids').split(',');
    return { data: ids.filter((id) => watched.has(id)).map((id) => ({ content_id: id, playhead: 1440, fully_watched: true })) };
  });
  E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
}

describe('Hors listes : bouton de complétion à la place du Bilan', () => {
  test('le texte « Bilan » a disparu, le bouton est là', () => {
    T.STATE.orphan.series = [series('A', [ep(1, 1, { seen: true }), ep(1, 2)])];
    T.STATE.orphan.loading = false;
    T.STATE.orphan.stats = { history: 11, kept: 1, inLists: 0, finished: 3, barelyStarted: 0, failed: 0 };
    const d = E.html(T.renderOrphelines());
    assert.doesNotMatch(d.textContent, /Bilan/);
    const b = d.querySelector('#crrav-histrec-orph [data-act="hist-recover"]');
    assert.ok(b);
    assert.match(b.textContent, /Retrouver mes séries déjà vues/);
  });
  test('pendant la complétion : bouton Pause avec la progression', () => {
    T.STATE.histRecover = { running: true, manual: true, checked: 12, found: ['Mashle'] };
    const d = E.html(T.historyRecoverOrphanHtml());
    assert.ok(d.querySelector('[data-act="hist-recover-stop"]'));
    assert.match(d.textContent, /12 vérifiées · 1 retrouvées/);
  });
  test('compteur des séries déjà retrouvées affiché sur le bouton', () => {
    T.historyRecoverSave('acc', { start: 0, checked: ['X'], found: [{ id: 'X', title: 'Mashle' }], done: false });
    assert.match(E.html(T.historyRecoverOrphanHtml()).textContent, /1 retrouvées/);
  });
});

describe('fiche série ouverte : vérification de l’avancement', () => {
  test('épisodes vus et série inconnue → ajoutée à l’historique (mémoire)', async () => {
    routeSeries({ watched: new Set(['GMASH-e1', 'GMASH-e2']) });
    assert.equal(await T.checkSeriesWatchedOnOpen('GMASH'), true);
    const a = T.historyArchiveLoad('acc').series.GMASH;
    assert.equal(a.src, 'page');
    assert.equal(a.title, 'Titre GMASH');
    assert.equal(a.eps.length, 2);
  });
  test('aucun épisode vu → rien n’est ajouté', async () => {
    routeSeries();
    assert.equal(await T.checkSeriesWatchedOnOpen('GNONE'), false);
    assert.equal(T.historyArchiveLoad('acc').series.GNONE, undefined);
  });
  test('déjà connue (historique ou mémoire) → zéro requête', async () => {
    routeSeries({ watched: new Set(['GA-e1']) });
    T.historyArchiveMerge('acc', [{ id: 'GA', title: 'A', eps: ['s1e1'], seconds: 1, genres: [] }]);
    T.cacheSet('watchedids:acc', { ids: ['GH'], complete: false, detail: [], cv: T.HISTORY_CACHE_CV });
    assert.equal(await T.checkSeriesWatchedOnOpen('GA'), false);
    assert.equal(await T.checkSeriesWatchedOnOpen('GH'), false);
    assert.equal(E.net.count(/playheads|seasons/), 0);
  });
  test('une seule vérification par série et par session, même si la page est re-scannée', async () => {
    routeSeries({ watched: new Set(['GX-e1']) });
    E.w.history.pushState({}, '', '/fr/series/GX/ma-serie');
    T.crpSeriesArchiveCheck(); T.crpSeriesArchiveCheck(); T.crpSeriesArchiveCheck();
    for (let i = 0; i < 50 && !T.historyArchiveLoad('acc').series.GX; i++) await E.tick(10);
    assert.ok(T.historyArchiveLoad('acc').series.GX, 'ajoutée');
    assert.equal(E.net.count(/playheads/), 1);
  });
  test('hors fiche série : rien', () => {
    E.w.history.pushState({}, '', '/fr/watch/GEP/episode');
    T.crpSeriesArchiveCheck();
    assert.equal(T.SERIES_PAGE_CHECKED.size, 0);
  });
});
