'use strict';
// v4.11.0 — Hors listes : bouton « Retrouver mes séries déjà vues » (à la place du Bilan) ;
// fiche série ouverte sur Crunchyroll → ajout à l'historique si des épisodes sont vus.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => E.close());

const panel = (id, title) => ({ id, type: 'series', title, slug_title: id.toLowerCase(), images: {},
  series_metadata: { season_count: 1, episode_count: 12, tenant_categories: ['Action'] } });
function routeSeries({ watched = new Set() } = {}) {
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\/seasons/, (u, o, m) => ({ data: [{ id: m[1] + '-S1', season_number: 1, number_of_episodes: 3, title: 'S1', versions: [] }] }));
  E.net.on(/cms\/seasons\/([A-Za-z0-9]+)-S1\/episodes/, (u, o, m) => ({ data: [1, 2, 3].map((n) => ({ id: `${m[1]}-e${n}`, episode_number: n, season_number: 1, sequence_number: n, duration_ms: 1440000, title: '', versions: [] })) }));
  E.net.on(/cms\/series\/([A-Za-z0-9]+)\?/, (u, o, m) => ({ data: [panel(m[1], 'Titre ' + m[1])] }));
  E.net.on(/playheads/, (u) => {
    const ids = new URL(u).searchParams.get('content_ids').split(',');
    return { data: ids.filter((id) => watched.has(id)).map((id) => ({ content_id: id, playhead: 1440, fully_watched: true })) };
  });
  E.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
}

describe('Hors listes : bouton de complétion à la place du Bilan', () => {
  test('le texte « Bilan » a disparu, le bouton est là', () => {
    T.STATE.orphan.series = [series('A', [ep(1, 1, { seen: true }), ep(1, 2)])];
    T.STATE.orphan.loading = false;
    T.STATE.orphan.stats = { history: 11, kept: 1, inLists: 0, finished: 3, barelyStarted: 0, failed: 0 };
    const d = E.html(T.renderOrphelines());
    assert.doesNotMatch(d.textContent, /Bilan/);
    const b = d.querySelector('#crrav-histrec-orph [data-act="hist-recover"]');
    assert.ok(b);
    assert.match(b.textContent, /Retrouver mes séries déjà vues/);
  });
  test('pendant la complétion : bouton Pause avec la progression', () => {
    T.STATE.histRecover = { running: true, manual: true, checked: 12, found: ['Mashle'] };
    const d = E.html(T.historyRecoverOrphanHtml());
    assert.ok(d.querySelector('[data-act="hist-recover-stop"]'));
    assert.match(d.textContent, /12 vérifiées · 1 retrouvées/);
  });
  test('compteur des séries déjà retrouvées affiché sur le bouton', () => {
    T.historyRecoverSave('acc', { start: 0, checked: ['X'], found: [{ id: 'X', title: 'Mashle' }], done: false });
    assert.match(E.html(T.historyRecoverOrphanHtml()).textContent, /1 retrouvées/);
  });
});

describe('fiche série ouverte : vérification de l’avancement', () => {
  test('épisodes vus et série inconnue → ajoutée à l’historique (mémoire)', async () => {
    routeSeries({ watched: new Set(['GMASH-e1', 'GMASH-e2']) });
    assert.equal(await T.checkSeriesWatchedOnOpen('GMASH'), true);
    const a = T.historyArchiveLoad('acc').series.GMASH;
    assert.equal(a.src, 'page');
    assert.equal(a.title, 'Titre GMASH');
    assert.equal(a.eps.length, 2);
  });
  test('aucun épisode vu → rien n’est ajouté', async () => {
    routeSeries();
    assert.equal(await T.checkSeriesWatchedOnOpen('GNONE'), false);
    assert.equal(T.historyArchiveLoad('acc').series.GNONE, undefined);
  });
  test('déjà connue (historique ou mémoire) → zéro requête', async () => {
    routeSeries({ watched: new Set(['GA-e1']) });
    T.historyArchiveMerge('acc', [{ id: 'GA', title: 'A', eps: ['s1e1'], seconds: 1, genres: [] }]);
    T.cacheSet('watchedids:acc', { ids: ['GH'], complete: false, detail: [], cv: T.HISTORY_CACHE_CV });
    assert.equal(await T.checkSeriesWatchedOnOpen('GA'), false);
    assert.equal(await T.checkSeriesWatchedOnOpen('GH'), false);
    assert.equal(E.net.count(/playheads|seasons/), 0);
  });
  test('une seule vérification par série et par session, même si la page est re-scannée', async () => {
    routeSeries({ watched: new Set(['GX-e1']) });
    E.w.history.pushState({}, '', '/fr/series/GX/ma-serie');
    T.crpSeriesArchiveCheck(); T.crpSeriesArchiveCheck(); T.crpSeriesArchiveCheck();
    for (let i = 0; i < 50 && !T.historyArchiveLoad('acc').series.GX; i++) await E.tick(10);
    assert.ok(T.historyArchiveLoad('acc').series.GX, 'ajoutée');
    assert.equal(E.net.count(/playheads/), 1);
  });
  test('hors fiche série : rien', () => {
    E.w.history.pushState({}, '', '/fr/watch/GEP/episode');
    T.crpSeriesArchiveCheck();
    assert.equal(T.SERIES_PAGE_CHECKED.size, 0);
  });
});

describe('complétion → Hors listes, Stats et Découverte (v4.11.1)', () => {
  const browse = (catalog) => E.net.on(/discover\/browse/, (u) => { const q = new URL(u).searchParams; const s = +q.get('start'), n = +q.get('n'); return { data: catalog.slice(s, s + n), total: catalog.length }; });
  const pg = (id, title, genres = ['Action']) => ({ ...panel(id, title), series_metadata: { season_count: 1, episode_count: 3, tenant_categories: genres } });
  test('séries retrouvées → ajoutées à Hors listes au fil de l’eau, terminées comprises (v4.12.0)', async () => {
    T.STATE.orphan.series = [];
    browse([pg('GHALF', 'Commencée'), pg('GDONE', 'Terminée')]);
    routeSeries({ watched: new Set(['GHALF-e1', 'GDONE-e1', 'GDONE-e2', 'GDONE-e3']) });
    let seenDuring = false;
    const orig = T.STATE.orphan;
    const run = T.runHistoryRecovery({ manual: true });
    for (let i = 0; i < 200 && T.STATE.histRecover.running; i++) { if (orig.series.some((s) => s.id === 'GHALF')) seenDuring = true; await E.tick(2); }
    await run;
    assert.deepEqual([...T.STATE.orphan.series.map((s) => s.id)], ['GHALF', 'GDONE']);
    assert.ok(seenDuring || T.STATE.orphan.series.length === 1);
    const st = T.historyRecoverLoad('acc');
    assert.equal(JSON.stringify(st.found.map((f) => [f.id, f.finished])), JSON.stringify([['GHALF', false], ['GDONE', true]]));
    assert.match(E.html(T.historyRecoverOrphanHtml()).textContent, /2 ajoutées ci-dessous : 1 à finir · 1 à jour/);
  });
  test('Stats : détail d’historique enrichi immédiatement (épisodes, durée, genres)', async () => {
    T.HISTORY_DETAIL = [];
    browse([pg('GDONE', 'Terminée', ['Comédie'])]);
    routeSeries({ watched: new Set(['GDONE-e1', 'GDONE-e2', 'GDONE-e3']) });
    await T.runHistoryRecovery({ manual: true });
    const d = T.HISTORY_DETAIL.find((x) => x.id === 'GDONE');
    assert.ok(d, 'présente dans le détail des Stats sans nouveau scan');
    assert.equal(d.episodes, 3);
    assert.equal(d.seconds, 3 * 1440);
    assert.deepEqual([...d.genres], ['Comédie']);
  });
  test('Découverte : une série retrouvée est écartée d’entrée, sans requête d’épisodes', async () => {
    browse([pg('GDONE', 'Terminée')]);
    routeSeries({ watched: new Set(['GDONE-e1']) });
    await T.runHistoryRecovery({ manual: true });
    const ids = await T.getWatchedSeriesIds('acc', null, false);
    assert.ok(ids.has('GDONE'), 'fait partie des exclusions de Découverte');
  });
});

describe('sections de Hors listes (v4.12.0)', () => {
  const mk = (id, eps) => series(id, eps, { title: id });
  test('partition : à peine commencé / au moins une saison vue / à jour', () => {
    const barely = mk('B', [ep(1, 1, { seen: true }), ep(1, 2), ep(1, 3)]);
    const started0 = mk('Z', [ep(1, 1, { started: true }), ep(1, 2)]);
    const season = mk('S', [ep(1, 1, { seen: true }), ep(1, 2, { seen: true }), ep(2, 1), ep(2, 2)]);
    const upd = mk('U', [ep(1, 1, { seen: true }), ep(1, 2, { seen: true })]);
    assert.equal(T.orphanGroupOf(barely), 'barely');
    assert.equal(T.orphanGroupOf(started0), 'barely');
    assert.equal(T.orphanGroupOf(season), 'season');
    assert.equal(T.orphanGroupOf(upd), 'uptodate');
  });
  test('un film vu ne compte pas comme « une saison vue »', () => {
    const s = mk('F', [ep(1, 1), ep(1, 2), ep(2, 1, { dur: 6000, seen: true })]);
    assert.equal(T.orphanGroupOf(s), 'barely');
  });
  test('rendu : 3 sections dans l’ordre demandé, compteurs, repli mémorisé', () => {
    T.STATE.orphan.loading = false; T.STATE.orphan.error = null;
    T.STATE.orphan.series = [
      mk('U', [ep(1, 1, { seen: true })]),
      mk('S', [ep(1, 1, { seen: true }), ep(2, 1)]),
      mk('B', [ep(1, 1, { seen: true }), ep(1, 2)]),
    ];
    T.STATE.filters.orphanGroupCollapsed = [];
    let d = E.html(T.renderOrphelines());
    const heads = [...d.querySelectorAll('[data-act="orphan-group-collapse"]')].map((b) => b.textContent.replace(/\s+/g, ' ').trim());
    assert.equal(heads.length, 3);
    assert.match(heads[0], /À peine commencé\s*1/);
    assert.match(heads[1], /Au moins une saison vue\s*1/);
    assert.match(heads[2], /À jour\s*1/);
    T.STATE.filters.orphanGroupCollapsed = ['uptodate'];
    d = E.html(T.renderOrphelines());
    assert.equal(d.querySelector('[data-ogroup="uptodate"] .crrav-grid'), null, 'section repliée');
    T.saveFilters();
    assert.deepEqual(JSON.parse(E.w.localStorage.getItem('crrav:state')).filters.orphanGroupCollapsed, ['uptodate']);
  });
});
