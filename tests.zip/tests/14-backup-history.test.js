'use strict';
// v4.13.0 — Sauvegarde / restauration de l'historique de visionnage.
// Contexte : l'archive d'historique est rangée PAR COMPTE Crunchyroll, dans le navigateur.
// Changer de compte (ami qui arrête son abonnement → compte perso) repartait d'une archive vide.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, historyEntry, routeHistory, DAY } = require('./lib/env');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; });
afterEach(() => E.close());

const entry = (id, eps, extra = {}) => ({ id, title: extra.title ?? id, eps, seconds: extra.seconds ?? eps.length * 1440,
  genres: extra.genres ?? [] });
// Aller-retour par le vrai format fichier (JSON), comme à l'export puis à l'import.
const viaFile = (payload) => JSON.parse(JSON.stringify(payload));
const plain = viaFile;   // sort aussi un objet du navigateur simulé (autre realm) avant deepEqual

describe('export de l’historique', () => {
  test('contient l’archive du compte : série, épisodes, durée, genres', () => {
    T.historyArchiveMerge('acc', [entry('MASHLE', ['s1e1', 's1e2'], { title: 'Mashle', genres: ['Action'] })], 'history');
    const h = T.buildBackupPayload().history;
    assert.equal(h.v, 1);
    assert.equal(h.series.length, 1);
    assert.deepEqual(plain(h.series[0]), { id: 'MASHLE', title: 'Mashle', eps: ['s1e1', 's1e2'], seconds: 2880, genres: ['Action'] });
  });

  test('garde les sections existantes (compatibilité d’une sauvegarde d’avant la 4.13.0)', () => {
    const p = T.buildBackupPayload();
    assert.equal(p.kind, 'mon-crunchy-config');
    assert.deepEqual(Object.keys(p.state).sort(), ['airsnap', 'filters', 'ignored', 'settings']);
    assert.equal(p.version, T.SCRIPT_VERSION);
  });

  test('export complet ({all:true}) : prend aussi l’archive d’un ANCIEN compte ; l’export normal NON (v4.17.0)', () => {
    T.historyArchiveMerge('ami', [entry('OLD', ['s1e1', 's1e2', 's1e3'])], 'history');
    T.ACCOUNT_ID = 'perso';                                     // on est déjà passé sur le compte perso
    T.historyArchiveMerge('perso', [entry('NEW', ['s1e1'])], 'history');
    const ids = plain(T.buildBackupPayload({ all: true }).history.series.map((d) => d.id)).sort();
    assert.deepEqual(ids, ['NEW', 'OLD']);
    assert.deepEqual(plain(T.buildBackupPayload().history.series.map((d) => d.id)), ['NEW']);
    assert.equal(T.buildBackupPayload({ all: true }).history.scope.all, true);
  });

  test('une série présente dans deux comptes : union des épisodes, sans doublon', () => {
    T.historyArchiveMerge('ami', [entry('S', ['s1e1', 's1e2'])], 'history');
    T.historyArchiveMerge('perso', [entry('S', ['s1e2', 's1e3'])], 'history');
    const s = T.buildBackupPayload({ all: true }).history.series;
    assert.equal(s.length, 1);
    assert.deepEqual([...s[0].eps].sort(), ['s1e1', 's1e2', 's1e3']);
    assert.equal(s[0].seconds, 3 * 1440);
  });

  test('reprend le détail du dernier scan d’historique même si l’archive est vide', async () => {
    routeHistory(E.net, [historyEntry('A', 1, 1, E.now() - DAY, { title: 'Alpha' }), historyEntry('A', 1, 2, E.now())]);
    await T.getWatchedSeriesIds('acc', null, true);
    const a = T.buildBackupPayload().history.series.find((d) => d.id === 'A');
    assert.ok(a && a.eps.length === 2 && a.title === 'Alpha');
  });

  test('un cache d’historique ou une archive abîmés ne cassent pas l’export', () => {
    T.cacheSet('histarchive:x', { series: null });
    T.cacheSet('watchedids:y', ['A', 'B']);                     // ancien format : simple tableau d’ids
    T.cacheSet('watchedids:z', { ids: [], detail: [null, 42, { id: 7 }, { id: 'OK', eps: ['s1e1'], seconds: 10 }] });
    const s = T.buildBackupPayload({ all: true }).history.series;
    assert.deepEqual(plain(s.map((d) => d.id)), ['OK']);
  });

  test('aucun historique : section vide mais valide', () => {
    assert.deepEqual(plain(T.buildBackupPayload().history.series), []);
  });
});

describe('import de l’historique', () => {
  test('SCÉNARIO : on exporte sur le compte de l’ami, on réimporte sur le compte perso', async () => {
    // Compte de l’ami : historique accumulé.
    T.historyArchiveMerge('ami', [
      entry('MASHLE', Array.from({ length: 12 }, (_, i) => `s1e${i + 1}`), { title: 'Mashle', genres: ['Action', 'Comédie'] }),
      entry('FRIEREN', ['s1e1', 's1e2', 's1e3'], { title: 'Frieren', genres: ['Fantasy'] }),
    ], 'history');
    T.ACCOUNT_ID = 'ami';
    const file = viaFile(T.buildBackupPayload());

    // Nouveau navigateur / nouveau compte : archive vide.
    const E2 = fresh(); const T2 = E2.T;
    try {
      T2.ACCOUNT_ID = 'perso';
      assert.equal(T2.historyArchiveCount('perso'), 0);
      const res = await T2.applyBackup(file);
      assert.equal(res.ok, true);
      assert.deepEqual(plain(res.history), { read: 2, newSeries: 2, newEps: 15 });
      const arch = T2.historyArchiveLoad('perso').series;
      assert.deepEqual(plain(Object.keys(arch)).sort(), ['FRIEREN', 'MASHLE']);
      assert.equal(arch.MASHLE.eps.length, 12);
      assert.equal(arch.MASHLE.title, 'Mashle');
      assert.deepEqual([...arch.MASHLE.genres], ['Action', 'Comédie']);
      assert.equal(arch.MASHLE.seconds, 12 * 1440);
      // Et le reste du script le voit : exclusions Découverte / Hors listes / Stats.
      T2.cacheSet('watchedids:perso', { ids: [], detail: [], complete: true, cv: 5 });
      const known = T2.cachedWatchedIds();
      assert.ok(known.ids.has('MASHLE') && known.ids.has('FRIEREN'));
      assert.ok(known.detail.some((d) => d.id === 'MASHLE' && d.eps.length === 12));
    } finally { E2.close(); }
  });

  test('l’archive est persistée (clé non évictable) : elle survit à un rechargement', async () => {
    const res = await T.applyBackup(viaFile({ kind: 'mon-crunchy-config', history: { series: [entry('S', ['s1e1'])] } }));
    assert.equal(res.ok, true);
    assert.equal(T.EVICTABLE.some((p) => 'histarchive:acc'.startsWith(p)), false);
    assert.ok(T.dirtyIdbKeys.has('histarchive:acc'), 'écriture IndexedDB planifiée');
  });

  test('idempotent : réimporter le même fichier n’ajoute rien et ne double rien', async () => {
    const file = viaFile({ kind: 'mon-crunchy-config', history: { series: [entry('S', ['s1e1', 's1e2'], { seconds: 2880 })] } });
    await T.applyBackup(file);
    const again = await T.applyBackup(file);
    assert.deepEqual(plain(again.history), { read: 1, newSeries: 0, newEps: 0 });
    const a = T.historyArchiveLoad('acc').series.S;
    assert.equal(a.eps.length, 2);
    assert.equal(a.seconds, 2880);
  });

  test('fusionne avec ce que le nouveau compte a déjà vu, sans rien perdre', async () => {
    T.historyArchiveMerge('acc', [entry('S', ['s1e5', 's1e6'], { title: 'Série' })], 'history');
    const res = await T.applyBackup(viaFile({ kind: 'mon-crunchy-config', history: { series: [
      entry('S', ['s1e1', 's1e2', 's1e5']), entry('T', ['s2e1']),
    ] } }));
    assert.deepEqual(plain(res.history), { read: 2, newSeries: 1, newEps: 3 });
    const a = T.historyArchiveLoad('acc').series;
    assert.deepEqual([...a.S.eps].sort(), ['s1e1', 's1e2', 's1e5', 's1e6']);
    assert.equal(a.S.title, 'Série', 'le titre déjà connu est conservé');
  });

  test('met à jour tout de suite le détail en mémoire (Stats) quand il est chargé', async () => {
    T.HISTORY_DETAIL = [];
    await T.applyBackup(viaFile({ kind: 'mon-crunchy-config', history: { series: [entry('S', ['s1e1'], { title: 'S' })] } }));
    assert.ok(T.HISTORY_DETAIL.some((d) => d.id === 'S' && d.archived));
  });

  test('un export puis un import sur le MÊME compte ne change rien', async () => {
    T.historyArchiveMerge('acc', [entry('S', ['s1e1', 's1e2'])], 'history');
    const before = JSON.stringify(T.historyArchiveLoad('acc').series.S.eps);
    await T.applyBackup(viaFile(T.buildBackupPayload()));
    assert.equal(JSON.stringify(T.historyArchiveLoad('acc').series.S.eps), before);
    assert.equal(T.historyArchiveCount('acc'), 1);
  });

  test('réglages + filtres + ignorées sont toujours restaurés avec l’historique', async () => {
    T.IGNORED.set('X', { title: 'Cachée', source: 'watchlist' });
    T.saveIgnored && T.saveIgnored();
    const payload = viaFile(T.buildBackupPayload());
    payload.state.settings = { hideMovies: true };
    payload.history.series = [entry('S', ['s1e1'])];
    const res = await T.applyBackup(payload);
    assert.equal(res.settings, true);
    assert.equal(T.CFG.hideMovies, true);
    assert.equal(res.history.newSeries, 1);
  });

  test('une ancienne sauvegarde (sans history) reste importable', async () => {
    const res = await T.applyBackup({ kind: 'mon-crunchy-config', version: '4.12.2', state: { settings: { hideMovies: true }, filters: {}, ignored: {}, airsnap: {} } });
    assert.equal(res.ok, true);
    assert.equal(res.settings, true);
    assert.equal(res.history, null);
    assert.equal(T.CFG.hideMovies, true);
  });

  test('un fichier ne contenant QUE l’historique ne touche pas aux réglages', async () => {
    T.saveSettings({ hideMovies: true });
    const res = await T.applyBackup({ kind: 'mon-crunchy-config', history: { series: [entry('S', ['s1e1'])] } });
    assert.equal(res.ok, true);
    assert.equal(res.settings, false);
    assert.equal(T.CFG.hideMovies, true, 'réglage actuel conservé');
  });

  test('refuse un fichier étranger ou illisible, sans rien modifier', async () => {
    for (const bad of [null, 42, 'x', {}, { kind: 'autre', state: {} }, { kind: 'mon-crunchy-config' }, { kind: 'mon-crunchy-config', history: {} }]) {
      const res = await T.applyBackup(bad);
      assert.equal(res.ok, false, JSON.stringify(bad));
      assert.equal(res.error, 'format');
    }
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('entrées invalides écartées une à une, le reste est importé', async () => {
    const res = await T.applyBackup({ kind: 'mon-crunchy-config', history: { series: [
      null, 7, 'x', {}, { id: '' }, { id: 'SANS-EPS', eps: [] }, { id: 'EPS-BIZARRES', eps: [1, null, {}, ''] },
      { id: 'OK', title: 'Ok', eps: ['s1e1', 's1e1', 's1e2'], seconds: 'abc', genres: ['A', 3, 'A'] },
    ] } });
    assert.equal(res.history.read, 1);
    const a = T.historyArchiveLoad('acc').series;
    assert.deepEqual(plain(Object.keys(a)), ['OK']);
    assert.deepEqual([...a.OK.eps], ['s1e1', 's1e2'], 'doublon écarté');
    assert.equal(a.OK.seconds, 0, 'durée illisible → 0, jamais NaN');
    assert.deepEqual([...a.OK.genres], ['A']);
  });

  test('compte Crunchyroll introuvable : historique non importé, réglages quand même appliqués, message clair', async () => {
    T.ACCOUNT_ID = null;
    E.net.on(/accounts\/v1\/me/, () => ({ __status: 401, body: {} }));
    const res = await T.applyBackup({ kind: 'mon-crunchy-config', state: { settings: { hideMovies: true }, filters: {}, ignored: {}, airsnap: {} },
      history: { series: [entry('S', ['s1e1'])] } });
    assert.equal(res.settings, true);
    assert.equal(res.history, null);
    assert.ok(res.historyError);
    assert.equal(res.ok, true);
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('fichier géant : plafonné, ne fait pas planter', async () => {
    const series = Array.from({ length: 25000 }, (_, i) => entry('S' + i, ['s1e1']));
    const res = await T.applyBackup({ kind: 'mon-crunchy-config', history: { series } });
    assert.equal(res.history.read, 20000);
  });
});

describe('interface', () => {
  test('la carte Sauvegarde annonce ce qui sera exporté', () => {
    T.historyArchiveMerge('acc', [entry('A', ['s1e1', 's1e2']), entry('B', ['s1e1'])], 'history');
    const line = T.backupHistoryLine();
    assert.match(line, /<b>2<\/b> séries/);
    assert.match(line, /<b>3<\/b> épisodes/);
    E.close(); E = fresh(); T = E.T;
    assert.match(T.backupHistoryLine(), /aucun/);
  });
});

function captureDownload(inst) {
  const w = inst.w; const cap = { blob: null, name: null };
  w.URL.createObjectURL = (b) => { cap.blob = b; return 'blob:test'; };
  w.URL.revokeObjectURL = () => {};
  const origCreate = w.document.createElement.bind(w.document);
  w.document.createElement = (tag, o) => {
    const el = origCreate(tag, o);
    if (String(tag).toLowerCase() === 'a') { el.click = () => { cap.name = el.download; }; }
    return el;
  };
  return cap;
}

describe('chemin complet fichier (boutons Exporter / Importer)', () => {
  // jsdom n’a pas URL.createObjectURL : on capte le Blob que le bouton fabrique.
  const readBlob = (w, blob) => new Promise((res, rej) => { const r = new w.FileReader(); r.onload = () => res(String(r.result)); r.onerror = rej; r.readAsText(blob); });

  test('Exporter télécharge un .json contenant l’historique ; Importer (autre compte) le restaure', async () => {
    T.historyArchiveMerge('acc', [entry('MASHLE', ['s1e1', 's1e2'], { title: 'Mashle' })], 'history');
    const cap = captureDownload(E);
    await T.exportSettings();
    assert.match(cap.name, /^mon-crunchy-sauvegarde-\d{4}-\d{2}-\d{2}\.json$/);
    const text = await readBlob(E.w, cap.blob);
    const parsed = JSON.parse(text);
    assert.equal(parsed.history.series[0].id, 'MASHLE');

    const E2 = fresh(); const T2 = E2.T;
    try {
      T2.ACCOUNT_ID = 'perso';
      const file = new E2.w.File([text], 'sauvegarde.json', { type: 'application/json' });
      T2.importSettings(file, { assumeYes: true });
      for (let i = 0; i < 40 && !T2.historyArchiveCount('perso'); i++) await E2.tick(10);
      assert.equal(T2.historyArchiveCount('perso'), 1);
      assert.deepEqual(plain([...T2.historyArchiveLoad('perso').series.MASHLE.eps]), ['s1e1', 's1e2']);
    } finally { E2.close(); }
  });

  test('la carte des réglages affiche la nouvelle sauvegarde et le compteur', () => {
    T.historyArchiveMerge('acc', [entry('A', ['s1e1'])], 'history');
    const html = T.settingsPanel();
    assert.match(html, /Sauvegarde \(réglages \+ historique\)/);
    assert.match(html, /Historique mémorisé sur cet appareil : <b>1<\/b> série/);
    assert.match(html, /data-act="export-settings"/);
    assert.match(html, /data-act="import-settings"/);
  });
});

describe('épisodes importés = vus (v4.14.0)', () => {
  const eps12 = () => Array.from({ length: 12 }, (_, i) => ({ season: 1, n: i + 1, dur: 1440, id: `E${i + 1}`, ids: [`E${i + 1}`], air: null }));
  const panel = { id: 'S', title: 'Série', slug_title: 's', images: {}, series_metadata: { tenant_categories: [] } };
  const build = (ph = new Map()) => T.buildSeriesEntry(panel, eps12(), null, null, 0, ph, null);

  test('compte neuf (aucune progression Crunchyroll) : les épisodes de l’archive sont vus', () => {
    assert.equal(build().seen, 0);
    T.historyArchiveMerge('acc', [entry('S', ['s1e1', 's1e2', 's1e3'])], 'import');
    const s = build();
    assert.equal(s.seen, 3);
    assert.equal(s.next.n, 4, 'le prochain épisode à voir suit ce qui est vu');
    assert.equal(s.remaining, 9);
  });

  test('série entièrement dans l’archive : terminée (remaining 0)', () => {
    T.historyArchiveMerge('acc', [entry('S', Array.from({ length: 12 }, (_, i) => `s1e${i + 1}`))], 'import');
    assert.equal(build().remaining, 0);
  });

  test('ne fait que combler : un épisode commencé chez Crunchyroll reste « commencé »', () => {
    T.historyArchiveMerge('acc', [entry('S', ['s1e1', 's1e2'])], 'import');
    const ph = new Map([['E2', { p: 300 }]]);
    const s = build(ph);
    assert.equal(s.episodes[1].started, true);
    assert.equal(s.episodes[1].seen, false, 'pas écrasé par l’archive');
    assert.equal(s.episodes[0].seen, true);
    assert.equal(s.resuming, true);
  });

  test('une autre série n’est pas touchée', () => {
    T.historyArchiveMerge('acc', [entry('AUTRE', ['s1e1', 's1e2'])], 'import');
    assert.equal(build().seen, 0);
  });

  test('sans compte identifié : aucun effet, aucune erreur', () => {
    T.historyArchiveMerge('acc', [entry('S', ['s1e1'])], 'import');
    T.ACCOUNT_ID = null;
    assert.equal(build().seen, 0);
  });
});

describe('complétude et robustesse de l’archive (v4.15.0)', () => {
  const { ep, series } = require('./lib/env');
  const mk = (id, nSeen, nTotal = 12, extra = {}) => series(id,
    Array.from({ length: nTotal }, (_, i) => ep(1, i + 1, { seen: i < nSeen, started: i === nSeen && extra.started })), { title: id, categories: ['Action'] });

  test('une série de Reste à voir (vue hors fenêtre historique) part dans l’export', () => {
    T.STATE.series = [mk('OLDWL', 10)];
    const s = plain(T.buildBackupPayload().history.series).find((d) => d.id === 'OLDWL');
    assert.ok(s, 'présente');
    assert.equal(s.eps.length, 10);
    assert.equal(s.seconds, 10 * 1440);
    assert.deepEqual(s.genres, ['Action']);
  });

  test('idem pour une série de Hors listes ; une série sans épisode vu est ignorée', () => {
    T.STATE.orphan.series = [mk('ORPH', 3), mk('RIEN', 0)];
    const ids = plain(T.buildBackupPayload().history.series.map((d) => d.id));
    assert.deepEqual(ids, ['ORPH']);
  });

  test('un épisode commencé compte (comme une entrée d’historique), sans durée inventée', () => {
    T.STATE.series = [mk('ST', 2, 12, { started: true })];
    const s = plain(T.buildBackupPayload().history.series).find((d) => d.id === 'ST');
    assert.equal(s.eps.length, 3);
    assert.equal(s.seconds, 2 * 1440);
  });

  test('archivé aussi sans export : après un chargement réussi de Reste à voir / Hors listes', () => {
    T.archiveLoadedSeries('acc', [mk('X', 4)], 'lists');
    assert.equal(T.historyArchiveLoad('acc').series.X.eps.length, 4);
    assert.equal(T.archiveLoadedSeries('acc', [mk('X', 4)], 'lists'), 0, 'idempotent');
  });

  test('« Vider le cache » épargne l’archive et vide le reste', async () => {
    for (let i = 0; i < 20; i++) await E.tick(10);           // laisse finir l’initialisation du cache au démarrage
    T.historyArchiveMerge('acc', [entry('S', ['s1e1', 's1e2'])], 'history');
    T.cacheSet('rating:Z', { r: 4 });
    T.clearCache();
    assert.equal(T.historyArchiveCount('acc'), 1);
    assert.equal(T.cacheGetStale('rating:Z'), null);
    for (let i = 0; i < 20; i++) await E.tick(10);           // l’écriture disque suit le vidage
    const onDisk = await T.idbGet('histarchive:acc');
    assert.ok(onDisk && onDisk.v.series.S, 'toujours sur disque');
    assert.equal(await T.idbGet('tier'), T.CACHE_TIER, 'palier réécrit');
  });

  test('un changement de palier du cache ne détruit pas l’archive (ni sur disque, ni en mémoire)', async () => {
    T.historyArchiveMerge('acc', [entry('S', ['s1e1'])], 'history');
    await T.idbSet('histarchive:acc', T.BIGCACHE['histarchive:acc']);
    await T.idbSet('rating:Q', { ts: 1, v: { r: 5 } });
    await T.idbSet('tier', 'ancien-palier');                  // disque écrit par un autre palier
    for (const k of Object.keys(T.BIGCACHE)) delete T.BIGCACHE[k];
    await T.initBigCache();
    for (let i = 0; i < 20; i++) await E.tick(10);
    assert.equal(T.historyArchiveCount('acc'), 1, 'en mémoire');
    assert.ok((await T.idbGet('histarchive:acc')).v.series.S, 'sur disque');
    assert.equal(await T.idbGet('rating:Q'), null, 'le reste du cache est bien invalidé');
    assert.equal(await T.idbGet('tier'), T.CACHE_TIER);
  });
});

describe('modale d’import étape par étape (v4.16.0)', () => {
  const stepsOf = () => Array.from(E.w.document.querySelectorAll('#crrav-imp li')).map((li) => ({ k: li.dataset.k, st: li.className, d: li.querySelector('small').textContent }));
  const st = (k) => stepsOf().find((s) => s.k === k).st;
  const fileOf = (obj) => new E.w.File([typeof obj === 'string' ? obj : JSON.stringify(obj)], 'sauvegarde.json', { type: 'application/json' });
  const waitFor = async (fn, n = 400) => { for (let i = 0; i < n && !fn(); i++) await E.tick(10); };
  const withRoot = () => { T.open(); };
  const good = () => ({ kind: 'mon-crunchy-config', version: '4.15.0',
    state: { settings: {}, filters: {}, ignored: {}, airsnap: {} },
    history: { series: [entry('A', ['s1e1', 's1e2']), entry('B', ['s1e1'])] } });

  test('affiche les 6 étapes puis le bilan ; l’historique est bien fusionné', async () => {
    withRoot();
    T.importSettings(fileOf(good()), { assumeYes: true });
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.done);
    assert.ok(T.STATE.importModal.done, 'flux terminé');
    assert.deepEqual(plain(stepsOf().map((s) => s.k)), ['read', 'check', 'target', 'settings', 'history', 'lists', 'orphans']);
    for (const k of ['read', 'check', 'target', 'settings', 'history']) assert.equal(st(k), 'done', k);
    assert.match(stepsOf().find((s) => s.k === 'check').d, /2 séries · 3 épisodes d'historique \+ réglages · créée avec la v4\.15\.0/);
    assert.match(stepsOf().find((s) => s.k === 'history').d, /\+2 séries · \+3 épisodes ajoutés/);
    assert.ok(['done', 'error'].includes(st('lists')) && ['done', 'error'].includes(st('orphans')));
    assert.match(E.w.document.querySelector('.crrav-imp-title').textContent, /Import terminé/);
    assert.equal(E.w.document.querySelector('.crrav-imp-bar i').style.width, '100%');
    assert.equal(E.w.document.querySelector('[data-imp-close]').textContent, 'Terminé');
    assert.equal(T.historyArchiveCount('acc'), 2);
  });

  test('pendant les relectures réseau : étapes précédentes faites, courante « en cours », suivantes en attente', async () => {
    withRoot();
    let release; const gate = new Promise((r) => { release = r; });
    E.net.on(/discover\/acc\/watchlist/, async () => { await gate; return { data: [], total: 0 }; });
    T.importSettings(fileOf(good()), { assumeYes: true });
    await waitFor(() => T.STATE.importModal && st('lists') === 'running');
    assert.deepEqual(plain(['read', 'check', 'target', 'settings', 'history'].map(st)), ['done', 'done', 'done', 'done', 'done']);
    assert.equal(st('lists'), 'running');
    assert.equal(st('orphans'), 'pending');
    assert.equal(E.w.document.querySelector('[data-imp-close]').textContent, 'Continuer en arrière-plan');
    assert.notEqual(E.w.document.querySelector('.crrav-imp-bar i').style.width, '100%');
    assert.ok(stepsOf().find((s) => s.k === 'lists').d.length > 0, 'détail de progression affiché');
    release();
    await waitFor(() => T.STATE.importModal.done);
    assert.ok(T.STATE.importModal.done);
  });

  test('« Continuer en arrière-plan » ferme la modale sans interrompre l’import', async () => {
    withRoot();
    let release; const gate = new Promise((r) => { release = r; });
    E.net.on(/discover\/acc\/watchlist/, async () => { await gate; return { data: [], total: 0 }; });
    T.importSettings(fileOf(good()), { assumeYes: true });
    await waitFor(() => T.STATE.importModal && st('lists') === 'running');
    const M = T.STATE.importModal;
    E.w.document.querySelector('[data-imp-close]').click();
    assert.equal(T.STATE.importModal, null);
    assert.equal(E.w.document.querySelector('#crrav-imp'), null, 'nœud retiré');
    release();
    await waitFor(() => M.done);
    assert.ok(M.done, 'l’import va au bout en arrière-plan');
    assert.equal(E.w.document.querySelector('#crrav-imp'), null, 'et ne réapparaît pas');
    assert.equal(T.historyArchiveCount('acc'), 2);
  });

  test('sauvegarde de réglages seule : historique et Hors listes sautés', async () => {
    withRoot();
    const f = good(); delete f.history;
    T.importSettings(fileOf(f), { assumeYes: true });
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.done);
    assert.equal(st('history'), 'skipped');
    assert.equal(st('orphans'), 'skipped');
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('fichier invalide : erreur claire à la vérification, rien n’est modifié, bouton Fermer', async () => {
    withRoot();
    T.importSettings(fileOf('{ pas du json'));
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.failed);
    assert.ok(T.STATE.importModal.failed);
    assert.equal(st('read'), 'done');
    assert.equal(st('check'), 'error');
    assert.match(stepsOf().find((s) => s.k === 'check').d, /pas une sauvegarde de Mon Crunchy/);
    for (const k of ['settings', 'history', 'lists', 'orphans']) assert.equal(st(k), 'skipped', k);
    assert.match(E.w.document.querySelector('.crrav-imp-title').textContent, /Import impossible/);
    assert.equal(E.w.document.querySelector('[data-imp-close]').textContent, 'Fermer');
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('compte introuvable : l’étape historique échoue avec le bon message, les suivantes ne partent pas', async () => {
    withRoot();
    T.ACCOUNT_ID = null;
    E.net.on(/accounts\/v1\/me/, () => ({ __status: 401, body: {} }));
    T.importSettings(fileOf(good()), { assumeYes: true });
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.failed);
    assert.equal(st('target'), 'error');
    assert.equal(st('settings'), 'skipped', 'rien n’est écrit avant d’avoir identifié la destination');
    assert.match(stepsOf().find((s) => s.k === 'target').d, /connecte-toi puis réimporte/);
    assert.equal(st('lists'), 'skipped');
  });

  test('la feuille Réglages est fermée pour ne pas rester derrière la modale', async () => {
    withRoot();
    T.STATE.settingsOpen = true;
    T.importSettings(fileOf(good()), { assumeYes: true });
    assert.equal(T.STATE.settingsOpen, false);
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.done);
  });
});

describe('profils Crunchyroll (v4.17.0)', () => {
  const fileOf = (obj) => new E.w.File([typeof obj === 'string' ? obj : JSON.stringify(obj)], 's.json', { type: 'application/json' });
  const waitFor = async (fn, n = 400) => { for (let i = 0; i < n && !fn(); i++) await E.tick(10); };
  const payloadOf = (from, series) => ({ kind: 'mon-crunchy-config', version: '4.17.0',
    state: { settings: {}, filters: {}, ignored: {}, airsnap: {} },
    history: { scope: from, series } });

  test('deux profils du même compte ont chacun leur archive, sans mélange', () => {
    T.setProfile('p1', 'Geoffrey');
    T.historyArchiveMerge('acc', [entry('A', ['s1e1'])], 'history');
    assert.ok(T.cacheGetStale('histarchive:acc~p1'));
    T.PROFILE_ID = null; T.PROFILE_TRIED = true;
    T.setProfile('p2', 'Ami');
    T.historyArchiveMerge('acc', [entry('B', ['s1e1'])], 'history');
    assert.deepEqual(plain(Object.keys(T.historyArchiveLoad('acc').series)), ['B']);
    T.PROFILE_ID = 'p1';
    assert.deepEqual(plain(Object.keys(T.historyArchiveLoad('acc').series)), ['A']);
  });

  test('export normal = profil actif seulement ; « tout » = tous les profils', () => {
    T.setProfile('p1', 'Geoffrey');
    T.historyArchiveMerge('acc', [entry('A', ['s1e1'])], 'history');
    T.cacheSet('histarchive:acc~p2', { v: 1, series: { B: { id: 'B', title: 'B', eps: ['s1e1'], seconds: 1, genres: [] } } });
    const p = T.buildBackupPayload();
    assert.deepEqual(plain(p.history.series.map((d) => d.id)), ['A']);
    assert.equal(p.history.scope.profileId, 'p1');
    assert.equal(p.history.scope.profileName, 'Geoffrey');
    assert.deepEqual(plain(T.buildBackupPayload({ all: true }).history.series.map((d) => d.id)).sort(), ['A', 'B']);
  });

  test('archive d’avant la 4.17 : adoptée une seule fois par le premier profil identifié', () => {
    T.historyArchiveMerge('acc', [entry('OLD', ['s1e1', 's1e2'])], 'history');   // clé « compte » (aucun profil)
    T.setProfile('p1', 'Geoffrey');
    assert.deepEqual(plain(Object.keys(T.historyArchiveLoad('acc').series)), ['OLD']);
    assert.equal(T.cacheGetStale('histarchive:acc').adoptedBy, 'p1');
    T.PROFILE_ID = null;
    T.setProfile('p2', 'Ami');
    assert.deepEqual(plain(Object.keys(T.historyArchiveLoad('acc').series)), [], 'le 2e profil ne récupère pas l’archive adoptée');
  });

  test('profil changé en cours de session : écritures suspendues, export refusé', async () => {
    T.setProfile('p1', 'Geoffrey');
    T.historyArchiveMerge('acc', [entry('A', ['s1e1'])], 'history');
    T.setProfile('p2', 'Ami');
    assert.equal(T.PROFILE_CHANGED, true);
    assert.equal(T.histWritable(), false);
    T.historyArchiveMerge('acc', [entry('X', ['s1e1'])], 'history');
    assert.deepEqual(plain(Object.keys(T.historyArchiveLoad('acc').series)), ['A'], 'rien n’a été écrit');
    const cap = captureDownload(E);
    await T.exportSettings();
    assert.equal(cap.blob, null, 'aucun fichier téléchargé');
  });

  test('profil détecté par le réseau (/accounts/v1/me/profile) et mémorisé', async () => {
    T.PROFILE_TRIED = false;
    E.net.on(/accounts\/v1\/me\/profile/, () => ({ profile_id: 'PX', profile_name: 'Geoffrey' }));
    await T.getAccountId();
    assert.equal(T.profileInfo().profileId, 'PX');
    assert.equal(T.profileInfo().scope, 'acc~PX');
  });

  test('profil introuvable mais connu auparavant : écritures suspendues (pas de mélange)', async () => {
    E.w.localStorage.setItem('crrav-last-profile:acc', 'p1');
    T.PROFILE_TRIED = false;                                     // /me/profile → 404
    await T.getAccountId();
    assert.equal(T.PROFILE_ID, null);
    assert.equal(T.histWritable(), false);
  });

  test('profil introuvable et jamais connu : repli sur la clé « compte » (comportement 4.16)', async () => {
    T.PROFILE_TRIED = false;
    await T.getAccountId();
    assert.equal(T.histWritable(), true);
    T.historyArchiveMerge('acc', [entry('A', ['s1e1'])], 'history');
    assert.ok(T.cacheGetStale('histarchive:acc'));
  });

  test('import : le fichier d’un AUTRE profil demande confirmation, annuler ne modifie rien', async () => {
    T.open();
    T.setProfile('p2', 'Perso');
    T.importSettings(fileOf(payloadOf({ all: false, profileId: 'p1', profileName: 'Ami' }, [entry('A', ['s1e1'])])));
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.ask);
    const ask = E.w.document.querySelector('#crrav-imp .crrav-imp-ask');
    assert.equal(ask.hidden, false);
    assert.match(ask.textContent, /profil « Ami »/);
    assert.match(ask.textContent, /« Perso »/);
    E.w.document.querySelector('[data-imp-no]').click();
    await waitFor(() => T.STATE.importModal.failed);
    assert.match(E.w.document.querySelector('#crrav-imp li[data-k="target"] small').textContent, /annulé/);
    assert.equal(T.historyArchiveCount('acc'), 0);
    assert.equal(E.w.document.querySelector('#crrav-imp li[data-k="settings"]').className, 'skipped');
  });

  test('import : confirmer fusionne dans le profil actif UNIQUEMENT', async () => {
    T.open();
    T.setProfile('p2', 'Perso');
    T.cacheSet('histarchive:acc~p9', { v: 1, series: {} });
    T.importSettings(fileOf(payloadOf({ all: false, profileId: 'p1', profileName: 'Ami' }, [entry('A', ['s1e1', 's1e2'])])));
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.ask);
    E.w.document.querySelector('[data-imp-yes]').click();
    await waitFor(() => T.STATE.importModal.done);
    assert.deepEqual(plain(Object.keys(T.cacheGetStale('histarchive:acc~p2').series)), ['A']);
    assert.deepEqual(plain(Object.keys(T.cacheGetStale('histarchive:acc~p9').series)), []);
    assert.ok(!T.cacheGetStale('histarchive:acc'), 'rien dans la clé du compte');
  });

  test('import : même profil que l’export → aucune question', async () => {
    T.open();
    T.setProfile('p1', 'Geoffrey');
    T.importSettings(fileOf(payloadOf({ all: false, profileId: 'p1', profileName: 'Geoffrey' }, [entry('A', ['s1e1'])])));
    await waitFor(() => T.STATE.importModal.done);
    assert.equal(T.historyArchiveCount('acc'), 1);
  });

  test('import : fichier sans provenance, ou export « tous les profils » → question', async () => {
    T.open();
    T.setProfile('p1', 'Geoffrey');
    for (const from of [undefined, { all: true }]) {
      T.importSettings(fileOf(payloadOf(from, [entry('A', ['s1e1'])])));
      await waitFor(() => T.STATE.importModal && T.STATE.importModal.ask);
      assert.ok(T.STATE.importModal.ask, JSON.stringify(from));
      E.w.document.querySelector('[data-imp-no]').click();
      await waitFor(() => T.STATE.importModal.failed);
    }
  });

  test('import : profil changé depuis l’ouverture → refusé, rien d’écrit', async () => {
    T.open();
    T.setProfile('p1', 'Geoffrey');
    E.net.on(/accounts\/v1\/me\/profile/, () => ({ profile_id: 'p2', profile_name: 'Ami' }));
    T.importSettings(fileOf(payloadOf({ profileId: 'p1', profileName: 'Geoffrey' }, [entry('A', ['s1e1'])])), { assumeYes: true });
    await waitFor(() => T.STATE.importModal.failed);
    assert.match(E.w.document.querySelector('#crrav-imp li[data-k="target"] small').textContent, /a changé/);
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('fermer la modale pendant la question = annuler', async () => {
    T.open();
    T.setProfile('p2', 'Perso');
    const run = T.runImportFlow(fileOf(payloadOf({ profileId: 'p1', profileName: 'Ami' }, [entry('A', ['s1e1'])])));
    await waitFor(() => T.STATE.importModal && T.STATE.importModal.ask);
    E.w.document.querySelector('[data-imp-close]').click();
    await run;
    assert.equal(T.historyArchiveCount('acc'), 0);
  });

  test('carte Réglages : profil affiché, bouton « Tout exporter »', () => {
    T.setProfile('p1', 'Geoffrey');
    const html = T.settingsPanel();
    assert.match(html, /Profil Crunchyroll détecté : <b>Geoffrey<\/b>/);
    assert.match(html, /data-act="export-settings-all"/);
  });

  test('console : resteAVoir.profile() / profileInfo', () => {
    T.setProfile('p1', 'Geoffrey');
    assert.deepEqual(plain(T.profileInfo()), { accountId: 'acc', profileId: 'p1', profileName: 'Geoffrey', scope: 'acc~p1', changed: false, writable: true });
  });
});
