# Tests de non-régression — Mon Crunchy

Ces tests chargent le **vrai `script.js`** (sans le modifier) dans un navigateur simulé
(jsdom + IndexedDB simulé), avec Crunchyroll et AniList simulés et une horloge pilotable.
Toutes les fonctions internes du script sont accessibles aux tests.

## Installation (une fois)

Place le dossier `tests/` à côté de `script.js` et `script-safari.js`, puis :

```
cd tests
npm install
```

## Lancer

```
npm test            # script.js (~10 s)
npm run test:safari # script-safari.js
```

Un autre fichier : `CRRAV_SCRIPT=/chemin/vers/script.js npm test`.

Résultat attendu : tout `pass`, `fail 0`. Les lignes `# TODO` sont des **bugs réels
détectés par la suite**, pas encore corrigés : elles ne font pas échouer la suite, mais
disparaissent (passent en `pass`) dès que le correctif est livré — retire alors l'option
`todo` du test concerné.

## Contenu

| Fichier | Couvre |
|---|---|
| `01-utils` | versions (@version = SCRIPT_VERSION), formats, garde-fous asynchrones, pool, rythme 429, URLs |
| `02-cache` | TTL / lecture « stale », éviction, persistance IndexedDB, palier de schéma, instantanés, notes et AniList périmés gardés à l'écran |
| `03-history` | décodage, total bidon (v4.7.0), repère temporel (v4.6.0), pages perdues, caches anciens, rescan hebdo |
| `04-correlation` | titres, filet « déjà vu par titre », choix de la fiche AniList, AniList → Crunchyroll, saisons |
| `05-anilist` | planning, genres/tags, reprises, coupe-circuit, requêtes groupées |
| `06-episodes` | vu/commencé, reprise, temps restant, films, cases (v3.90 → v3.99), calendrier |
| `07-discover-scoring` | profil de goût, cosinus, paliers, plafond sans AniList, 💞, filtres de genre |
| `08-state` | filtres (verrou mode similaire), migrations, ignorées, navigation de session |
| `09-render` | pas de « saut » pendant un rafraîchissement, cartes robustes, échappement HTML |
| `11-history-archive` | mémoire permanente de l'historique, complétion par l'avancement réel (bouton diagnostic), Découverte qui alimente l'historique |
| `12-history-growth` | historique qui grossit sur des semaines malgré la fenêtre glissante Crunchyroll : jamais de perte, épisodes cumulés, rechargement, purges de cache |
| `13-series-page` | bouton « Retrouver mes séries déjà vues » dans Hors listes, ajout à l'historique à l'ouverture d'une fiche série |
| `14-backup-history` | sauvegarde / restauration de l'historique (v4.13 → v4.17) : export tous comptes confondus, import fusionné et idempotent, scénario « changement de compte », épisodes importés = vus, archive épargnée par « Vider le cache » et par un changement de palier, modale d'import étape par étape, profils Crunchyroll (archive et import rattachés au profil actif, confirmation, gel si le profil change) |
| `15-episode-numbers-notes` | v4.18 : numéro d'épisode relatif à la saison (numérotation continue Crunchyroll vs AniList par saison, calendrier « S3 E4 / tu en es à S3 E3 »), notes perso ★ archivées / exportées / importées (jamais écrasées, épargnées par « Vider le cache », par profil) |
| `16-calendar` | v4.19 (+ responsive : paliers de conteneur, nouveautés distinctes) : calendrier (Agenda / Semaine / Mois, horizon jusqu'à 1 an) — projection des épisodes suivants plafonnée par le total prévu, dates exactes AniList, séries ignorées jamais affichées (épisodes, nouveautés, export), nouveautés lointaines AniList (précision heure/jour/mois/saison, cache, panne, couverture), filtres et options mémorisés, export .ics (CRLF, UTC, rappel, pliage 75 octets), cas limites (vide, 120 séries, titres piégés) |
| `17-agenda-button` | v4.20.0 : bouton flottant « Agenda » (accès direct au calendrier, prochaine sortie, badge du jour, séries ignorées exclues, mobile) + bouton « Agenda complet » de l’accueil Crunchyroll |
| `18-calendar-filters-month-series` | v4.21.0 : filtres du calendrier (groupes, À commencer / Derniers ép. / Suites, recherche, dates confirmées, compteurs), vue Mois visuelle (affiches, pastilles, couleurs, « +N »), agenda d’une série (fiche, frise, .ics, points d’entrée) |
| `19-calendar-structure` | v4.21.3 : garde-fous STRUCTURELS sur le DOM produit par de vrais clics (lib/scenarios.js) : feuilles toujours sous `.crrav-modals`, aucune `position:fixed` dans `.crrav-cal`, ouvrir/fermer ne touche pas au flux de la page, chaque `data-act="cal-*"` rendu a un gestionnaire, libellés accessibles |
| `20-layout-e2e` | v4.21.3 : mise en page dans un VRAI Chromium, 280→3840 px (+ bornes 1039/1040/1059/1060/1139/1140/1159/1160) : débordement horizontal, ancrage et taille des feuilles, plein écran mobile, jamais de « zone morte » Options/panneau, cartes du jour jamais en lamelle, vue Mois, filtres, boutons flottants, boutons agenda sans chevauchement. Se saute si Playwright/Chromium absents ; `npm run test:layout` pour le forcer (`CRRAV_CHROMIUM=/chemin`) |
| `21-calendar-released` | v4.22.0 : le calendrier montre aussi le PASSÉ — régression « jours passés de la semaine vides », semaine glissante (−3/+3) ou lundi→dimanche, navigation arrière (26 sem. / 12 mois), épisodes sortis vus / pas vus, règle NEW (ép. 1 ou précédent > 30 j, bornes à 30 j), SxEy (rang réel de saison), note, image wide (repli affiche recadrée), « Tout Crunchyroll » (grille AniList hors listes : parsing, filtres CR, dédoublonnage listes / nouveautés / ignorées, pagination, cache, panne), séries en pause, propriété de COMPLÉTUDE (aucun épisode perdu ni dupliqué sur des centaines de séries), clics réels | ; v4.22.1 : pastilles passé / aujourd'hui / à venir, badge NEW sans collision de classe, liens fiables ; v4.23.0 : nouvelles séries lues directement chez Crunchyroll (browse « ajouté récemment » → épisode 1 : filtres, cache, panne), tuiles à image large (titre, S · E, heure, note, détail au toucher) ; **v4.24.0 : calendrier 100 % Crunchyroll** (plus aucune donnée AniList pour le passé ni les nouveautés : régressions « Carnets E1 fantôme » = date réécrite ignorée, « GelPiyo 2 » inexistant ; « Tout Crunchyroll » = catalogue de la saison par étiquette `seasonal_tag`, cache, panne, ignorées, dédoublonnage), panneau « Affichage » supprimé, filtres Statut exclusif + Repères cumulables (compteurs conditionnels exacts sur toutes les combinaisons, retoucher = annuler, migration des anciens réglages), bouton « Regarder » jamais coupé (mesuré dans Chromium sur toutes les familles de tuiles) |
| `10-discover-e2e` | vrais scans Découverte et Hors listes de bout en bout : exclusions, terminaison, bilan, reprises |

## Règle

À chaque bug corrigé, ajouter **un test qui échoue sans le correctif** (dans le fichier du
domaine concerné). Vérification : la suite échoue sur la 4.5.5 (historique + Mashle de
bout en bout) et sur la 4.7.0 (pause AniList, boucle infinie Découverte, Hors listes) ;
elle passe entièrement sur la 4.8.0.

## Outils (`lib/`)

- `loader.js` : charge le script, expose `T` (fonctions et variables internes), réseau simulé `net.on(regex, handler)`.
- `env.js` : `fresh()` (instance neuve, session valide, horloge `advance()`), fabriques `ep()`, `series()`, `historyEntry()`, `routeHistory()`.
