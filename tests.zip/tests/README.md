# Tests de non-régression — Mon Crunchy

Ces tests chargent le **vrai `script.js`** (sans le modifier) dans un navigateur simulé
(jsdom + IndexedDB simulé), avec Crunchyroll et AniList simulés et une horloge pilotable.
Toutes les fonctions internes du script sont accessibles aux tests.

## Installation (une fois)

Place le dossier `tests/` à côté de `script.js` et `script-safari.js`, puis :

```
cd tests
npm install
```

## Lancer

```
npm test            # script.js (~10 s)
npm run test:safari # script-safari.js
```

Un autre fichier : `CRRAV_SCRIPT=/chemin/vers/script.js npm test`.

Résultat attendu : tout `pass`, `fail 0`. Les lignes `# TODO` sont des **bugs réels
détectés par la suite**, pas encore corrigés : elles ne font pas échouer la suite, mais
disparaissent (passent en `pass`) dès que le correctif est livré — retire alors l'option
`todo` du test concerné.

## Contenu

| Fichier | Couvre |
|---|---|
| `01-utils` | versions (@version = SCRIPT_VERSION), formats, garde-fous asynchrones, pool, rythme 429, URLs |
| `02-cache` | TTL / lecture « stale », éviction, persistance IndexedDB, palier de schéma, instantanés, notes et AniList périmés gardés à l'écran |
| `03-history` | décodage, total bidon (v4.7.0), repère temporel (v4.6.0), pages perdues, caches anciens, rescan hebdo |
| `04-correlation` | titres, filet « déjà vu par titre », choix de la fiche AniList, AniList → Crunchyroll, saisons |
| `05-anilist` | planning, genres/tags, reprises, coupe-circuit, requêtes groupées |
| `06-episodes` | vu/commencé, reprise, temps restant, films, cases (v3.90 → v3.99), calendrier |
| `07-discover-scoring` | profil de goût, cosinus, paliers, plafond sans AniList, 💞, filtres de genre |
| `08-state` | filtres (verrou mode similaire), migrations, ignorées, navigation de session |
| `09-render` | pas de « saut » pendant un rafraîchissement, cartes robustes, échappement HTML |
| `11-history-archive` | mémoire permanente de l'historique, complétion par l'avancement réel (bouton diagnostic), Découverte qui alimente l'historique |
| `12-history-growth` | historique qui grossit sur des semaines malgré la fenêtre glissante Crunchyroll : jamais de perte, épisodes cumulés, rechargement, purges de cache |
| `13-series-page` | bouton « Retrouver mes séries déjà vues » dans Hors listes, ajout à l'historique à l'ouverture d'une fiche série |
| `10-discover-e2e` | vrais scans Découverte et Hors listes de bout en bout : exclusions, terminaison, bilan, reprises |

## Règle

À chaque bug corrigé, ajouter **un test qui échoue sans le correctif** (dans le fichier du
domaine concerné). Vérification : la suite échoue sur la 4.5.5 (historique + Mashle de
bout en bout) et sur la 4.7.0 (pause AniList, boucle infinie Découverte, Hors listes) ;
elle passe entièrement sur la 4.8.0.

## Outils (`lib/`)

- `loader.js` : charge le script, expose `T` (fonctions et variables internes), réseau simulé `net.on(regex, handler)`.
- `env.js` : `fresh()` (instance neuve, session valide, horloge `advance()`), fabriques `ep()`, `series()`, `historyEntry()`, `routeHistory()`.
