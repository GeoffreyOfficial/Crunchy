'use strict';
// v4.27.0 — Saisons Crunchyroll découpées en « parties » / épisodes rangés dans la mauvaise saison (Black Clover : « S3 · E1 » et
// « S4 · E1 » le même jour au lieu de S2E1 / S2E2), noms AniList « 2nd Season » / « 3rd Season Part 2 », nouvelles saisons dans
// « Reprises », filtres Favoris / Derniers ép. retirés.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
const ANI = /graphql\.anilist\.co/;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const plain = (v) => JSON.parse(JSON.stringify(v));

// Série façon Black Clover : 4 parties de « Saison 1 » (numérotation continue 1-170), un OVA, puis « Saison 2 » (E171-174).
function mockBlackClover(o = {}) {
  const now = E.now();
  const seasons = [
    { id: 'p1', title: 'Black Clover Saison 1 Partie 1', season_number: 1, season_sequence_number: 1, series_title: 'Black Clover', size: 51, from: 1 },
    { id: 'p2', title: 'Black Clover Saison 1 Partie 2', season_number: o.sameNo ? 1 : 2, season_sequence_number: 2, series_title: 'Black Clover', size: 51, from: 52 },
    { id: 'p3', title: 'Black Clover Saison 1 Partie 3', season_number: o.sameNo ? 1 : 3, season_sequence_number: 3, series_title: 'Black Clover', size: 52, from: 103 },
    { id: 'p4', title: 'Black Clover Saison 1 Partie 4', season_number: o.sameNo ? 1 : 4, season_sequence_number: 4, series_title: 'Black Clover', size: 16, from: 155 },
    { id: 'ov', title: 'SP: OVA', season_number: 5, season_sequence_number: 5, series_title: 'Black Clover', size: 1, from: 1 },
    { id: 's2', title: 'Saison 2', season_number: o.s2No ?? 6, season_sequence_number: 6, series_title: 'Black Clover', size: 4, from: 171 },
  ];
  const iso = (ms) => new Date(ms).toISOString();
  const s2Dates = [now - 10 * DAY, now - 10 * DAY, now - 3 * DAY, now - 0.5 * DAY];     // E171 + E172 le même jour, puis hebdo
  E.net.on(/\/content\/v2\/cms\/series\/BC\/seasons/, () => ({ data: seasons }));
  E.net.on(/\/content\/v2\/cms\/seasons\/([^/?]+)\/episodes/, (u) => {
    const id = u.match(/seasons\/([^/?]+)\/episodes/)[1];
    const s = seasons.find((x) => x.id === id);
    return { data: Array.from({ length: s.size }, (_, i) => {
      const t = id === 's2' ? s2Dates[i] : now - (2000 - s.from - i) * DAY;
      // « Saison 2 » : chaque épisode porte un season_number DIFFÉRENT (7, 8, 9, 10) alors qu'il est rangé dans une seule entrée
      const sn = id === 's2' && o.spread !== false ? 7 + i : s.season_number;
      return { id: id + 'e' + i, episode_number: s.from + i, title: 'E' + (s.from + i), duration_ms: 1440000, season_number: sn, episode_air_date: iso(t), availability_starts: iso(t) };
    }) };
  });
}
async function loadBC(o) {
  mockBlackClover(o);
  const out = await T.fetchEpisodesRaw('BC');
  const panel = { id: 'BC', title: 'Black Clover', slug_title: 'black-clover', images: {}, series_metadata: { tenant_categories: [] } };
  const ph = new Map(out.episodes.map((e) => [e.id, { p: 1440, full: true }]));
  const s = T.buildSeriesEntry(panel, out.episodes, out.maxAir, null, 0, ph, null);
  return { out, s };
}

describe('RÉGRESSION Black Clover : saison 2 = S2E1, S2E2… (pas S3E1 / S4E1)', () => {
  for (const [name, o] of [['numéros de saison distincts par partie', {}], ['même numéro de saison partout', { sameNo: true }], ['« Saison 2 » au numéro déjà pris', { s2No: 2 }]]) {
    test(name, async () => {
      const { s } = await loadBC(o);
      const seasons = [...new Set(s.episodes.map((e) => e.season))];
      assert.equal(seasons.length, 2, 'les 4 parties = UNE saison, puis « Saison 2 » : ' + JSON.stringify(seasons));
      assert.equal(s.episodes.length, 51 + 51 + 52 + 16 + 4, 'OVA exclu, aucun épisode perdu');
      const e171 = s.episodes.find((e) => e.n === 171), e103 = s.episodes.find((e) => e.n === 103);
      assert.equal(T.epRelN(s, e171), 1, 'E171 = épisode 1 de la saison 2');
      assert.equal(T.epRelN(s, e103), 103, 'E103 reste dans la saison 1 (numéro continu)');
      T.STATE.series = [s];
      const ev = T.calReleasedEvents(E.now(), E.now() - 20 * DAY, E.now() + DAY).filter((e) => e.type === 'out');
      assert.deepEqual(plain(ev.map((e) => e.sxe)), ['S2E1', 'S2E2', 'S2E3', 'S2E4']);
      assert.deepEqual(plain(ev.map((e) => e.isNew)), [true, false, false, false], 'seul l’épisode 1 ouvre la saison');
    });
  }
  test('épisodes jamais « inventés » : la clé d’archive reste celle de Crunchyroll (numéro de saison brut)', async () => {
    const { s } = await loadBC();
    const e = s.episodes.find((x) => x.n === 52);
    assert.equal(e.season, 1); assert.equal(e.rs, 2);
    const d = T.watchedDetailFromPlayheads('BC', 'Black Clover', s.episodes, new Map(s.episodes.map((x) => [x.id, { p: 1440, full: true }])));
    assert.ok(d.eps.includes('s2e52'), 'clé brute s2e52');
    assert.ok(!d.eps.includes('s1e52'));
  });
  test('une série normale n’est pas touchée (aucun `rs`, mêmes saisons)', async () => {
    const now = E.now();
    const seasons = [{ id: 'a', title: 'Season 1', season_number: 1, season_sequence_number: 1, series_title: 'Foo' }, { id: 'b', title: 'Season 2', season_number: 2, season_sequence_number: 2, series_title: 'Foo' }];
    E.net.on(/\/content\/v2\/cms\/series\/FO\/seasons/, () => ({ data: seasons }));
    E.net.on(/\/content\/v2\/cms\/seasons\/([^/?]+)\/episodes/, (u) => {
      const id = u.match(/seasons\/([^/?]+)\/episodes/)[1]; const sn = id === 'a' ? 1 : 2;
      return { data: Array.from({ length: 12 }, (_, i) => ({ id: id + i, episode_number: i + 1, duration_ms: 1440000, season_number: sn, episode_air_date: new Date(now - (300 - sn * 100 + i) * DAY).toISOString(), availability_starts: new Date(now - (300 - sn * 100 + i) * DAY).toISOString() })) };
    });
    const out = await T.fetchEpisodesRaw('FO');
    assert.equal(out.episodes.length, 24);
    assert.ok(out.episodes.every((e) => e.rs === undefined));
    assert.deepEqual(plain([...new Set(out.episodes.map((e) => e.season))]), [1, 2]);
  });
  test('anciens caches : une entrée v3 qui montre le découpage est relue, une entrée normale est gardée', () => {
    assert.equal(T.epsVerOk({ fv: T.EPS_FILTER_VER }), true);
    const parts = [{ t: 'Black Clover Saison 1 Partie 1', keep: true }, { t: 'Black Clover Saison 1 Partie 2', keep: true }];
    assert.equal(T.epsVerOk({ fv: 3, seasonsDiag: parts, episodes: [] }), false, 'deux entrées « Saison 1 » = parties à fusionner');
    const tiny = [1, 2, 3, 4, 5].map((n) => ({ season: 1, n })).concat([{ season: 3, n: 6 }, { season: 4, n: 7 }]);
    assert.equal(T.epsVerOk({ fv: 3, seasonsDiag: [], episodes: tiny }), false, 'saison de 1 épisode dans la numérotation continue');
    const ok = Array.from({ length: 12 }, (_, i) => ({ season: 1, n: i + 1 })).concat(Array.from({ length: 12 }, (_, i) => ({ season: 2, n: i + 1 })));
    assert.equal(T.epsVerOk({ fv: 3, seasonsDiag: [{ t: 'Season 1', keep: true }, { t: 'Season 2', keep: true }], episodes: ok }), true);
  });
});

describe('titres AniList : « 2nd Season », « 3rd Season Part 2 »…', () => {
  const cases = [
    [['Re:ZERO -Starting Life in Another World- Season 3'], { season: 3, part: null, base: 'Re:ZERO -Starting Life in Another World' }],
    [['Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season'], { season: 3, part: null, base: 'Re:Zero kara Hajimeru Isekai Seikatsu' }],
    [['Shingeki no Kyojin 3rd Season Part 2'], { season: 3, part: 2, base: 'Shingeki no Kyojin' }],
    [['Mushoku Tensei II'], { season: 2, part: null, base: 'Mushoku Tensei' }],
    [['Kimetsu no Yaiba 2'], { season: 2, part: null, base: 'Kimetsu no Yaiba' }],
    [['Spy x Family Season 2 Part 2'], { season: 2, part: 2, base: 'Spy x Family' }],
    [['Attack on Titan: The Final Season'], { season: null, part: null, final: true, base: 'Attack on Titan' }],
    [['Frieren'], { season: null, part: null, base: null }],
    [['Mob Psycho 100'], { season: null, part: null, base: null }],
    [['Jujutsu Kaisen 2nd Season', 'Jujutsu Kaisen Season 2'], { season: 2, part: null, base: 'Jujutsu Kaisen' }],
  ];
  for (const [titles, w] of cases) {
    test(titles[0], () => {
      const r = T.aniSeasonInfo(titles);
      assert.equal(r.season, w.season); assert.equal(r.part, w.part); assert.equal(!!r.final, !!w.final);
      if (w.base) assert.ok(r.bases.includes(w.base), JSON.stringify(r.bases)); else assert.deepEqual(plain(r.bases), []);
    });
  }
});

describe('annonces AniList d’une suite : retrouvée dans tes listes, saison / partie dites, rangée dans « Reprises »', () => {
  const NOWS = () => Math.floor(E.now() / 1000);
  const media = (id, en, ro, o = {}) => ({ id, title: { english: en, romaji: ro }, format: 'TV', genres: ['Action'], description: '', coverImage: { large: '' }, season: null, seasonYear: null,
    startDate: { year: null, month: null, day: null }, nextAiringEpisode: { episode: 1, airingAt: NOWS() + (o.days ?? 20) * 86400 }, externalLinks: [] });
  const followedSeries = (id, title) => {
    const panel = { id, title, slug_title: id.toLowerCase(), images: {}, series_metadata: { tenant_categories: [] } };
    const eps = Array.from({ length: 12 }, (_, i) => ({ season: 1, n: i + 1, id: id + i, ids: [id + i], dur: 1440, title: '', avail: E.now() - (200 - i * 7) * DAY, air: E.now() - (200 - i * 7) * DAY }));
    return T.buildSeriesEntry(panel, eps, eps[11].air, null, 0, new Map(eps.map((e) => [e.id, { p: 1440, full: true }])), null);
  };
  const run = async (list) => { E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: list } } })); await T.loadAniFuture(true); };
  const prems = () => T.calModel(Object.assign(T.calOpts(), { horizon: 90, flags: [] }), E.now()).events.filter((e) => e.type === 'prem');

  test('« 3rd Season » : série suivie reconnue par son titre de base ; S3E1 ; dans Reprises, pas dans Nouvelles séries', async () => {
    T.STATE.series = [followedSeries('RZ', 'Re:ZERO -Starting Life in Another World-')];
    await run([media(1, 'Re:ZERO -Starting Life in Another World- Season 3', 'Re:Zero kara Hajimeru Isekai Seikatsu 3rd Season'), media(3, 'Totally New Show', 'Zenzen Atarashii')]);
    const p = prems();
    const f = p.filter((e) => e.followed);
    assert.deepEqual(plain(f.map((e) => e.followed.id)), ['RZ'], 'reconnue par le titre de base anglais');
    assert.equal(f[0].sxe, 'S3E1');
    const o = (flags) => Object.assign(T.calOpts(), { horizon: 90, flags });
    const rep = T.calModel(o(['new']), E.now()).events.filter((e) => e.type === 'prem');
    const nou = T.calModel(Object.assign(o([]), { sources: ['new'] }), E.now()).events.filter((e) => e.type === 'prem');
    assert.ok(rep.some((e) => e.followed) && !rep.some((e) => !e.followed), 'Reprises : la nouvelle saison');
    assert.ok(nou.length === 1 && !nou[0].followed, 'Nouvelles séries : seulement l’inconnue ' + JSON.stringify(nou.map((e) => [e.key, e.title, !!e.followed])) + JSON.stringify(plain(T.STATE.aniFut.items.map((i) => i.title))));
  });
  test('« Part 2 » : une REPRISE (pas un épisode 1) — libellé « Partie 2 », puce « Reprise »', async () => {
    T.STATE.series = [followedSeries('SK', 'Shingeki')];
    await run([media(1, null, 'Shingeki 3rd Season Part 2')]);
    const e = prems().find((x) => x.followed);
    assert.ok(e, 'retrouvée'); assert.equal(e.part, 2); assert.equal(e.sxe, 'S3 · Partie 2');
    assert.match(T.calPremiereWhen(e, E.now()), /^Reprise \(partie 2\) le /);
    T.STATE.series.push(followedSeries('ZZ', 'Autre'));
    const dom = E.html(T.renderCalendrier());
    const card = [...dom.querySelectorAll('.crrav-calcard.prem')].find((c) => /Shingeki/.test(c.textContent));
    assert.ok(card); assert.match(card.textContent, /Reprise/); assert.match(card.textContent, /S3 · Partie 2/);
  });
  test('déjà daté par un épisode de la série suivie (même sans lien Crunchyroll déclaré) : pas de doublon', async () => {
    const s = followedSeries('AB', 'Alpha Beta');
    const now = E.now();
    s.aniNextTs = now + 20 * DAY; s.aniNextNum = 1;
    T.STATE.series = [s];
    await run([media(1, 'Alpha Beta Season 2', 'Alpha Beta 2nd Season', { days: 20 })]);
    const evs = T.calModel(Object.assign(T.calOpts(), { horizon: 90 }), now).events.filter((e) => e.id === 'AB' || (e.followed && e.followed.id === 'AB'));
    assert.ok(evs.length <= 1, 'au plus un événement : ' + evs.map((e) => e.key).join(','));
  });
});
