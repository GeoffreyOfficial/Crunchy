'use strict';
// Score « pépite » de Découverte : profil de goût, similarité cosinus, signaux, paliers
// légendaire/notable, plafond sans liaison AniList, tags méta sous-pondérés, filtres de genre.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series } = require('./lib/env');

let E, T;
const SCORE_CFG = {
  discoverTasteWeight: 3, discoverTasteNeutralCos: 0.3, discoverGoodTasteThreshold: 0.15,
  discoverPrefGenreBonus: 0.8, discoverFavRecBonus: 0.3,
  discoverWellRatedThresholdCr: 4.1, discoverWellRatedThresholdAni: 3.3, discoverWellRatedBonus: 0.3,
  discoverSuperRatedThresholdCr: 4.5, discoverSuperRatedThresholdAni: 3.8, discoverSuperRatedBonus: 0.5,
  discoverLegendaryScore: 1.7, discoverNotableScore: 1.2,
  discoverCompletionWeight: 0.6, discoverMyRatingWeight: 0.5, discoverLowSignalTagWeight: 0.25,
};
beforeEach(() => {
  E = fresh(); T = E.T; Object.assign(T.CFG, SCORE_CFG);
  T.CFG.discoverExcludeCategories = ['romance', 'hentai'];
  T.STATE.filters.discoverCatsIn = []; T.STATE.filters.discoverCatsEx = [];
});
afterEach(() => E.close());

const tags = (...pairs) => pairs.map(([name, rank]) => ({ name, rank }));
const watched = (id, tg, extra = {}) => series(id, Array.from({ length: 12 }, (_, i) => ep(1, i + 1, { seen: i < (extra.seenN ?? 12) })), { tags: tg, categories: extra.categories || [], myRating: extra.myRating ?? null, favorite: extra.myRating === 5 });

describe('profil de goût (buildTasteProfile)', () => {
  test('vide sans séries vues', () => {
    T.STATE.series = [];
    const p = T.buildTasteProfile();
    assert.equal(p.size, 0); assert.equal(p.norm, 0);
  });
  test('tags pondérés par rank ; séries non vues ignorées', () => {
    T.STATE.series = [watched('A', tags(['Magic', 100], ['School', 50])), { ...watched('B', tags(['Sports', 100])), seen: 0 }];
    const p = T.buildTasteProfile();
    assert.ok(p.weights['tag:Magic'] > p.weights['tag:School']);
    assert.equal(p.weights['tag:Sports'], undefined);
    assert.equal(p.top[0], 'tag:Magic');
  });
  test('tags méta (Male Protagonist…) sous-pondérés ×0.25', () => {
    T.STATE.series = [watched('A', tags(['Magic', 80], ['Male Protagonist', 80]))];
    const p = T.buildTasteProfile();
    assert.ok(Math.abs(p.weights['tag:Male Protagonist'] / p.weights['tag:Magic'] - 0.25) < 1e-9);
    assert.equal(T.tagLowSignalMult('ensemble cast'), 0.25);
    assert.equal(T.tagLowSignalMult('Isekai'), 1);
  });
  test('série finie pèse plus qu’une série survolée du même volume', () => {
    const done = watched('A', tags(['Magic', 100]), { seenN: 12 });
    const skim = { ...watched('B', tags(['Sports', 100]), { seenN: 12 }), total: 100 };
    T.STATE.series = [done, skim];
    const p = T.buildTasteProfile();
    assert.ok(p.weights['tag:Magic'] > p.weights['tag:Sports']);
  });
  test('note perso : 5★ renforce, 1★ affaiblit', () => {
    T.STATE.series = [watched('A', tags(['Magic', 100]), { myRating: 5 }), watched('B', tags(['Sports', 100]), { myRating: 1 })];
    const p = T.buildTasteProfile();
    assert.ok(p.weights['tag:Magic'] > 2 * p.weights['tag:Sports']);
  });
  test('séries sans tags : repli genres, sans mélange tags+genres pour une même série', () => {
    T.STATE.series = [watched('A', [], { categories: ['Action'] }), watched('B', tags(['Magic', 100]), { categories: ['Comédie'] })];
    const p = T.buildTasteProfile();
    assert.ok(p.weights['genre:Action']);
    assert.equal(p.weights['genre:Comédie'], undefined, 'B a des tags : ses genres ne vont que dans le sous-profil genres');
    assert.ok(p.genreWeights['genre:Comédie']);
  });
});

describe('tasteScore (cosinus remis à l’échelle, borné [-1, 1])', () => {
  beforeEach(() => { T.STATE.series = [watched('A', tags(['Magic', 100], ['School', 60]), { categories: ['Fantastique'] })]; });
  test('profil identique → +1 ; aucun tag commun → -1', () => {
    const p = T.buildTasteProfile();
    assert.equal(T.tasteScore({ tags: tags(['Magic', 100], ['School', 60]) }, p), 1);
    assert.equal(T.tasteScore({ tags: tags(['Sports', 100]) }, p), -1);
  });
  test('monotone : plus de recouvrement = meilleur goût', () => {
    const p = T.buildTasteProfile();
    const a = T.tasteScore({ tags: tags(['Magic', 100], ['Sports', 100]) }, p);
    const b = T.tasteScore({ tags: tags(['Magic', 100], ['Sports', 100], ['Gore', 100], ['Mecha', 100]) }, p);
    assert.ok(a > b);
  });
  test('candidate SANS tags comparée au sous-profil genres (pas de malus fantôme)', () => {
    const p = T.buildTasteProfile();
    assert.ok(T.tasteScore({ tags: [], categories: ['Fantastique'] }, p) > 0);
    assert.equal(T.tasteScore({ tags: [], categories: [] }, p), 0);
  });
  test('profil vide → neutre', () => assert.equal(T.tasteScore({ tags: tags(['Magic', 100]) }, { norm: 0 }), 0));
});

describe('discoverSignals : badges, score, paliers', () => {
  beforeEach(() => { T.STATE.series = [watched('A', tags(['Magic', 100], ['School', 60]))]; });
  test('parfait match bien noté et lié à AniList → légendaire', () => {
    const sig = T.discoverSignals({ id: 'C', tags: tags(['Magic', 100], ['School', 60]), rating: 4.8, aniScore: 85, aniMatched: true }, T.buildTasteProfile());
    assert.equal(sig.legendary, true);
    assert.deepEqual([...sig.badges.map((b) => b[0])], ['🎯', '💚', '🏆']);
    assert.equal(sig.lead, 'pref');
  });
  test('sans liaison AniList : plafonné à « notable » (jamais légendaire)', () => {
    const sig = T.discoverSignals({ id: 'C', tags: tags(['Magic', 100], ['School', 60]), rating: 4.8, aniMatched: false }, T.buildTasteProfile());
    assert.equal(sig.legendary, false);
    assert.equal(sig.notable, true);
  });
  test('hors goûts : un genre aimé ne compense pas les genres étrangers (pas de 🎯)', () => {
    const sig = T.discoverSignals({ id: 'C', tags: tags(['Magic', 30], ['Sports', 100], ['Drama', 100], ['Mecha', 100]), rating: 4.8, aniScore: 90, aniMatched: true }, T.buildTasteProfile());
    assert.ok(sig.parts.taste < 0);
    assert.ok(!sig.badges.some((b) => b[0] === '🎯'));
    assert.equal(sig.legendary, false);
  });
  test('palier décidé sur le score AFFICHÉ (somme des termes arrondis)', () => {
    const sig = T.discoverSignals({ id: 'C', tags: tags(['Magic', 100]), rating: 4.2, aniMatched: true }, T.buildTasteProfile());
    const p = sig.parts;
    const r1 = (v) => Math.round(v * 10) / 10;
    assert.equal(sig.scoreShown, r1(p.tasteContrib) + p.prefBonus + p.wellBonus + p.superBonus + p.favRecBonus);
    assert.equal(sig.legendary, sig.scoreShown >= T.CFG.discoverLegendaryScore);
  });
  test('note : CR ET AniList doivent chacune passer leur seuil ; une note inconnue ne bloque pas', () => {
    const p = T.buildTasteProfile();
    const base = { id: 'C', tags: tags(['Magic', 100]), aniMatched: true };
    assert.equal(T.discoverSignals({ ...base, rating: 4.3, aniScore: 60 }, p).parts.wellBonus, 0, 'AniList 3.0/5 < 3.3');
    assert.equal(T.discoverSignals({ ...base, rating: 4.3, aniScore: null }, p).parts.wellBonus, 0.3);
    assert.equal(T.discoverSignals({ ...base, rating: null, aniScore: null }, p).parts.wellBonus, 0, 'aucune note connue');
    assert.equal(T.discoverSignals({ ...base, rating: 4.6, aniScore: 80 }, p).parts.superBonus, 0.5);
  });
  test('💞 reco d’un favori : bonus via l’id AniList en cache', () => {
    T.STATE.series = [watched('FAV', tags(['Magic', 100]), { myRating: 5 })];
    T.cacheSet('favrecs:FAV', [{ id: 777 }]);
    T.cacheSet('anilist:C', { av: T.ANILIST_CACHE_VER, aniId: 777 });
    const sig = T.discoverSignals({ id: 'C', tags: tags(['Magic', 100]), aniMatched: true }, T.buildTasteProfile());
    assert.equal(sig.parts.favRecBonus, 0.3);
    assert.ok(sig.badges.some((b) => b[0] === '💞'));
  });
});

describe('empreinte de scoring (validité du cache « nugget: »)', () => {
  test('change si un réglage ou le profil change', () => {
    T.STATE.series = [watched('A', tags(['Magic', 100]))];
    const p = T.buildTasteProfile();
    const a = T.discoverScoreFingerprint(p);
    assert.equal(T.discoverScoreFingerprint(p), a, 'stable');
    T.CFG.discoverLegendaryScore = 1.8;
    assert.notEqual(T.discoverScoreFingerprint(p), a);
    T.CFG.discoverLegendaryScore = 1.7;
    T.CFG.discoverCompletionWeight = 0.1;
    assert.notEqual(T.discoverScoreFingerprint(p), a, 'pondération du profil incluse (v3.59.0)');
  });
});

describe('profil « série unique » (baguette 🪄)', () => {
  test('buildSingleSeriesProfile a la même forme que le profil agrégé', () => {
    const p = T.buildSingleSeriesProfile(tags(['Sports', 100]), ['Sport']);
    for (const k of ['weights', 'norm', 'genreWeights', 'genreNorm', 'max', 'top', 'size']) assert.ok(k in p, k);
    assert.equal(T.tasteScore({ tags: tags(['Sports', 100]) }, p), 1);
    assert.equal(T.buildSingleSeriesProfile([], []), null);
  });
  test('activeSimilarProfile se désactive dès que les genres divergent', () => {
    T.STATE.discover.similarTo = { id: 'X', genres: ['Sport'] };
    T.STATE.discover.similarProfile = { size: 1 };
    T.STATE.filters.discoverCatsIn = ['sport'];
    assert.ok(T.activeSimilarProfile());
    T.STATE.filters.discoverCatsIn = ['sport', 'drame'];
    assert.equal(T.activeSimilarProfile(), null);
    T.STATE.discover.similarTo = null;
  });
});

describe('filtres de genre', () => {
  test('exclusion par défaut (romance, hentai) : un seul genre suffit', () => {
    assert.equal(T.categoriesRejectedByGenre(['Action', 'Romance']), true);
    assert.equal(T.categoriesRejectedByGenre(['Action']), false);
  });
  test('puces « exclure » en plus du réglage', () => {
    T.STATE.filters.discoverCatsEx = ['horreur'];
    assert.equal(T.categoriesRejectedByGenre(['Horreur']), true);
  });
  test('« garder uniquement » : OR par défaut, AND en mode strict (baguette)', () => {
    T.STATE.filters.discoverCatsIn = ['action', 'sport'];
    assert.equal(T.categoriesRejectedByGenre(['Action']), false);
    assert.equal(T.categoriesRejectedByGenre(['Action'], null, null, true), true);
    assert.equal(T.categoriesRejectedByGenre(['Action', 'Sport'], null, null, true), false);
  });
  test('genres inconnus : écarté seulement si « garder uniquement » est actif', () => {
    assert.equal(T.categoriesRejectedByGenre(null), false);
    T.STATE.filters.discoverCatsIn = ['action'];
    assert.equal(T.categoriesRejectedByGenre([]), true);
  });
  test('pré-filtre browse : ne tranche jamais sans genres (sinon « garder » vidait tout)', () => {
    T.STATE.filters.discoverCatsIn = ['action'];
    assert.equal(T.browseRejectedByGenre({ id: 'X', title: 'X' }), false);
    assert.equal(T.browseRejectedByGenre({ series_metadata: { tenant_categories: ['Romance'] } }), true);
  });
  test('listes live séparées (Nouveautés)', () => {
    assert.equal(T.categoriesRejectedByGenre(['Mecha'], ['mecha'], []), false);
    assert.equal(T.categoriesRejectedByGenre(['Action'], ['mecha'], []), true);
  });
});
