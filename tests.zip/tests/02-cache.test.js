'use strict';
// Couche de cache : TTL, lecture « stale », éviction, persistance IndexedDB, instantanés,
// et les régressions « donnée encore valable mais effacée de l'affichage » (v3.88/v3.89).
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, ep, series, DAY } = require('./lib/env');
const { IDBFactory } = require('./lib/loader');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; });
afterEach(() => E.close());

describe('cacheGet / cacheGetStale / cacheSet', () => {
  test('cacheGet respecte le TTL, cacheGetStale l’ignore', () => {
    T.cacheSet('k', { a: 1 });
    assert.deepEqual({ ...T.cacheGet('k', 1000) }, { a: 1 });
    E.advance(1001);
    assert.equal(T.cacheGet('k', 1000), null);
    assert.deepEqual({ ...T.cacheGetStale('k') }, { a: 1 });
  });
  test('clé absente → null partout', () => {
    assert.equal(T.cacheGet('nope', 1e9), null);
    assert.equal(T.cacheGetStale('nope'), null);
  });
  test('cacheSet horodate avec l’horloge courante', () => {
    T.cacheSet('k', 1);
    assert.equal(T.cacheReadRaw('k').ts, E.now());
  });
});

describe('éviction', () => {
  test('evictOldest purge d’abord les plus anciennes, seulement les préfixes évictables', () => {
    for (let i = 0; i < 8; i++) { T.cacheSet('rating:' + i, { r: i }); E.advance(10); }
    T.cacheSet('anilist:cooldown', { until: 1 });          // jamais évictable (pas un préfixe listé ? « anilist: » l'est)
    T.cacheSet('filters-like', { keep: true });             // préfixe non évictable
    const n = T.evictOldest(0.25);
    assert.ok(n >= 2);
    assert.equal(T.cacheReadRaw('rating:0'), null, 'la plus ancienne part en premier');
    assert.ok(T.cacheReadRaw('rating:7'), 'la plus récente reste');
    assert.ok(T.cacheReadRaw('filters-like'), 'préfixe hors EVICTABLE jamais purgé');
  });
  test('watchedids: et anilist: sont évictables (les plus grosses entrées)', () => {
    assert.ok(T.EVICTABLE.includes('watchedids:'));
    assert.ok(T.EVICTABLE.includes('anilist:'));
  });
  test('eps3 : écriture, lecture, invalidation d’une série', () => {
    T.eps3Write('S1', { eps: [1] });
    T.cacheSet('series:S1', { x: 1 });
    T.cacheSet('anilist:S1', { x: 1 });
    assert.ok(T.eps3ReadRaw('S1'));
    T.eps3Invalidate('S1');
    assert.equal(T.eps3ReadRaw('S1'), null);
    assert.equal(T.cacheReadRaw('series:S1'), null);
    assert.equal(T.cacheReadRaw('anilist:S1'), null);
  });
});

async function idbReady(inst) {
  for (let i = 0; i < 300; i++) {
    if ((await inst.T.idbGet(inst.T.IDB_TIER_KEY)) === inst.T.CACHE_TIER) return;
    await inst.tick(10);
  }
  throw new Error('IndexedDB jamais initialisé');
}
describe('persistance IndexedDB', () => {
  test('une entrée écrite est relue par une nouvelle instance (même navigateur)', async () => {
    E.close();
    const idb = new IDBFactory();
    const A = fresh({ idb });
    await idbReady(A);                   // initBigCache : estampille le palier de schéma (sinon il viderait notre écriture)
    A.T.cacheSet('rating:XYZ', { r: 4.6 });
    A.T.flushBigCache();
    for (let i = 0; i < 100 && !(await A.T.idbGet('rating:XYZ')); i++) await A.tick(10);
    const B = fresh({ idb });
    for (let i = 0; i < 100 && !B.T.cacheGetStale('rating:XYZ'); i++) await B.tick(10);   // chargement IDB asynchrone
    assert.deepEqual({ ...B.T.cacheGetStale('rating:XYZ') }, { r: 4.6 });
    A.close(); B.close();
    E = fresh(); T = E.T;
  });
  test('un palier de schéma différent invalide le cache disque', async () => {
    E.close();
    const idb = new IDBFactory();
    const A = fresh({ idb });
    await idbReady(A);
    A.T.cacheSet('rating:OLD', { r: 1 });
    A.T.flushBigCache();
    for (let i = 0; i < 100 && !(await A.T.idbGet('rating:OLD')); i++) await A.tick(10);
    await A.T.idbSet(A.T.IDB_TIER_KEY, 'palier-inconnu');
    const B = fresh({ idb });
    await idbReady(B);
    assert.equal(B.T.cacheGetStale('rating:OLD'), null);
    A.close(); B.close();
    E = fresh(); T = E.T;
  });
});

describe('instantanés Reste à voir / Hors listes (v3.85 / v3.92)', () => {
  const mk = () => series('S1', [ep(1, 1, { seen: true }), ep(1, 2)], { title: 'Une série', isNew: true });
  test('snapshotSave allège les épisodes et retire isNew ; snapshotLoad le relit 7 j', () => {
    T.STATE.series = [mk()];
    T.snapshotSave();
    const snap = T.snapshotLoad();
    assert.equal(snap.length, 1);
    assert.equal('isNew' in snap[0], false);
    assert.deepEqual(Object.keys(snap[0].episodes[0]).sort(), ['air', 'dur', 'id', 'n', 'season', 'seen', 'started', 'title'].sort());
    assert.equal(snap[0].next.n, 2);
    E.advance(7 * DAY + 1);
    assert.equal(T.snapshotLoad(), null, 'au-delà de 7 j : rescan complet');
  });
  test('instantané vide = absent', () => {
    T.STATE.series = [];
    T.snapshotSave();
    assert.equal(T.snapshotLoad(), null);
  });
  test('Hors listes a sa propre clé et primeOrphanSnapshot l’affiche avant le scan', () => {
    T.STATE.orphan.series = [mk()];
    T.orphanSnapshotSave();
    assert.equal(T.cacheGetStale('snapshot'), null, 'clés distinctes');
    T.STATE.orphan.series = [];
    T.STATE.orphan.loading = false;
    T.primeOrphanSnapshot();
    assert.equal(T.STATE.orphan.series.length, 1);
    assert.equal(T.STATE.orphan.fromSnapshot, true);
  });
  test('primeOrphanSnapshot ne remplace pas une liste déjà affichée', () => {
    T.STATE.orphan.series = [mk()];
    T.orphanSnapshotSave();
    const live = series('LIVE', [ep(1, 1)]);
    T.STATE.orphan.series = [live];
    T.primeOrphanSnapshot();
    assert.equal(T.STATE.orphan.series[0].id, 'LIVE');
  });
});

describe('curseur légendaire', () => {
  test('sauvegarde bornée ≥ 0 et entière', () => {
    assert.equal(T.loadLegendaryCursor(), 0);
    T.saveLegendaryCursor(37.9);
    assert.equal(T.loadLegendaryCursor(), 37);
    T.saveLegendaryCursor(-5);
    assert.equal(T.loadLegendaryCursor(), 0);
  });
});

describe('notes : affichage sans contrainte d’âge (régression v3.89.0)', () => {
  test('getRatingCached affiche une note vieille de 22 j (RATING_TTL = 21 j)', () => {
    T.cacheSet('rating:S1', { r: 4.7 });
    E.advance(22 * DAY);
    assert.equal(T.getRatingCached('S1'), 4.7);
  });
  test('getMyRatingCached idem', () => {
    T.cacheSet('myrating:S1', { r: 5 });
    E.advance(60 * DAY);
    assert.equal(T.getMyRatingCached('S1'), 5);
  });
  test('getRating : cache frais = aucune requête ; périmé = refetch', async () => {
    let calls = 0;
    E.net.on(/content-reviews\/v2\/rating\/series\/S1/, () => { calls++; return { average: '4,2' }; });
    T.cacheSet('rating:S1', { r: 3 });
    assert.equal(await T.getRating('S1'), 3);
    assert.equal(calls, 0);
    E.advance(T.RATING_TTL + 1);
    assert.equal(await T.getRating('S1'), 4.2, 'virgule décimale acceptée');
    assert.equal(calls, 1);
  });
  test('getRating : erreur réseau → null mis en cache (pas de martèlement)', async () => {
    E.net.on(/rating\/series\/BAD/, () => ({ __status: 500, body: {} }));
    assert.equal(await T.getRating('BAD'), null);
    assert.deepEqual({ ...T.cacheGetStale('rating:BAD') }, { r: null });
  });
  test('parseMyRatingResponse : formats tolérés', () => {
    assert.equal(T.parseMyRatingResponse({ rating: '5s' }), 5);
    assert.equal(T.parseMyRatingResponse({ data: { rating: { value: 4 } } }), 4);
    assert.equal(T.parseMyRatingResponse({ user_rating: '3,5' }), 3.5);
    assert.equal(T.parseMyRatingResponse({}), null);
    assert.equal(T.parseMyRatingResponse(null), null);
  });
});

describe('cache AniList : affichage vs rafraîchissement (régression v3.88.0)', () => {
  const put = (id, v) => T.cacheSet('anilist:' + id, { av: T.ANILIST_CACHE_VER, ...v });
  test('readAnilistCached garde une valeur périmée affichée (AniList injoignable)', () => {
    put('S1', { matched: true, anilistStatus: 'RELEASING', nextEpTs: E.now() + DAY, nextEpNum: 7, genres: ['Action'] });
    E.advance(13 * 3600e3);    // > TTL 12 h d'une série en diffusion
    const a = T.readAnilistCached('S1');
    assert.equal(a.nextEpNum, 7);
    assert.deepEqual([...a.genres], ['Action']);
    assert.equal(T.anilistNeedsFetch('S1'), true, 'mais un refetch est bien demandé');
  });
  test('ancien format de cache = vide (jamais de données d’un autre schéma)', () => {
    T.cacheSet('anilist:S1', { av: T.ANILIST_CACHE_VER - 1, matched: true, nextEpNum: 3 });
    assert.equal(T.readAnilistCached('S1'), T.EMPTY_ANI);
    assert.equal(T.anilistNeedsFetch('S1'), true);
  });
  test('anilistTtlMs selon le statut', () => {
    assert.equal(T.anilistTtlMs({ anilistStatus: 'RELEASING' }), 12 * 3600e3);
    assert.equal(T.anilistTtlMs({ anilistStatus: 'NOT_YET_RELEASED' }), 6 * 3600e3);
    assert.equal(T.anilistTtlMs({ matched: true, meanScore: null }), 7 * DAY);
    assert.equal(T.anilistTtlMs({ matched: true, meanScore: 80 }), 90 * DAY);
    assert.equal(T.anilistTtlMs({ matched: false }), 90 * DAY);
  });
  test('anilistNeedsFetch : prochain épisode déjà passé → relecture (après 30 min)', () => {
    put('S1', { matched: true, meanScore: 80, anilistStatus: 'RELEASING', relv: 1, nextEpTs: E.now() + 3600e3 });
    assert.equal(T.anilistNeedsFetch('S1'), false);
    E.advance(2 * 3600e3);
    assert.equal(T.anilistNeedsFetch('S1'), true);
  });
  test('anilistNeedsFetch : CR voit la série en diffusion mais le cache la dit finie → relecture', () => {
    put('S1', { matched: true, meanScore: 80, anilistStatus: 'FINISHED', relv: 1 });
    assert.equal(T.anilistNeedsFetch('S1', { airing: false }), false);
    assert.equal(T.anilistNeedsFetch('S1', { airing: true }), false, 'pas avant 6 h');
    E.advance(6 * 3600e3 + 1);
    assert.equal(T.anilistNeedsFetch('S1', { airing: true }), true, 'relu toutes les 6 h au lieu de 90 j');
    put('S3', { matched: true, meanScore: 80, anilistStatus: 'FINISHED' });   // entrée d'avant relv
    assert.equal(T.anilistNeedsFetch('S3', { airing: true }), true, 'ancienne entrée : relue tout de suite');
  });
  test('anilistNeedsFetch : une correspondance forcée ajoutée après coup invalide le cache', () => {
    put('S1', { matched: true, meanScore: 80, aniId: 1 });
    assert.equal(T.anilistNeedsFetch('S1', { title: 'Madan no Ô to Vanadis' }), true);
    put('S2', { matched: true, meanScore: 80, aniId: 20809 });
    assert.equal(T.anilistNeedsFetch('S2', { title: 'Madan no Ô to Vanadis' }), false);
  });
});

describe('cache de correspondance AniList → Crunchyroll', () => {
  test('positif 30 j, négatif 3 j, version de cache vérifiée', () => {
    T.writeCrMatchCache(1, { id: 'G1' });
    T.writeCrMatchCache(2, { id: null });
    E.advance(4 * DAY);
    assert.equal(T.readCrMatchCached(1).id, 'G1');
    assert.equal(T.readCrMatchCached(2), undefined, 'négatif expiré : on retente');
    E.advance(27 * DAY);
    assert.equal(T.readCrMatchCached(1), undefined);
    T.cacheSet('crmatch:3', { id: 'G3', cv: 1 });
    assert.equal(T.readCrMatchCached(3), undefined, 'ancien format ignoré');
  });
});

describe('slimPanel (quota localStorage/IDB)', () => {
  test('ne garde que l’utile et aplatit les genres', () => {
    const raw = {
      id: 'S1', title: 'T', slug_title: 's', description: 'd', extra_lourd: 'x'.repeat(5000),
      images: { poster_tall: [[{ source: 'a', width: 60 }, { source: 'b', width: 240 }, { source: 'c', width: 1200 }]] },
      series_metadata: { season_count: 2, episode_count: 24, tenant_categories: [{ tenant_category: 'action', localization: { title: 'Action' } }], audio_locales: ['ja-JP'] },
    };
    const s = T.slimPanel(raw);
    assert.equal(s.extra_lourd, undefined);
    assert.equal(s.images.poster_tall[0][0].source, 'b', '1re image ≥ 240 px');
    assert.deepEqual([...s.series_metadata.tenant_categories], ['Action']);
    assert.equal(s.series_metadata.episode_count, 24);
    assert.ok(JSON.stringify(s).length < JSON.stringify(raw).length / 5);
  });
  test('panel sans image exploitable', () => {
    const s = T.slimPanel({ id: 'S', title: 'T' });
    assert.deepEqual([...s.images.poster_tall], []);
  });
});
