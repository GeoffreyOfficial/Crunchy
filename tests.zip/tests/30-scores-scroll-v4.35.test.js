'use strict';
// v4.35.0 — notes par ANIMÉ (Crunchyroll ET AniList sur chaque carte, passée ou future) ; résumé défilable ; titre de jour simplifié.
const { test, describe, beforeEach, afterEach, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { fresh, DAY } = require('./lib/env');
const { seed } = require('./lib/scenarios');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
afterEach(() => E.close());
const crItem = (id, title, inDays) => ({ id, title, poster: '', wide: '', synopsis: '', categories: [], ts: E.now() + inDays * DAY, firstN: 1, rank: 1, crId: id, crSlug: id.toLowerCase(), crSource: 'crunchyroll',
  eps: [1, 2].map((n) => ({ id: id + 'e' + n, n, t: '', ts: E.now() + (inDays + (n - 1) * 7) * DAY })) });

describe('mêmes deux notes pour tous les épisodes d’un animé (Dark Machine)', () => {
  test('épisode passé (catalogue Crunchyroll) ET épisode futur (AniList) : « ★ 3.8 | AL ★ 2.5 » partout', async () => {
    E.net.on(/\/content-reviews\/v2\/rating\/series\/([^/?]+)/, (u, o, m) => ({ average: m[1] === 'GDARK' ? '3.8' : null }));
    T.STATE.crSeason.items = [crItem('GDARK', 'Dark Machine The Animation', -3)];       // épisodes passés + à venir datés par Crunchyroll
    T.STATE.aniLive.items = [{ aniId: 7, id: 'ani:7', crId: '', crSlug: '', url: '', title: 'Dark Machine The Animation', titles: ['Dark Machine The Animation'], poster: '', aniScore: 50, categories: ['Sci-Fi'], synopsis: '', eps: [{ n: 4, ts: E.now() + 2 * DAY }] }];
    await T.calEnsureRatings(); await E.tick(20);
    T.STATE.series = [(() => { const eps = [{ season: 1, n: 1, id: 'Ze1', ids: ['Ze1'], dur: 1440, air: E.now() - 2 * DAY, avail: E.now() - 2 * DAY, title: '' }];
      return T.buildSeriesEntry({ id: 'Z', title: 'Zéro', slug_title: 'z', images: {}, series_metadata: { tenant_categories: [] } }, eps, eps[0].air, null, 0, new Map(), null); })()];
    T.STATE.filters.calSources = ['mine', 'rest']; T.STATE.filters.calView = 'agenda'; T.calUi().q = '';
    const cards = [...E.html(T.renderCalendrier()).querySelectorAll('.crrav-calcard')].filter((c) => /Dark Machine/.test(c.textContent));
    assert.ok(cards.length >= 2, 'plusieurs épisodes : ' + cards.length);
    for (const c of cards) { const t = c.querySelector('.crrav-calstar').textContent; assert.match(t, /★ 3\.8/); assert.match(t, /AL ★ 2\.5/); }
  });
});

describe('titre de jour', () => {
  test('« Vendredi 30 Octobre » puis « 3 sorties »', () => {
    const now = Date.parse('2026-10-25T10:00:00Z');
    const hd = E.html(T.calDayHeader(Date.parse('2026-10-30T12:00:00Z'), now, 3)).querySelector('header');
    assert.equal(hd.querySelector('b').textContent, 'Vendredi 30 Octobre'); assert.equal(hd.querySelector('small').textContent, '3 sorties');
  });
});

function loadPlaywright() { for (const m of ['playwright-core', 'playwright', '/opt/npm-tools/node_modules/playwright']) { try { return require(m); } catch (_) { /* suivant */ } } return null; }
const PW = process.env.CRRAV_E2E === '0' ? null : loadPlaywright();
const EXE = [process.env.CRRAV_CHROMIUM, '/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find((p) => p && fs.existsSync(p));
describe('molette sur le voile (hors du résumé) : défile le résumé (JS)', () => {
  test('transmise au résumé tant qu’il peut défiler ; sinon la page garde la molette', async () => {
    const e = fresh(); seed(e, {}); e.T.STATE.tab = 'suivi';
    try {
      for (const s of e.T.STATE.series) s.synopsis = 'x '.repeat(500);
      e.T.openCalendar(); await e.tick(60);
      const D = e.w.document, card = D.querySelector('.crrav-calcard.ep'), syn = card.querySelector('.crrav-calsyn');
      Object.defineProperty(syn, 'scrollHeight', { value: 500 }); Object.defineProperty(syn, 'clientHeight', { value: 50 });
      const fire = (dy) => { const ev = new e.w.WheelEvent('wheel', { deltaY: dy, bubbles: true, cancelable: true }); card.querySelector('.crrav-calgenres, .crrav-calstline').dispatchEvent(ev); return ev.defaultPrevented; };
      assert.equal(fire(120), true); assert.equal(syn.scrollTop, 120);
      assert.equal(fire(-120), true); assert.equal(syn.scrollTop, 0);
      assert.equal(fire(-120), false, 'déjà en haut : la page reprend la molette');
    } finally { e.close(); }
  });
});

describe('Chromium réel : résumé défilable', { skip: !PW || !EXE ? 'Chromium absent' : false }, () => {
  let browser, html;
  const LONG = Array.from({ length: 40 }, (_, i) => `Phrase numéro ${i + 1} du résumé très long.`).join(' ');
  before(async () => {
    browser = await PW.chromium.launch({ executablePath: EXE });
    const e = fresh(); seed(e, {}); e.T.STATE.tab = 'suivi';
    for (const s of e.T.STATE.series) s.synopsis = LONG;
    e.T.STATE.filters.calScope = 'all'; e.T.openCalendar(); await e.tick(60);
    html = '<!doctype html>' + e.w.document.documentElement.outerHTML; e.close();
  });
  after(async () => { if (browser) await browser.close(); });
  test('la molette fait défiler le résumé (la page ne bouge pas) et le début comme la fin sont atteignables', async () => {
    for (const w of [390, 1280, 1920]) {
      const page = await browser.newPage({ viewport: { width: w, height: 900 } });
      try {
        await page.route('**/*', (r) => (/^(data|about|blob):/.test(r.request().url()) ? r.continue() : r.abort()));
        await page.setContent(html, { waitUntil: 'load' });
        await page.addStyleTag({ content: '*,*::before,*::after{animation:none !important;transition:none !important}' });
        const card = page.locator('.crrav-calcard.ep').first(); await card.scrollIntoViewIfNeeded(); await card.hover(); await page.waitForTimeout(50);
        const m = await card.evaluate((el) => { const s = el.querySelector('.crrav-calsyn'); return { oy: getComputedStyle(s).overflowY, sh: s.scrollHeight, ch: s.clientHeight }; });
        assert.equal(m.oy, 'auto'); assert.ok(m.sh > m.ch, `${w}px : le résumé dépasse et doit défiler (${m.sh} > ${m.ch})`);
        const y0 = await page.evaluate(() => scrollY);
        const bb = await card.locator('.crrav-calsyn').boundingBox(); await page.mouse.move(bb.x + bb.width / 2, bb.y + Math.min(bb.height / 2, 12));
        await page.mouse.wheel(0, 400); await page.waitForTimeout(120);
        const r = await card.evaluate((el) => el.querySelector('.crrav-calsyn').scrollTop);
        assert.ok(r > 0, `${w}px : le résumé a défilé (${r})`);
        assert.equal(await page.evaluate(() => scrollY), y0, 'la page n’a pas bougé');
      } finally { await page.close(); }
    }
  });
});
