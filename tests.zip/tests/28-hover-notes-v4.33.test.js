'use strict';
// v4.33.0 — plus de .ics ; détail (statut, genres, résumé, actions) AU SURVOL sur PC / au toucher sur mobile, sans débordement ;
// deux notes distinctes (Crunchyroll « ★ », AniList « AL ★ ») ; fiche Crunchyroll retrouvée pour les séries hors listes.
const { test, describe, beforeEach, afterEach, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { fresh, DAY } = require('./lib/env');
const { seed } = require('./lib/scenarios');

const ANI = /graphql\.anilist\.co/;
const plain = (v) => JSON.parse(JSON.stringify(v));

describe('notes : Crunchyroll ET AniList, retrouvées pour les séries hors listes (Dark Machine)', () => {
  let E, T;
  beforeEach(() => { E = fresh(); T = E.T; T.STATE.series = []; T.STATE.raw = []; T.CFG.calFutureEnabled = true; });
  afterEach(() => E.close());
  const sec = (d) => Math.floor(E.now() / 1000) + Math.round(d * 86400);
  const media = (id, title, o = {}) => ({ id, title: { english: title, romaji: title }, format: 'TV', genres: ['Sci-Fi', 'Action'], description: 'Un résumé <br>très long.', coverImage: { large: '' },
    season: 'FALL', seasonYear: 2026, averageScore: 50, nextAiringEpisode: { episode: 3, airingAt: sec(2) }, airingSchedule: { nodes: [] }, externalLinks: o.links || [] });
  const air = () => T.calModel(Object.assign(T.calOpts(), { horizon: 30, view: 'agenda', sources: ['rest'] }), E.now()).events.filter((e) => e.crSource === 'anilist');

  test('série AniList SANS lien Crunchyroll : sa fiche est retrouvée par la recherche → note Crunchyroll 3,8 ET note AniList 2,5', async () => {
    E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: [media(11, 'Dark Machine The Animation')] } } }));
    E.net.on(/\/content\/v2\/discover\/search/, () => ({ data: [{ type: 'series', items: [{ id: 'GDARK1', title: 'Dark Machine The Animation', slug_title: 'dark-machine-the-animation' }] }] }));
    E.net.on(/\/content-reviews\/v2\/rating\/series\/([^/?]+)/, (u, o, m) => ({ average: m[1] === 'GDARK1' ? '3.8' : null }));
    await T.loadAniLive(true);
    assert.equal(air()[0].score, null, 'avant la recherche : pas de note Crunchyroll, et SURTOUT pas la note AniList à sa place');
    await T.calEnsureRatings(); await E.tick(20);
    const e = air()[0];
    assert.equal(e.score, 3.8); assert.equal(e.ani, 2.5); assert.equal(e.crId, 'GDARK1');
    T.STATE.series = [(() => { const eps = [{ season: 1, n: 1, id: 'Ze1', ids: ['Ze1'], dur: 1440, air: E.now() - 2 * DAY, avail: E.now() - 2 * DAY, title: '' }];
      return T.buildSeriesEntry({ id: 'Z', title: 'Zéro', slug_title: 'z', images: {}, series_metadata: { tenant_categories: [] } }, eps, eps[0].air, null, 0, new Map(), null); })()];
    T.STATE.filters.calSources = ['mine', 'rest'];
    const star = [...E.html(T.renderCalendrier()).querySelectorAll('.crrav-calcard')].find((c) => /Dark Machine/.test(c.textContent)).querySelector('.crrav-calstar');
    assert.match(star.textContent, /★ 3\.8/); assert.match(star.textContent, /AL ★ 2\.5/);
    assert.match(star.title, /Crunchyroll 3\.8\/5/); assert.match(star.title, /AniList 2\.5\/5/);
  });
  test('recherche Crunchyroll non concluante : seule « AL ★ » est affichée, étiquetée comme AniList', async () => {
    E.net.on(ANI, () => ({ data: { Page: { pageInfo: { hasNextPage: false }, media: [media(12, 'Inconnu Total')] } } }));
    E.net.on(/\/content\/v2\/discover\/search/, () => ({ data: [{ type: 'series', items: [] }] }));
    await T.loadAniLive(true); await T.calEnsureRatings(); await E.tick(20);
    const e = air()[0];
    assert.equal(e.score, null); assert.equal(e.ani, 2.5);
  });
});

describe('plus aucun bouton .ics', () => {
  test('ni carte, ni fiche série, ni barre d’outils', async () => {
    const E = fresh(); seed(E, {}); E.T.STATE.tab = 'suivi';
    try {
      E.T.openCalendar(); await E.tick(60);
      const D = E.w.document;
      assert.equal(D.querySelectorAll('[data-act="cal-ics"],[data-act="cal-ics-all"],[data-act="cal-sa-ics"],[data-act="cal-sa-ics1"]').length, 0);
      D.querySelector('.crrav-calcard [data-act="cal-series"]').click(); await E.tick(20);
      assert.equal(D.querySelectorAll('[data-act^="cal-sa-ics"]').length, 0);
      assert.ok(!/Ajouter à mon agenda/.test(D.body.innerHTML));
    } finally { E.close(); }
  });
});

describe('détail de la carte : genres + résumé pour TOUTES les cartes', () => {
  test('séries de mes listes (résumé de la fiche), hors listes, nouvelles : genres + résumé dans le détail', async () => {
    const E = fresh();
    try {
      seed(E, {}); E.T.STATE.tab = 'suivi';
      for (const s of E.T.STATE.series) { s.synopsis = 'Résumé de ma série ' + s.title; s.categories = ['Drame', 'Action']; }
      for (const it of E.T.STATE.crSeason.items) { it.synopsis = 'Résumé catalogue ' + it.title; it.categories = ['Comédie']; }
      for (const it of E.T.STATE.crNew.items) { it.synopsis = 'Résumé nouveauté ' + it.title; it.categories = ['Fantasy']; }
      E.T.STATE.filters.calScope = 'all'; E.T.openCalendar(); await E.tick(60);
      const cards = [...E.w.document.querySelectorAll('.crrav-calcard')];
      assert.ok(cards.length > 5);
      const miss = cards.filter((c) => !c.querySelector('.crrav-calc .crrav-calgenres') || !c.querySelector('.crrav-calc .crrav-calsyn'));
      assert.equal(miss.length, 0, 'cartes sans résumé/genres : ' + miss.map((c) => c.className).join(' | '));
      assert.ok(cards.some((c) => c.classList.contains('air') && /Résumé catalogue/.test(c.querySelector('.crrav-calsyn').textContent)));
      assert.ok(cards.some((c) => c.classList.contains('ep') && /Résumé de ma série/.test(c.querySelector('.crrav-calsyn').textContent)));
    } finally { E.close(); }
  });
});

function loadPlaywright() { for (const m of ['playwright-core', 'playwright', '/opt/npm-tools/node_modules/playwright']) { try { return require(m); } catch (_) { /* suivant */ } } return null; }
const PW = process.env.CRRAV_E2E === '0' ? null : loadPlaywright();
const EXE = [process.env.CRRAV_CHROMIUM, '/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome'].find((p) => p && fs.existsSync(p));
const SKIP = !PW || !EXE ? 'Playwright/Chromium absents' : false;

describe('Chromium réel : détail au survol, animation, aucun débordement même très chargé', { skip: SKIP }, () => {
  let browser, html;
  const LONG = 'Dans un monde où les machines ont pris le contrôle de la ville, un groupe d’amis improbables doit traverser des zones interdites, affronter des créatures mécaniques et percer le secret d’un ancien laboratoire. '.repeat(4);
  before(async () => {
    browser = await PW.chromium.launch({ executablePath: EXE });
    const E = fresh();
    seed(E, {}); E.T.STATE.tab = 'suivi';
    for (const s of E.T.STATE.series) { s.synopsis = LONG; s.categories = ['Science-fiction', 'Action', 'Drame psychologique', 'Slice of life', 'Isekai']; }
    for (const it of E.T.STATE.crSeason.items) { it.synopsis = LONG; it.categories = ['Science-fiction', 'Action', 'Drame psychologique', 'Slice of life']; it.title = 'Un titre vraiment très très long pour tester le débordement ' + it.title; }
    E.T.STATE.filters.calScope = 'all'; E.T.openCalendar(); await E.tick(60);
    html = '<!doctype html>' + E.w.document.documentElement.outerHTML; E.close();
  });
  after(async () => { if (browser) await browser.close(); });
  const open = async (w, animate) => {
    const page = await browser.newPage({ viewport: { width: w, height: 900 } });
    await page.route('**/*', (r) => (/^(data|about|blob):/.test(r.request().url()) ? r.continue() : r.abort()));
    await page.setContent(html, { waitUntil: 'load' });
    if (!animate) await page.addStyleTag({ content: '*,*::before,*::after{animation:none !important;transition:none !important;content-visibility:visible !important}' });
    return page;
  };

  test('survol (PC) : le détail apparaît sans clic ; ni débordement, ni bouton coupé, à toutes les largeurs', async () => {
    const bad = [];
    for (const w of [390, 700, 1024, 1280, 1920, 2560]) {
      const page = await open(w);
      try {
        const n = await page.locator('.crrav-calcard').count();
        for (const i of [0, 1, 2, Math.floor(n / 2), n - 1].filter((v, k, a) => v >= 0 && a.indexOf(v) === k)) {
          const card = page.locator('.crrav-calcard').nth(i);
          await card.scrollIntoViewIfNeeded(); await card.hover(); await page.waitForTimeout(30);
          const r = await card.evaluate((el) => {
            const c = el.querySelector('.crrav-calc'); const cs = getComputedStyle(c);
            const box = el.getBoundingClientRect(); const out = [];
            if (cs.display === 'none') return { hidden: true };
            const cb = c.getBoundingClientRect();
            if (cb.left < box.left - 1 || cb.right > box.right + 1 || cb.top < box.top - 1 || cb.bottom > box.bottom + 1) out.push('voile hors carte');
            if (c.scrollWidth > c.clientWidth + 1 || c.scrollHeight > c.clientHeight + 1) out.push(`voile déborde ${c.scrollWidth}x${c.scrollHeight} / ${c.clientWidth}x${c.clientHeight}`);
            for (const k of c.querySelectorAll('.crrav-calqa,.crrav-calst,.crrav-calgenres')) {
              const b = k.getBoundingClientRect(); if (!b.width) continue;
              if (b.left < cb.left - 1 || b.right > cb.right + 1 || b.bottom > cb.bottom + 1 || b.top < cb.top - 1) out.push('coupé : ' + k.className);
            }
            const pri = c.querySelector('.crrav-calqa.pri'); const pb = pri && pri.getBoundingClientRect();
            if (!pb || pb.width < 30 || pb.height < 28) out.push('bouton Regarder trop petit');
            const syn = c.querySelector('.crrav-calsyn'); if (syn && syn.getBoundingClientRect().height < 1 && box.width >= 200) out.push('résumé invisible');
            return { out, w: Math.round(box.width) };
          });
          if (r.hidden) bad.push(`${w}px carte ${i} : détail non affiché au survol`);
          else if (r.out.length) bad.push(`${w}px carte ${i} (${r.w}px) : ${r.out.join(', ')}`);
        }
      } finally { await page.close(); }
    }
    assert.deepEqual(bad.slice(0, 8), []);
  });
  test('hors survol le détail est masqué ; un clic sur PC ne le fige pas (survol = seul déclencheur)', async () => {
    const page = await open(1280);
    try {
      await page.mouse.move(2, 2);
      assert.equal(await page.locator('.crrav-calcard').first().evaluate((el) => getComputedStyle(el.querySelector('.crrav-calc')).display), 'none');
      await page.locator('.crrav-calcard').first().hover();
      assert.equal(await page.locator('.crrav-calcard').first().evaluate((el) => getComputedStyle(el.querySelector('.crrav-calc')).display), 'flex');
    } finally { await page.close(); }
  });
  test('animation : voile qui se révèle + contenu en cascade (animations réelles, sauf mouvement réduit)', async () => {
    const page = await open(1280, true);
    try {
      await page.locator('.crrav-calcard').first().hover();
      const r = await page.locator('.crrav-calcard').first().evaluate((el) => {
        const c = el.querySelector('.crrav-calc');
        return { veil: getComputedStyle(c).animationName, kids: [...c.children].map((k) => getComputedStyle(k).animationName), delays: [...c.children].map((k) => getComputedStyle(k).animationDelay) };
      });
      assert.equal(r.veil, 'crrav-reveal'); assert.ok(r.kids.every((n) => n === 'crrav-rise'));
      assert.ok(new Set(r.delays).size > 1, 'délais décalés (cascade) : ' + r.delays);
    } finally { await page.close(); }
  });
  test('mobile (toucher) : le détail s’ouvre au clic, sans survol', async () => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, hasTouch: true, isMobile: true });
    const page = await ctx.newPage();
    try {
      await page.route('**/*', (r) => (/^(data|about|blob):/.test(r.request().url()) ? r.continue() : r.abort()));
      await page.setContent(html, { waitUntil: 'load' });
      await page.addStyleTag({ content: '*,*::before,*::after{animation:none !important;transition:none !important}' });
      const card = page.locator('.crrav-calcard').first();
      assert.equal(await card.evaluate((el) => getComputedStyle(el.querySelector('.crrav-calc')).display), 'none');
      await card.evaluate((el) => el.classList.add('open'));
      assert.equal(await card.evaluate((el) => getComputedStyle(el.querySelector('.crrav-calc')).display), 'flex');
    } finally { await ctx.close(); }
  });
});
