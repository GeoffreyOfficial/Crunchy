'use strict';
// v4.10.0 — L'historique connu doit GROSSIR au fil du temps, jamais rétrécir, alors que
// Crunchyroll ne sert qu'une fenêtre glissante des dernières entrées. Simulation sur
// plusieurs semaines, rechargements, purges de cache.
const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, historyEntry, DAY } = require('./lib/env');
const { IDBFactory } = require('./lib/loader');

let E, T;
beforeEach(() => { E = fresh(); T = E.T; T.CFG.concurrency = 3; T.PACE.limit = 3; T.STATE.series = []; T.STATE.raw = []; });
afterEach(() => { if (E) E.close(); });

// « Compte Crunchyroll » simulé : journal complet + fenêtre servie limitée (comme l'API réelle,
// qui refuse au-delà de ~1000 entrées ; ici WINDOW entrées pour garder des tests rapides).
function makeAccount(env, window = 150) {
  const log = [];   // du plus récent au plus ancien
  const acct = {
    log,
    watch(series, season, n, title) {
      const i = log.findIndex((e) => e.parent_id === series && e.panel.episode_metadata.season_number === season && e.panel.episode_metadata.episode_number === n);
      if (i >= 0) log.splice(i, 1);                       // revoir un épisode le remonte en tête
      log.unshift(historyEntry(series, season, n, env.now(), { title: title || series }));
    },
    route() {
      env.net.on(/watch-history\?/, (u) => {
        const p = +new URL(u).searchParams.get('page');
        const served = log.slice(0, window);
        if ((p - 1) * 100 >= window) return { __status: 400, body: {} };
        const d = served.slice((p - 1) * 100, p * 100); return { total: d.length, data: d };
      });
      env.net.on(/crunchyroll\.com/, () => ({ data: [], total: 0 }));
    },
  };
  acct.route();
  return acct;
}
const scan = (force = true) => T.getWatchedSeriesIds('acc', null, force);

describe('croissance de l’historique sur plusieurs semaines', () => {
  test('6 semaines, 4 séries × 12 épisodes par semaine : rien n’est jamais perdu', async () => {
    const acc = makeAccount(E, 150);
    const everSeen = new Set();
    let prevSize = 0;
    for (let week = 0; week < 6; week++) {
      for (let k = 0; k < 4; k++) {
        const sid = `W${week}S${k}`;
        everSeen.add(sid);
        for (let ep = 1; ep <= 12; ep++) { acc.watch(sid, 1, ep); E.advance(20 * 60e3); }
      }
      // plusieurs ouvertures par semaine (scans incrémentaux) + scan complet hebdo (> 7 j)
      for (let day = 0; day < 7; day++) { E.advance(DAY); await scan(day === 0 ? true : false); }
      const ids = await scan();
      for (const sid of everSeen) assert.ok(ids.has(sid), `semaine ${week} : ${sid} perdue`);
      assert.ok(ids.size >= prevSize, 'jamais de rétrécissement');
      prevSize = ids.size;
    }
    assert.equal(prevSize, 24);
    assert.ok(acc.log.length > 150, 'le scénario dépasse bien la fenêtre servie');
    assert.equal(T.historyArchiveCount('acc'), 24);
  });

  test('série longue vue à cheval sur la fenêtre : les épisodes s’accumulent', async () => {
    const acc = makeAccount(E, 100);
    for (let ep = 1; ep <= 5; ep++) { acc.watch('LONG', 1, ep); E.advance(60e3); }
    await scan();
    for (let i = 0; i < 120; i++) { acc.watch('FILL' + Math.floor(i / 12), 1, (i % 12) + 1); E.advance(60e3); }  // pousse LONG hors fenêtre
    E.advance(8 * DAY); await scan();
    for (let ep = 6; ep <= 10; ep++) { acc.watch('LONG', 1, ep); E.advance(60e3); }
    E.advance(8 * DAY); await scan();
    const d = T.HISTORY_DETAIL.find((x) => x.id === 'LONG');
    assert.equal(d.episodes, 10, 'épisodes 1-5 (archivés) + 6-10 (fenêtre)');
    const a = T.historyArchiveLoad('acc').series.LONG;
    assert.equal(a.eps.length, 10);
    assert.equal(a.seconds, 10 * 1440);
  });

  test('temps total vu (Stats) croissant, jamais en baisse', async () => {
    const acc = makeAccount(E, 100);
    let prev = 0;
    for (let round = 0; round < 5; round++) {
      for (let i = 0; i < 60; i++) { acc.watch(`R${round}S${Math.floor(i / 12)}`, 1, (i % 12) + 1); E.advance(60e3); }
      E.advance(8 * DAY);
      await scan();
      const total = T.HISTORY_DETAIL.reduce((s, d) => s + (d.seconds || 0), 0);
      assert.ok(total > prev, `tour ${round} : ${total} ≤ ${prev}`);
      prev = total;
    }
  });

  test('rescanner la même fenêtre 10 fois : mémoire stable (pas de doublons, pas d’inflation)', async () => {
    const acc = makeAccount(E, 150);
    for (let i = 0; i < 48; i++) { acc.watch('S' + Math.floor(i / 12), 1, (i % 12) + 1); E.advance(60e3); }
    await scan();
    const snap = JSON.stringify(T.historyArchiveLoad('acc').series);
    for (let i = 0; i < 10; i++) { E.advance(8 * DAY); await scan(); }
    const after = T.historyArchiveLoad('acc').series;
    assert.equal(Object.keys(after).length, 4);
    for (const [id, d] of Object.entries(JSON.parse(snap))) {
      assert.equal(after[id].eps.length, d.eps.length);
      assert.equal(after[id].seconds, d.seconds);
    }
  });

  test('séries supprimées de l’historique Crunchyroll : conservées (l’historique ne fait que grossir)', async () => {
    const acc = makeAccount(E, 150);
    acc.watch('GONE', 1, 1); acc.watch('KEEP', 1, 1);
    await scan();
    acc.log.splice(acc.log.findIndex((e) => e.parent_id === 'GONE'), 1);
    E.advance(8 * DAY);
    const ids = await scan();
    assert.ok(ids.has('GONE'));
  });
});

describe('robustesse de la mémoire', () => {
  test('survit à un rechargement de la page (IndexedDB)', async () => {
    E.close();
    const idb = new IDBFactory();
    const ready = async (inst) => {
      for (let i = 0; i < 300; i++) { if ((await inst.T.idbGet(inst.T.IDB_TIER_KEY)) === inst.T.CACHE_TIER) return; await inst.tick(10); }
      throw new Error('IDB jamais prêt');
    };
    const A = fresh({ idb }); await ready(A);
    A.T.STATE.series = []; A.T.STATE.raw = [];
    const accA = makeAccount(A, 150);
    accA.watch('OLD', 1, 1, 'Ancienne');
    await A.T.getWatchedSeriesIds('acc', null, true);
    A.T.flushBigCache();
    for (let i = 0; i < 100 && !(await A.T.idbGet('histarchive:acc')); i++) await A.tick(10);
    A.close();
    const B = fresh({ idb }); await ready(B);
    for (let i = 0; i < 100 && !B.T.cacheGetStale('histarchive:acc'); i++) await B.tick(10);
    B.T.STATE.series = []; B.T.STATE.raw = [];
    const accB = makeAccount(B, 150);
    accB.watch('NEW', 1, 1);                       // OLD n'est plus dans la fenêtre servie
    const ids = await B.T.getWatchedSeriesIds('acc', null, true);
    assert.ok(ids.has('OLD') && ids.has('NEW'));
    B.close();
    E = null;
  });
  test('purge du cache sous pression (quota) : la mémoire est épargnée', async () => {
    const acc = makeAccount(E, 150);
    acc.watch('OLD', 1, 1);
    await scan();
    T.evictOldest(1);                              // purge maximale de tout l'évictable
    assert.equal(T.cacheGetStale('watchedids:acc'), null, 'le cache de scan, lui, est purgé');
    assert.ok(T.cacheGetStale('histarchive:acc'), 'la mémoire reste');
    acc.log.length = 0; acc.watch('NEW', 1, 1);
    const ids = await scan(false);
    assert.ok(ids.has('OLD'));
  });
  test('« vider le cache historique » (réglages) ne touche pas la mémoire', async () => {
    const acc = makeAccount(E, 150);
    acc.watch('OLD', 1, 1);
    await scan();
    T.invalidateCache(['watchedids:']);
    assert.ok(T.cacheGetStale('histarchive:acc'));
  });
  test('mémoire isolée par compte Crunchyroll', () => {
    T.historyArchiveMerge('acc', [{ id: 'A', title: 'A', eps: ['s1e1'], seconds: 1, genres: [] }]);
    assert.equal(T.historyArchiveCount('autre'), 0);
    assert.equal(T.withHistoryArchive('autre', [], []).ids.has('A'), false);
  });
});
