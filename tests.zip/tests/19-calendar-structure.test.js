'use strict';
// v4.21.3 — Garde-fous STRUCTURELS contre la classe de bugs « feuille/fenêtre mal ancrée, bloc inséré dans la page,
// bouton sans action » : vérifiés sur le DOM produit par de vrais clics, dans tous les états de l'agenda.
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const { SCENARIOS, build } = require('./lib/scenarios');
const { fresh } = require('./lib/env');
const { seed } = require('./lib/scenarios');

const CAL_SCENARIOS = Object.keys(SCENARIOS).filter((n) => n !== 'fab');

describe('feuilles et fenêtres : ancrage', () => {
  for (const name of CAL_SCENARIOS) {
    test(`« ${name} » : modales sous .crrav-modals (enfant direct de l’overlay), jamais dans le contenu`, async () => {
      const { E, D } = await build(name);
      try {
        const ov = D.querySelector('.crrav-overlay');
        assert.ok(ov, 'overlay présent');
        const modals = ov.querySelector(':scope > .crrav-modals');
        assert.ok(modals, '.crrav-modals enfant direct de l’overlay');
        assert.equal(D.querySelectorAll('.crrav-content .crrav-sa, .crrav-content .crrav-confirm, .crrav-cal .crrav-sa').length, 0,
          'aucune feuille dans .crrav-content / .crrav-cal (position:fixed y serait ancré au conteneur)');
        for (const sheet of D.querySelectorAll('.crrav-sa')) assert.ok(modals.contains(sheet));
      } finally { E.close(); }
    });
  }
  test('ouvrir puis fermer une feuille laisse le contenu du calendrier strictement identique (aucun bloc inséré)', async () => {
    for (const [open, close] of [['.crrav-calsidebtn', '.crrav-sa-x2'], ['.crrav-calcard [data-act="cal-series"]', '.crrav-sa-x']]) {
      const E = fresh(); const D = E.w.document; seed(E);
      try {
        E.T.openCalendar(); await E.tick(60);
        const before = D.querySelector('.crrav-cal').outerHTML;
        D.querySelector(open).click(); await E.tick(20);
        const norm = (h) => h.replace(/crrav-calsidebtn( on)?" data-act="cal-aside" aria-expanded="(true|false)"/, 'crrav-calsidebtn" data-act="cal-aside" aria-expanded="x"');
        assert.equal(norm(D.querySelector('.crrav-cal').outerHTML), norm(before), 'ouvrir ne modifie pas le flux de la page (' + open + ')');
        D.querySelector(close).click(); await E.tick(20);
        assert.equal(D.querySelector('.crrav-cal').outerHTML, before, 'fermer rétablit l’état exact');
        assert.equal(D.querySelector('.crrav-sa'), null);
      } finally { E.close(); }
    }
  });
  test('CSS : aucune règle ne met position:fixed à l’intérieur de .crrav-cal (container-type l’ancrerait au conteneur)', () => {
    const E = fresh();
    try {
      const css = E.T.CSS.replace(/\/\*[\s\S]*?\*\//g, '');
      const rules = [...css.matchAll(/([^{}@][^{}]*)\{([^{}]*)\}/g)];
      const bad = rules.filter(([, sel, body]) => /position:\s*fixed/.test(body) && /\.crrav-cal(?![a-z0-9-])/.test(sel) && !/\.crrav-calwrap/.test(sel));
      assert.deepEqual(bad.map((r) => r[1].trim()), []);
      for (const sel of ['.crrav-sa', '.crrav-sa-opts', '.crrav-fabs', '.crrav-confirm']) assert.ok(css.includes(sel), sel + ' défini');
    } finally { E.close(); }
  });
  test('toute feuille a fond cliquable de fermeture + bouton ✕ + rôle dialog accessible', async () => {
    for (const name of ['agenda-side', 'month-series']) {
      const { E, D } = await build(name);
      try {
        const sa = D.querySelector('.crrav-sa');
        assert.ok(sa, name);
        assert.equal(sa.getAttribute('role'), 'dialog'); assert.equal(sa.getAttribute('aria-modal'), 'true');
        assert.ok(sa.querySelector('.crrav-sa-bg[data-act]'));
        assert.ok(sa.querySelector('button[aria-label="Fermer"]'));
      } finally { E.close(); }
    }
  });
});

describe('exhaustivité : chaque bouton du calendrier fait quelque chose', () => {
  test('tout data-act="cal-*" émis dans tous les états est géré par calHandleAct', async () => {
    const seen = new Map();
    for (const name of CAL_SCENARIOS) {
      const { E, D } = await build(name);
      try { for (const el of D.querySelectorAll('[data-act^="cal-"]')) seen.set(el.dataset.act, (seen.get(el.dataset.act) || 0) + 1); } finally { E.close(); }
    }
    const must = ['cal-view', 'cal-horizon', 'cal-filter', 'cal-opt', 'cal-reset', 'cal-nav', 'cal-sel', 'cal-goto', 'cal-aside', 'cal-series',
      'cal-sa-close', 'cal-sa-ics', 'cal-sa-ics1', 'cal-sa-focus', 'cal-ics', 'cal-ics-all', 'cal-open', 'cal-link'];
    const missing = must.filter((a) => !seen.has(a) && !['cal-reset', 'cal-nav', 'cal-goto', 'cal-sa-ics1'].includes(a));
    assert.deepEqual(missing, [], 'actions jamais rendues dans aucun scénario : ' + missing.join(','));
    const E = fresh(); seed(E); E.T.openCalendar(); await E.tick(60);
    const D = E.w.document;
    E.w.URL.createObjectURL = () => 'blob:x'; E.w.URL.revokeObjectURL = () => {};
    const unhandled = [];
    try {
      for (const act of seen.keys()) {
        const el = D.createElement('button');
        el.dataset.act = act; el.dataset.v = act === 'cal-filter' ? 'all' : act === 'cal-view' ? 'agenda' : '7'; el.dataset.k = 'calShowEst';
        el.dataset.day = E.T.calDayKey(E.now()); el.dataset.id = 'S0'; el.dataset.d = '0'; el.dataset.calkey = 'x';
        E.T.STATE.serieAgenda = act.startsWith('cal-sa') ? { id: 'S0' } : null;
        if (!E.T.calHandleAct(el)) unhandled.push(act);
      }
    } finally { E.close(); }
    assert.deepEqual(unhandled, [], 'boutons sans gestionnaire : ' + unhandled.join(','));
  });
  test('toute action rendue a un libellé accessible (texte, aria-label ou title)', async () => {
    for (const name of ['agenda', 'month-series', 'agenda-side']) {
      const { E, D } = await build(name);
      try {
        for (const b of D.querySelectorAll('.crrav-cal button, .crrav-sa button, .crrav-sa a[data-act]')) {
          const lbl = (b.textContent || '').trim() || b.getAttribute('aria-label') || b.title;
          assert.ok(lbl, `bouton sans libellé (${name}): ${b.outerHTML.slice(0, 120)}`);
        }
      } finally { E.close(); }
    }
  });
});

describe('état : robustesse de la navigation', () => {
  test('changer d’onglet ou de vue avec une feuille ouverte ne laisse pas de feuille orpheline', async () => {
    const { E, D } = await build('agenda-side');
    try {
      assert.ok(D.querySelector('.crrav-sa-opts'));
      D.querySelector('[data-tab="suivi"]').click(); await E.tick(30);
      assert.equal(D.querySelector('.crrav-sa-opts'), null, 'la feuille Options ne reste pas sur un autre onglet');
    } finally { E.close(); }
    const b = await build('agenda-series');
    try {
      b.D.querySelector('.crrav-sa-bg').click(); await b.E.tick(20);
      assert.equal(b.D.querySelector('.crrav-sa'), null);
    } finally { b.E.close(); }
  });
  test('deux feuilles jamais ouvertes en même temps par un geste utilisateur normal', async () => {
    const { E, D } = await build('agenda-side');
    try { assert.ok(D.querySelectorAll('.crrav-sa').length <= 1); } finally { E.close(); }
  });
});
