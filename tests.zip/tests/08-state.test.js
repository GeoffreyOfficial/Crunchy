'use strict';
// État persistant : filtres (dont le verrou « mode similaire »), migrations de formats,
// séries ignorées, navigation de session.
const { test, describe, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { fresh } = require('./lib/env');

let E;
afterEach(() => { if (E) E.close(); E = null; });
const withState = (state, extra = {}) => fresh({ localStorage: { 'crrav:state': JSON.stringify({ v: 1, settings: {}, filters: {}, ignored: {}, airsnap: {}, ...state }) }, ...extra });
const stored = () => JSON.parse(E.w.localStorage.getItem('crrav:state'));

describe('saveFilters : mode similaire 🪄 jamais persisté (régression « Découverte ne montre plus rien »)', () => {
  test('pendant le mode similaire, les 4 champs de genre gardent la préférence d’avant', () => {
    E = withState({ filters: { discoverCatsIn: [], discoverCatsEx: ['horreur'], discoverSort: 'relevance', cleanedStuckGenreFilterVersion: '9' } });
    const T = E.T;
    T.STATE.discover.similarTo = { id: 'X', genres: ['Sport'] };
    T.STATE.filters.discoverCatsIn = ['sport'];
    T.STATE.filters.discoverCatsInMode = 'all';
    T.STATE.filters.view = 'list';                    // un vrai réglage, lui, doit passer
    T.saveFilters();
    const f = stored().filters;
    assert.deepEqual(f.discoverCatsIn, []);
    assert.equal(f.discoverCatsInMode, 'any');
    assert.deepEqual(f.discoverCatsEx, ['horreur']);
    assert.equal(f.view, 'list');
  });
  test('hors mode similaire : persisté normalement, recherches jamais mémorisées', () => {
    E = fresh(); const T = E.T;
    T.STATE.discover.similarTo = null;
    T.STATE.filters.discoverCatsIn = ['action'];
    T.STATE.filters.q = 'mashle';
    T.saveFilters();
    const f = stored().filters;
    assert.deepEqual(f.discoverCatsIn, ['action']);
    assert.equal('q' in f, false);
  });
  test('migration de nettoyage : un filtre « garder » resté coincé est vidé au chargement', () => {
    E = withState({ filters: { discoverCatsIn: ['sport'], discoverCatsInMode: 'all' } });
    assert.deepEqual([...E.T.STATE.filters.discoverCatsIn], []);
    assert.equal(E.T.STATE.filters.discoverCatsInMode, 'any');
    assert.equal(stored().cleanedStuckGenreFilterVersion, E.T.CLEANUP_STUCK_GENRE_FILTER_VERSION);
  });
  test('…mais une seule fois : un filtre choisi après la migration est respecté', () => {
    E = withState({ cleanedStuckGenreFilterVersion: '99.0.0', filters: { discoverCatsIn: ['action'] } });
    assert.deepEqual([...E.T.STATE.filters.discoverCatsIn], ['action']);
  });
});

describe('loadFilters : migrations', () => {
  test('tri par note retiré → tri par défaut ; statuts retirés → « Tout »', () => {
    E = withState({ cleanedStuckGenreFilterVersion: '99', filters: { sort: 'rating', orphanSort: 'rating', discoverSort: 'rating', status: 'todo' } });
    const f = E.T.STATE.filters;
    assert.equal(f.sort, 'remaining'); assert.equal(f.orphanSort, 'remaining');
    assert.equal(f.discoverSort, 'relevance'); assert.equal(f.status, 'all');
  });
  test('ordre des sections : clés invalides retirées, manquantes ajoutées (rien ne disparaît)', () => {
    E = withState({ cleanedStuckGenreFilterVersion: '99', filters: { suiviGroupOrder: ['done', 'bidon'], suiviGroupHidden: ['started'] } });
    assert.deepEqual([...E.T.STATE.filters.suiviGroupOrder], ['done', 'started', 'notstarted']);
    assert.equal('suiviGroupHidden' in E.T.STATE.filters, false);
  });
  test('filtres retirés purgés (aucune série cachée par un filtre disparu)', () => {
    E = withState({ cleanedStuckGenreFilterVersion: '99', filters: { onlyAiring: true, hideAiringSeason: true, showIgnoredDiscover: true, lastTab: 'stats' } });
    for (const k of ['onlyAiring', 'hideAiringSeason', 'showIgnoredDiscover', 'lastTab']) assert.equal(k in E.T.STATE.filters, false, k);
  });
  test('ancien format discoverCats → discoverCatsEx', () => {
    E = withState({ cleanedStuckGenreFilterVersion: '99', filters: { discoverCats: ['mecha'] } });
    assert.deepEqual([...E.T.STATE.filters.discoverCatsEx], ['mecha']);
  });
  test('état corrompu → valeurs par défaut, pas de plantage', () => {
    E = fresh({ localStorage: { 'crrav:state': '{pas du json' } });
    assert.equal(E.T.STATE.filters.sort, 'remaining');
  });
  test('anciennes clés séparées (< 2.44) fusionnées puis supprimées', () => {
    E = fresh({ localStorage: { 'crrav:filters': JSON.stringify({ view: 'list' }), 'crrav:ignored': JSON.stringify(['A']) } });
    assert.equal(E.T.STATE.filters.view, 'list');
    assert.ok(E.T.IGNORED.has('A'));
    assert.equal(E.w.localStorage.getItem('crrav:filters'), null);
  });
});

describe('séries ignorées', () => {
  test('anciens formats (liste d’ids, titre seul) migrés avec une date plancher', () => {
    E = withState({ ignored: { A: 'Titre A', B: { title: 'B', source: 'discover' } } });
    const T = E.T;
    assert.equal(T.IGNORED.get('A').title, 'Titre A');
    assert.equal(T.IGNORED.get('A').source, 'watchlist');
    assert.equal(T.IGNORED.get('B').ignoredAt, T.RETRO_IGNORED_AT);
    assert.equal(stored().ignored.A.ignoredAt, T.RETRO_IGNORED_AT, 'date plancher persistée');
  });
  test('toggleIgnored ajoute puis retire, persiste, horodate', () => {
    E = fresh(); const T = E.T;
    T.toggleIgnored('X', 'Mashle', 'discover');
    assert.equal(T.IGNORED.get('X').ignoredAt, E.now());
    assert.equal(T.ignoredCount('discover'), 1);
    assert.ok(stored().ignored.X);
    T.toggleIgnored('X', 'Mashle', 'discover');
    assert.equal(T.IGNORED.has('X'), false);
    assert.equal(stored().ignored.X, undefined);
  });
  test('ignoreAll : une seule écriture, sans doublon', () => {
    E = fresh(); const T = E.T;
    T.toggleIgnored('A', 'A', 'discover');
    const n = T.ignoreAll([{ id: 'A', title: 'A' }, { id: 'B', title: 'B' }, { id: 'C', title: 'C' }], 'discover');
    assert.equal(n, 2);
    assert.equal(T.ignoredCount('discover'), 3);
  });
});

describe('navigation de session (onglet + défilement, sessionStorage uniquement)', () => {
  test('onglet inconnu → « suivi » ; défilement invalide ignoré', () => {
    E = fresh({ sessionStorage: { 'crrav:sessionnav': JSON.stringify({ tab: 'pirate', scrollPos: [1] }) } });
    assert.equal(JSON.stringify(E.T.loadSessionNav()), JSON.stringify({ tab: 'suivi', scrollPos: {} }));
  });
  test('onglet valide restauré', () => {
    E = fresh({ sessionStorage: { 'crrav:sessionnav': JSON.stringify({ tab: 'decouverte', scrollPos: { suivi: 120 } }) } });
    assert.equal(E.T.STATE.tab, 'decouverte');
  });
  test('jamais écrit dans les réglages persistants (localStorage)', () => {
    E = fresh(); const T = E.T;
    T.saveSessionNav({ tab: 'stats', scrollPos: {} });
    T.saveFilters();
    assert.equal('lastTab' in stored().filters, false);
    assert.equal(E.w.localStorage.getItem('crrav:sessionnav'), null);
  });
});
