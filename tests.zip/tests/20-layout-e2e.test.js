'use strict';
// v4.21.3 — Mise en page dans un VRAI Chromium (le DOM est produit par de vrais clics dans jsdom puis rendu avec le CSS réel
// du script). Attrape ce que jsdom ne voit jamais : feuilles mal ancrées, colonnes écrasées, débordements, cibles trop petites,
// chevauchements, blocs insérés dans la page. Se SAUTE proprement si Playwright/Chromium sont absents (CRRAV_E2E=0 pour forcer).
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { build } = require('./lib/scenarios');

function loadPlaywright() {
  for (const m of ['playwright-core', 'playwright', '/opt/npm-tools/node_modules/playwright']) { try { return require(m); } catch (_) { /* suivant */ } }
  return null;
}
function chromiumPath() {
  for (const p of [process.env.CRRAV_CHROMIUM, '/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome']) { if (p && fs.existsSync(p)) return p; }
  return null;
}
const PW = process.env.CRRAV_E2E === '0' ? null : loadPlaywright();
const EXE = chromiumPath();
const SKIP = !PW || !EXE ? 'Playwright/Chromium absents : tests de mise en page sautés (npm i -D playwright-core ; CRRAV_CHROMIUM=/chemin/chrome)' : false;

const WIDTHS = [280, 320, 360, 390, 430, 600, 700, 768, 884, 1024, 1039, 1040, 1059, 1060, 1099, 1100, 1119, 1120, 1139, 1140, 1159, 1160, 1280, 1536, 1700, 1920, 2560, 3840];
const H = 900;
let browser;
before(async () => { if (!SKIP) browser = await PW.chromium.launch({ executablePath: EXE }); });
after(async () => { if (browser) await browser.close(); });

// Une page par scénario, redimensionnée à chaque largeur (recharger 380 Ko de HTML 24 fois coûtait ~2,5 min).
const PAGES = new Map();
async function render(html, w, h = H) {
  let page = PAGES.get(html);
  if (!page) {
    page = await browser.newPage({ viewport: { width: w, height: h } });
    await page.route('**/*', (r) => (/^(data|about|blob):/.test(r.request().url()) ? r.continue() : r.abort()));
    await page.setContent(html, { waitUntil: 'load' });
    // Pas d'animation d'entrée (le panneau démarre à scale .99) : on mesure l'état final.
    await page.addStyleTag({ content: '*,*::before,*::after{animation:none !important;transition:none !important;content-visibility:visible !important}' });
    PAGES.set(html, page);
  }
  await page.setViewportSize({ width: w, height: h });
  await page.waitForTimeout(15);
  return new Proxy(page, { get: (t, k) => (k === 'close' ? async () => {} : (typeof t[k] === 'function' ? t[k].bind(t) : t[k])) });
}
const rectOf = (page, sel) => page.evaluate((s) => { const e = document.querySelector(s); if (!e) return null; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e);
  return { x: r.x, y: r.y, w: r.width, h: r.height, r: r.right, b: r.bottom, display: cs.display, pos: cs.position }; }, sel);
const overflowX = (page) => page.evaluate(() => {
  const ov = document.querySelector('.crrav-overlay');
  return { doc: document.documentElement.scrollWidth - innerWidth, ov: ov ? ov.scrollWidth - ov.clientWidth : 0 };
});

describe('mise en page réelle (Chromium)', { skip: SKIP, timeout: 300000 }, () => {
  const page_scenarios = ['agenda', 'week', 'month', 'month-busy', 'agenda-filters', 'month-side', 'agenda-side', 'month-series', 'agenda-series'];
  for (const name of page_scenarios) {
    test(`« ${name} » : aucun débordement horizontal, de 280 à 3840 px`, async () => {
      const { html, E } = await build(name); E.close();
      const bad = [];
      for (const w of WIDTHS) {
        const page = await render(html, w);
        try { const o = await overflowX(page); if (o.doc > 1 || o.ov > 1) bad.push(`${w}px: doc+${o.doc} overlay+${o.ov}`); } finally { await page.close(); }
      }
      assert.deepEqual(bad, []);
    });
  }

  for (const [name, sheetSel] of [['agenda-series', '.crrav-sa'], ['month-series', '.crrav-sa']]) {
    test(`« ${name} » : la fiche série couvre exactement l’écran (ancrage fixed) et son contenu tient dedans`, async () => {
      const { html, E } = await build(name); E.close();
      const bad = [];
      for (const w of WIDTHS) {
        const page = await render(html, w);
        try {
          const r = await rectOf(page, sheetSel); const s = await rectOf(page, sheetSel + ' .crrav-sa-sheet');
          if (!r || r.pos !== 'fixed') { bad.push(`${w}: pas fixed`); continue; }
          if (Math.abs(r.x) > 1 || Math.abs(r.y) > 1 || Math.abs(r.w - w) > 1 || Math.abs(r.h - H) > 1) bad.push(`${w}: voile ${JSON.stringify(r)}`);
          if (s.x < -1 || s.r > w + 1 || s.y < -1 || s.b > H + 1) bad.push(`${w}: feuille hors écran ${JSON.stringify(s)}`);
          for (const btn of ['.crrav-sa-x', '.crrav-sa-btn']) { const b = await rectOf(page, `.crrav-sa ${btn}`); if (b && (b.h < 40 || b.w < 40)) bad.push(`${w}: ${btn} ${Math.round(b.w)}x${Math.round(b.h)}`); }
        } finally { await page.close(); }
      }
      assert.deepEqual(bad, []);
    });
  }

  for (const name of ['agenda-side', 'month-side']) {
    test(`« ${name} » : feuille Options = plein écran < 700 px, fenêtre dans l’écran jusqu’à 1039 px, remplacée par le panneau permanent (jamais de zone morte)`, async () => {
      const { html, E } = await build(name); E.close();
      const bad = [];
      for (const w of WIDTHS) {
        const page = await render(html, w);
        try {
          const sheet = await rectOf(page, '.crrav-sa-opts');
          const aside = await rectOf(page, '.crrav-calaside');
          // Jamais de « zone morte » : à toute largeur, soit le panneau permanent est là, soit la feuille est affichable.
          const permanent = !!aside && aside.display !== 'none';
          const sheetOn = sheet.display !== 'none';
          if (!permanent && !sheetOn) bad.push(`${w}: ni panneau permanent ni feuille (zone morte)`);
          if (w >= 1160 && sheetOn) bad.push(`${w}: feuille visible alors que le panneau est permanent`);
          if (w >= 1160 && !permanent) bad.push(`${w}: panneau permanent absent`);
          if (!permanent) {
            const sh = await rectOf(page, '.crrav-sa-opts .crrav-sa-sheet');
            if (w < 700 && (Math.abs(sh.w - w) > 1 || Math.abs(sh.h - H) > 2)) bad.push(`${w}: pas plein écran ${Math.round(sh.w)}x${Math.round(sh.h)}`);
            if (sh.x < -1 || sh.r > w + 1 || sh.y < -1 || sh.b > H + 1) bad.push(`${w}: feuille hors écran`);
            const foot = await rectOf(page, '.crrav-sa-opts .crrav-sa-foot'); if (foot.b > H + 1) bad.push(`${w}: bouton Fermer hors écran`);
            const btn = await rectOf(page, '.crrav-calsidebtn'); if (btn.display === 'none') bad.push(`${w}: bouton réglages absent alors qu’il n’y a pas de panneau permanent`);
          } else {
            const btn = await rectOf(page, '.crrav-calsidebtn'); if (btn && btn.display !== 'none') bad.push(`${w}: bouton réglages visible avec panneau permanent`);
          }
        } finally { await page.close(); }
      }
      assert.deepEqual(bad, []);
    });
  }

  test('ouvrir une feuille ne change PAS la hauteur du calendrier (aucun bloc inséré, donc aucun saut de défilement)', async () => {
    const base = await build('agenda'); const side = await build('agenda-side'); const ser = await build('agenda-series');
    base.E.close(); side.E.close(); ser.E.close();
    const bad = [];
    for (const w of [320, 390, 768, 1024, 1536]) {
      const hs = [];
      for (const html of [base.html, side.html, ser.html]) {
        const page = await render(html, w);
        try {
          await page.evaluate(() => document.querySelectorAll('.crrav-calnote').forEach((n) => n.remove())); // avis réseau : dépend du timing, pas de la feuille
          hs.push(Math.round((await rectOf(page, '.crrav-cal')).h));
        } finally { await page.close(); }
      }
      if (hs.some((x) => Math.abs(x - hs[0]) > 2)) bad.push(`${w}: ${hs.join(' / ')}`);
    }
    assert.deepEqual(bad, []);
  });

  test('vue Mois : le détail du jour garde une largeur utile (jamais en lamelle) à toutes les largeurs', async () => {
    const { html, E } = await build('month'); E.close();
    const bad = [];
    for (const w of WIDTHS) {
      const page = await render(html, w);
      try {
        const cards = await page.evaluate(() => [...document.querySelectorAll('.crrav-calselday .crrav-calcard')].map((c) => { const r = c.getBoundingClientRect(); return [r.width, r.height]; }));
        if (!cards.length) { bad.push(`${w}: aucune carte`); continue; }
        for (const [cw, ch] of cards) {
          if (cw < Math.min(200, w - 40)) bad.push(`${w}: carte trop étroite ${Math.round(cw)}px`);
          if (ch > cw * 1.8) bad.push(`${w}: carte en lamelle ${Math.round(cw)}x${Math.round(ch)}`);
        }
      } finally { await page.close(); }
    }
    assert.deepEqual(bad, []);
  });

  test('vue Mois : cases lisibles (affiches > 12 px sur mobile), aucune case qui sort de la grille', async () => {
    const { html, E } = await build('month-busy'); E.close();
    const bad = [];
    for (const w of WIDTHS) {
      const page = await render(html, w);
      try {
        const m = await page.evaluate(() => {
          const g = document.querySelector('.crrav-calmgrid:not(.mini)').getBoundingClientRect();
          const out = []; let minTh = 999, minCell = 999;
          for (const c of document.querySelectorAll('.crrav-calmgrid:not(.mini) .crrav-calcell:not(.blank)')) {
            const r = c.getBoundingClientRect(); minCell = Math.min(minCell, r.width);
            if (r.left < g.left - 1 || r.right > g.right + 1) out.push('case hors grille');
            for (const t of c.querySelectorAll('.crrav-calth')) { const tr = t.getBoundingClientRect(); if (tr.width > 0) minTh = Math.min(minTh, tr.width); }
            if (c.scrollHeight > c.clientHeight + 2) out.push('contenu coupé ' + c.dataset.day);
          }
          return { out: [...new Set(out)], minTh, minCell };
        });
        if (m.out.length) bad.push(`${w}: ${m.out.join(',')}`);
        if (m.minTh !== 999 && m.minTh < 12) bad.push(`${w}: affiche ${m.minTh}px`);
        if (m.minCell < 28) bad.push(`${w}: case ${m.minCell}px`);
      } finally { await page.close(); }
    }
    assert.deepEqual(bad, []);
  });

  test('filtres : cibles tactiles ≥ 32 px, recherche utilisable, rien ne se chevauche', async () => {
    const { html, E } = await build('agenda-filters'); E.close();
    const bad = [];
    for (const w of WIDTHS) {
      const page = await render(html, w);
      try {
        const m = await page.evaluate(() => {
          const small = [...document.querySelectorAll('.crrav-calchip, .crrav-calq, .crrav-calib, .crrav-calseg button')].filter((e) => e.offsetParent).map((e) => { const r = e.getBoundingClientRect(); return [e.className, r.width, r.height]; }).filter(([, cw, ch]) => ch < 32 || cw < 28);
          const s = document.querySelector('.crrav-calsearch').getBoundingClientRect();
          return { small, searchW: s.width };
        });
        if (m.small.length) bad.push(`${w}: ${m.small.map((x) => x.join(' ')).slice(0, 2).join(' | ')}`);
        if (m.searchW < Math.min(150, w - 40)) bad.push(`${w}: recherche ${Math.round(m.searchW)}px`);
      } finally { await page.close(); }
    }
    assert.deepEqual(bad, []);
  });

  test('boutons flottants Agenda + Mon Crunchy : dans l’écran, sans chevauchement', async () => {
    const { html, E } = await build('fab'); E.close();
    const bad = [];
    for (const w of WIDTHS) {
      const page = await render(html, w);
      try {
        const a = await rectOf(page, '.crrav-fab-ag'), m = await rectOf(page, '.crrav-fab');
        if (a.x < 0 || m.r > w + 0.5 || a.b > H + 0.5 || m.b > H + 0.5) bad.push(`${w}: hors écran`);
        if (a.r > m.x + 0.5) bad.push(`${w}: chevauchement`);
        if (a.h < 44 || m.h < 44 || a.w < 44 || m.w < 44) bad.push(`${w}: cible ${Math.round(a.w)}x${Math.round(a.h)} / ${Math.round(m.w)}x${Math.round(m.h)}`);
      } finally { await page.close(); }
    }
    assert.deepEqual(bad, []);
  });

  for (const name of ['suivi', 'suivi-list']) {
    test(`« ${name} » : le bouton agenda d’une carte ne chevauche pas « Ignorer » et reste dans sa carte`, async () => {
      const { html, E } = await build(name); E.close();
      const bad = [];
      for (const w of [320, 390, 768, 1280, 1920]) {
        const page = await render(html, w);
        try {
          const m = await page.evaluate(() => {
            const out = []; const btns = [...document.querySelectorAll('.crrav-agbtn')];
            for (const a of btns) {
              const card = a.closest('.crrav-card, .crrav-lrow, article'); const ig = card && card.querySelector('.crrav-ignore');
              const ra = a.getBoundingClientRect(); if (!ra.width) continue;
              if (card) { const rc = card.getBoundingClientRect(); if (ra.left < rc.left - 1 || ra.right > rc.right + 1 || ra.bottom > rc.bottom + 1) out.push('hors carte'); }
              if (ig) { const ri = ig.getBoundingClientRect(); if (!(ra.right <= ri.left + 0.5 || ra.left >= ri.right - 0.5 || ra.bottom <= ri.top + 0.5 || ra.top >= ri.bottom - 0.5)) out.push('chevauche Ignorer'); }
            }
            return { n: btns.length, out: [...new Set(out)] };
          });
          if (!m.n) bad.push(`${w}: aucun bouton agenda`);
          if (m.out.length) bad.push(`${w}: ${m.out.join(',')}`);
        } finally { await page.close(); }
      }
      assert.deepEqual(bad, []);
    });
  }
});
