'use strict';
// Utilitaires transverses : versions, formats, garde-fous asynchrones, pool, HTML.
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { fresh, DAY } = require('./lib/env');

let E, T;
before(() => { E = fresh(); T = E.T; });
after(() => E.close());

describe('compareVersions', () => {
  test('ordre numérique, pas lexical', () => {
    assert.equal(T.compareVersions('4.10.0', '4.9.0'), 1);
    assert.equal(T.compareVersions('4.9.0', '4.10.0'), -1);
    assert.equal(T.compareVersions('3.39.0', '3.39.0'), 0);
  });
  test('segments manquants = 0', () => {
    assert.equal(T.compareVersions('4.7', '4.7.0'), 0);
    assert.equal(T.compareVersions('4', '3.99.99'), 1);
  });
  test('version du script cohérente avec l’en-tête @version', () => {
    const fs = require('fs');
    const src = fs.readFileSync(require('./lib/loader').SCRIPT, 'utf8');
    const header = /\/\/ @version\s+(\S+)/.exec(src)[1];
    assert.equal(T.SCRIPT_VERSION, header, 'SCRIPT_VERSION et @version doivent être bumpés ensemble');
  });
});

describe('formats de durée', () => {
  test('fmtDuration : arrondi sur le total en minutes (jamais « 20 h 60 »)', () => {
    assert.equal(T.fmtDuration(0), '—');
    assert.equal(T.fmtDuration(1440), '24 min');
    assert.equal(T.fmtDuration(3600), '1 h');
    assert.equal(T.fmtDuration(5400), '1 h 30');
    assert.equal(T.fmtDuration(20 * 3600 + 59 * 60 + 50), '21 h');
    assert.equal(T.fmtDuration(3600 + 5 * 60), '1 h 05');
  });
  test('fmtShortDuration', () => {
    assert.equal(T.fmtShortDuration(0), '0 s');
    assert.equal(T.fmtShortDuration(-5), '0 s');
    assert.equal(T.fmtShortDuration(45000), '45 s');
    assert.equal(T.fmtShortDuration(120000), '2 min');
    assert.equal(T.fmtShortDuration(125000), '2 min 5 s');
  });
  test('fmtRelDay', () => {
    const now = E.now();
    assert.equal(T.fmtRelDay(0), '');
    assert.equal(T.fmtRelDay(now - 3600e3), "aujourd'hui");
    assert.equal(T.fmtRelDay(now - DAY - 1), 'hier');
    assert.equal(T.fmtRelDay(now - 3 * DAY - 1), 'il y a 3 j');
    assert.equal(T.fmtRelDay(now - 14 * DAY - 1), 'il y a 2 sem.');
    assert.equal(T.fmtRelDay(now - 800 * DAY), 'il y a 2 ans');
  });
});

describe('escapeHtml', () => {
  test('échappe les 5 caractères sensibles', () => {
    assert.equal(T.escapeHtml(`<a href="x" title='y'>&</a>`), '&lt;a href=&quot;x&quot; title=&#39;y&#39;&gt;&amp;&lt;/a&gt;');
  });
  test('accepte les non-chaînes', () => { assert.equal(T.escapeHtml(42), '42'); });
});

describe('withDeadline (garde-fou Firefox Android en arrière-plan)', () => {
  test('résout normalement si la promesse arrive à temps', async () => {
    assert.equal(await T.withDeadline(Promise.resolve(7), 1000, 'x'), 7);
  });
  test('rejette avec le libellé si la promesse ne se règle jamais', async () => {
    await assert.rejects(T.withDeadline(new Promise(() => {}), 1, 'AniList'), /AniList : délai dépassé/);
  });
  test('propage le rejet d’origine', async () => {
    await assert.rejects(T.withDeadline(Promise.reject(new Error('boom')), 1000), /boom/);
  });
});

describe('safeCall', () => {
  test('renvoie la valeur ou le repli, ne lève jamais', () => {
    assert.equal(T.safeCall(() => 3, 0, 't'), 3);
    assert.equal(T.safeCall(() => { throw new Error('x'); }, 'repli', 't'), 'repli');
  });
});

describe('pool', () => {
  test('respecte l’ordre des résultats et la limite de concurrence', async () => {
    let live = 0, peak = 0;
    const out = await T.pool([1, 2, 3, 4, 5, 6], async (x) => {
      live++; peak = Math.max(peak, live);
      await E.tick(2); live--; return x * 10;
    }, 2);
    assert.deepEqual([...out], [10, 20, 30, 40, 50, 60]);
    assert.ok(peak <= 2, 'jamais plus de 2 en parallèle');
  });
  test('une erreur de worker donne null sans casser les autres', async () => {
    const out = await T.pool([1, 2, 3], async (x) => { if (x === 2) throw new Error('x'); return x; }, 3);
    assert.deepEqual([...out], [1, null, 3]);
  });
  test('shouldStop arrête d’attribuer de nouveaux items', async () => {
    let n = 0;
    await T.pool([1, 2, 3, 4, 5], async () => { n++; }, 1, null, () => n >= 2);
    assert.equal(n, 2);
  });
});

describe('rythme adaptatif (429)', () => {
  test('paceOnThrottle réduit, paceOnSuccess remonte progressivement', () => {
    T.CFG.concurrency = 4;
    T.PACE.limit = 4; T.PACE.ok = 0;
    T.paceOnThrottle();
    assert.equal(T.paceLimit(), 3);
    for (let i = 0; i < 20; i++) T.paceOnSuccess();
    assert.equal(T.paceLimit(), 4);
  });
  test('paceLimit ne dépasse jamais CFG.concurrency ni ne descend sous 1', () => {
    T.PACE.limit = 99; T.CFG.concurrency = 3;
    assert.equal(T.paceLimit(), 3);
    T.CFG.concurrency = 0;
    assert.equal(T.paceLimit(), 1);
    T.CFG.concurrency = 4; T.PACE.limit = 4;
  });
});

describe('URLs Crunchyroll', () => {
  test('parseCrunchyrollUrl : avec/sans locale, slug optionnel', () => {
    assert.deepEqual({ ...T.parseCrunchyrollUrl('https://www.crunchyroll.com/fr/series/GDKHZEP8W/mashle-magic-and-muscles') },
      { id: 'GDKHZEP8W', slug: 'mashle-magic-and-muscles' });
    assert.deepEqual({ ...T.parseCrunchyrollUrl('https://www.crunchyroll.com/series/G6497W726') }, { id: 'G6497W726', slug: '' });
    assert.deepEqual({ ...T.parseCrunchyrollUrl('https://www.crunchyroll.com/pt-br/series/GABC/x?y=1') }, { id: 'GABC', slug: 'x' });
  });
  test('parseCrunchyrollUrl : rejette ce qui n’est pas une fiche série', () => {
    assert.equal(T.parseCrunchyrollUrl('https://www.youtube.com/@crunchyroll'), null);
    assert.equal(T.parseCrunchyrollUrl('https://www.crunchyroll.com/watch/GXYZ'), null);
    assert.equal(T.parseCrunchyrollUrl(null), null);
  });
  test('crWatchUrl/crSeriesUrl hors Android = https simple', () => {
    assert.equal(T.crWatchUrl('G1'), 'https://www.crunchyroll.com/watch/G1');
    assert.equal(T.crSeriesUrl('G2', 'slug'), 'https://www.crunchyroll.com/fr/series/G2/slug');
  });
});

describe('libellés de progression', () => {
  test('stepLabel', () => assert.equal(T.stepLabel(2, 3, 'Historique'), 'Étape 2/3 · Historique'));
  test('historyScanLabel : avec total, sans total (total non fiable), sans rien', () => {
    assert.equal(T.historyScanLabel(null), 'Historique de visionnage…');
    assert.equal(T.historyScanLabel({ done: 3, total: 9, scanned: 300, series: 40 }),
      'Historique de visionnage… page 3/9 · 300 entrées · 40 séries');
    assert.equal(T.historyScanLabel({ done: 4, total: null, scanned: 400 }),
      'Historique de visionnage… page 4 · 400 entrées');
  });
});
